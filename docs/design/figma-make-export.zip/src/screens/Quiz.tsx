import { useState } from 'react';
import type { Screen } from '../types';

const C = {
  coral: '#C0553A',
  coralTint: '#F7EAE6',
  ground: '#F6F5F2',
  panel: '#FFFFFF',
  ink: '#1A1918',
  ink2: '#6B6560',
  ink3: '#A09A93',
  fog: '#EEEAE4',
  edge: '#E6E2DA',
  warmTint: '#FAF5EF',
  successTint: '#EEF5EE',
  successGreen: '#2D6A2D',
  sans: "'Inter', system-ui, sans-serif",
  serif: "'Playfair Display', Georgia, serif",
};

interface Question {
  type: 'Mechanism' | 'Apply' | 'Distinguish';
  typeDesc: string;
  question: string;
  options: string[];
  correct: number;
  feedback: {
    correct: string;
    distractor: string;
  };
}

const QUESTIONS: Question[] = [
  {
    type: 'Mechanism',
    typeDesc: 'Understand the central change',
    question: 'What fundamentally changes when an agent gains persistent memory?',
    options: [
      'The model receives a larger context window during a session',
      'The model responds more quickly to repeated queries',
      'The agent can retain useful information across separate sessions',
      'The agent gains access to more external tools',
    ],
    correct: 2,
    feedback: {
      correct: 'Exactly. Persistent memory allows the agent to carry useful context forward when a session ends and a new one begins — not just hold more within one session.',
      distractor: 'A larger context window increases capacity within a single session but still resets when that session ends. Persistent memory is what survives the reset.',
    },
  },
  {
    type: 'Apply',
    typeDesc: 'Apply the concept to a new situation',
    question: 'A customer-support agent shuts down after every conversation but remembers unresolved issues when it starts again the next day. Which capability best explains this?',
    options: [
      'A longer context window',
      'Persistent memory',
      'Tool use',
      'Faster model inference',
    ],
    correct: 1,
    feedback: {
      correct: 'Right. The agent is retaining state across separate sessions — exactly what persistent memory enables. The shutdown and restart make context-window size irrelevant.',
      distractor: 'A longer context window would only help if the conversation never ended. Once the agent shuts down, only persistent memory can bridge the gap to the next session.',
    },
  },
  {
    type: 'Distinguish',
    typeDesc: 'Separate this concept from related ideas',
    question: 'Which situation would not require persistent memory?',
    options: [
      'An agent tracking a multi-week research project across work sessions',
      'An agent remembering user preferences from a previous conversation',
      'An agent maintaining context through a single, uninterrupted session',
      'An agent building on notes from last week\'s work',
    ],
    correct: 2,
    feedback: {
      correct: "Correct. Maintaining context within one uninterrupted session is what a context window already handles. Persistent memory is only needed when the session ends and a new one begins.",
      distractor: 'The other options — tracking a project across weeks, remembering preferences from earlier, building on past notes — all require surviving session resets. Only option C stays within a single session.',
    },
  },
];

type Phase = 'question' | 'feedback' | 'result';

export default function Quiz({ onNavigate }: { onNavigate: (s: Screen) => void }) {
  const [qIndex, setQIndex] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [phase, setPhase] = useState<Phase>('question');
  const [answers, setAnswers] = useState<(number | null)[]>([null, null, null]);

  const q = QUESTIONS[qIndex];
  const isCorrect = selected === q.correct;
  const allCorrect = answers.every((a, i) => a === QUESTIONS[i].correct);

  const submit = () => {
    if (selected === null) return;
    const newAnswers = [...answers];
    newAnswers[qIndex] = selected;
    setAnswers(newAnswers);
    setPhase('feedback');
  };

  const advance = () => {
    if (qIndex < QUESTIONS.length - 1) {
      setQIndex(i => i + 1);
      setSelected(null);
      setPhase('question');
    } else {
      setPhase('result');
    }
  };

  // ── Result screen ────────────────────────────────────────────────────────────
  if (phase === 'result') {
    const incorrectCount = answers.filter((a, i) => a !== QUESTIONS[i].correct).length;

    return (
      <div style={{
        height: '100%', display: 'flex', flexDirection: 'column',
        backgroundColor: C.ground, fontFamily: C.sans,
      }}>
        <div style={{ flex: 1, overflowY: 'auto', padding: '48px 24px 32px' }}>

          {/* Status */}
          <div style={{ marginBottom: '32px' }}>
            <div style={{
              width: '40px', height: '40px', borderRadius: '50%',
              backgroundColor: incorrectCount === 0 ? C.successTint : C.coralTint,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              marginBottom: '16px',
            }}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
                stroke={incorrectCount === 0 ? C.successGreen : C.coral}
                strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                {incorrectCount === 0
                  ? <polyline points="20 6 9 17 4 12"/>
                  : <><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></>
                }
              </svg>
            </div>

            <h1 style={{
              fontFamily: C.serif, fontSize: '26px', fontWeight: 600,
              color: C.ink, letterSpacing: '-0.02em', lineHeight: 1.2, marginBottom: '10px',
            }}>
              {incorrectCount === 0 ? 'Initial understanding verified.' : 'One connection needs clarification.'}
            </h1>

            <p style={{ fontSize: '14px', color: C.ink2, lineHeight: 1.6 }}>
              {incorrectCount === 0
                ? 'You identified the mechanism, applied it to a new situation, and distinguished persistent memory from session context.'
                : 'Most connections are clear. Review the explanation below, then Thinketh will offer an equivalent question for that dimension.'}
            </p>
          </div>

          {/* Dimension summary */}
          <div style={{
            backgroundColor: C.panel, borderRadius: '16px',
            overflow: 'hidden', marginBottom: '24px',
            boxShadow: '0 1px 6px rgba(0,0,0,0.05)',
          }}>
            {QUESTIONS.map((q, i) => {
              const ans = answers[i];
              const correct = ans === q.correct;
              return (
                <div key={i} style={{
                  display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                  padding: '14px 18px',
                  borderBottom: i < QUESTIONS.length - 1 ? `1px solid ${C.edge}` : 'none',
                }}>
                  <div>
                    <p style={{ fontSize: '11px', color: C.ink3, marginBottom: '2px', letterSpacing: '0.06em', textTransform: 'uppercase', fontWeight: 500 }}>
                      {q.type}
                    </p>
                    <p style={{ fontSize: '13px', color: correct ? C.ink : C.coral, fontWeight: correct ? 400 : 500 }}>
                      {correct ? 'Verified' : 'Needs clarification'}
                    </p>
                  </div>
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
                    stroke={correct ? C.successGreen : C.coral}
                    strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                    {correct
                      ? <polyline points="20 6 9 17 4 12"/>
                      : <><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></>
                    }
                  </svg>
                </div>
              );
            })}
          </div>

          {/* What happens next */}
          <div style={{
            backgroundColor: C.coralTint, borderRadius: '14px',
            padding: '14px 18px', marginBottom: '8px',
          }}>
            <p style={{ fontSize: '12px', color: C.coral, fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase', marginBottom: '6px' }}>
              Next
            </p>
            <p style={{ fontSize: '13px', color: C.ink, lineHeight: 1.5 }}>
              Persistent Memory will be integrated into your Knowledge Atlas and connected to three concepts you already understand.
            </p>
          </div>
        </div>

        {/* CTA */}
        <div style={{
          flexShrink: 0, padding: '16px 24px 32px',
          borderTop: `1px solid ${C.edge}`,
          backgroundColor: C.ground,
        }}>
          <button
            onClick={() => onNavigate('update')}
            style={{
              width: '100%', padding: '15px',
              backgroundColor: C.ink, color: '#fff',
              border: 'none', borderRadius: '14px',
              fontSize: '15px', fontWeight: 600, fontFamily: C.sans,
              cursor: 'pointer', letterSpacing: '-0.01em',
            }}
          >
            Integrate into my Atlas
          </button>
        </div>
      </div>
    );
  }

  // ── Question / Feedback screen ───────────────────────────────────────────────
  return (
    <div style={{
      height: '100%', display: 'flex', flexDirection: 'column',
      backgroundColor: C.ground, fontFamily: C.sans,
    }}>
      {/* Header */}
      <div style={{
        flexShrink: 0, padding: '48px 24px 0',
        display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between',
      }}>
        <button
          onClick={() => onNavigate('detail')}
          style={{
            background: 'none', border: 'none', cursor: 'pointer', padding: 0,
            display: 'flex', alignItems: 'center', gap: '4px',
            fontSize: '13px', color: C.ink2,
          }}
        >
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
            <path d="M19 12H5M12 19l-7-7 7-7"/>
          </svg>
          Development
        </button>
        <span style={{ fontSize: '13px', color: C.ink3 }}>
          {qIndex + 1} of {QUESTIONS.length}
        </span>
      </div>

      {/* Progress bar */}
      <div style={{
        flexShrink: 0, margin: '16px 24px 0',
        height: '2px', backgroundColor: C.edge, borderRadius: '2px', overflow: 'hidden',
      }}>
        <div style={{
          height: '100%', borderRadius: '2px',
          backgroundColor: C.coral,
          width: `${((qIndex + (phase === 'feedback' ? 1 : 0)) / QUESTIONS.length) * 100}%`,
          transition: 'width 0.35s ease',
        }} />
      </div>

      {/* Content */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '24px 24px 16px' }}>

        {/* Question type label */}
        <div style={{ marginBottom: '20px' }}>
          <span style={{
            fontSize: '10px', fontWeight: 600, letterSpacing: '0.1em',
            textTransform: 'uppercase', color: C.coral,
          }}>
            {q.type}
          </span>
          <span style={{ fontSize: '10px', color: C.ink3, marginLeft: '6px' }}>
            — {q.typeDesc}
          </span>
        </div>

        {/* Question */}
        <h2 style={{
          fontFamily: C.serif, fontSize: '20px', fontWeight: 600,
          color: C.ink, letterSpacing: '-0.02em', lineHeight: 1.35,
          marginBottom: '24px',
        }}>
          {q.question}
        </h2>

        {/* Options */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', marginBottom: '24px' }}>
          {q.options.map((opt, i) => {
            const isSelected = selected === i;
            const showResult = phase === 'feedback';
            const isCorrectOption = i === q.correct;
            const isWrongSelected = showResult && isSelected && !isCorrectOption;
            const isCorrectReveal = showResult && isCorrectOption;

            let bg = C.panel;
            let borderColor = C.edge;
            let textColor = C.ink;

            if (showResult) {
              if (isCorrectReveal) { bg = C.successTint; borderColor = C.successGreen; textColor = C.successGreen; }
              else if (isWrongSelected) { bg = C.coralTint; borderColor = C.coral; textColor = C.coral; }
              else { bg = C.fog; textColor = C.ink3; borderColor = C.edge; }
            } else if (isSelected) {
              bg = C.ink; borderColor = C.ink; textColor = '#fff';
            }

            return (
              <button
                key={i}
                onClick={() => phase === 'question' && setSelected(i)}
                disabled={phase === 'feedback'}
                style={{
                  display: 'flex', alignItems: 'flex-start', gap: '12px',
                  padding: '13px 16px', borderRadius: '12px',
                  backgroundColor: bg, border: `1.5px solid ${borderColor}`,
                  cursor: phase === 'question' ? 'pointer' : 'default',
                  textAlign: 'left', transition: 'background 0.12s, border-color 0.12s',
                }}
              >
                <span style={{
                  width: '22px', height: '22px', borderRadius: '50%', flexShrink: 0,
                  border: `1.5px solid ${showResult ? 'transparent' : (isSelected ? '#fff' : C.edge)}`,
                  backgroundColor: showResult ? 'transparent' : (isSelected ? 'rgba(255,255,255,0.2)' : 'transparent'),
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: '11px', fontWeight: 600, color: isSelected && !showResult ? '#fff' : textColor,
                }}>
                  {showResult
                    ? (isCorrectReveal
                        ? <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke={C.successGreen} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                        : isWrongSelected
                          ? <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke={C.coral} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                          : String.fromCharCode(65 + i))
                    : String.fromCharCode(65 + i)}
                </span>
                <span style={{
                  fontSize: '14px', lineHeight: 1.45, fontFamily: C.sans,
                  color: textColor, fontWeight: isSelected && !showResult ? 500 : 400,
                }}>
                  {opt}
                </span>
              </button>
            );
          })}
        </div>

        {/* Feedback */}
        {phase === 'feedback' && (
          <div style={{
            backgroundColor: isCorrect ? C.successTint : C.coralTint,
            borderRadius: '14px', padding: '16px 18px',
            borderLeft: `3px solid ${isCorrect ? C.successGreen : C.coral}`,
          }}>
            <p style={{
              fontSize: '12px', fontWeight: 600,
              color: isCorrect ? C.successGreen : C.coral,
              marginBottom: '8px', letterSpacing: '0.04em',
            }}>
              {isCorrect ? 'Correct' : 'Not quite'}
            </p>
            <p style={{ fontSize: '13px', color: C.ink, lineHeight: 1.55, marginBottom: '10px' }}>
              {isCorrect ? q.feedback.correct : q.feedback.distractor}
            </p>
            {!isCorrect && (
              <p style={{ fontSize: '12px', color: C.ink2, lineHeight: 1.5 }}>
                {q.feedback.correct}
              </p>
            )}
          </div>
        )}
      </div>

      {/* Bottom action */}
      <div style={{
        flexShrink: 0, padding: '12px 24px 36px',
        borderTop: `1px solid ${C.edge}`,
        backgroundColor: C.ground,
      }}>
        {phase === 'question' ? (
          <button
            onClick={submit}
            disabled={selected === null}
            style={{
              width: '100%', padding: '15px',
              backgroundColor: selected !== null ? C.ink : C.edge,
              color: selected !== null ? '#fff' : C.ink3,
              border: 'none', borderRadius: '14px',
              fontSize: '15px', fontWeight: 600, fontFamily: C.sans,
              cursor: selected !== null ? 'pointer' : 'default',
              transition: 'background 0.15s, color 0.15s',
            }}
          >
            Submit answer
          </button>
        ) : (
          <button
            onClick={advance}
            style={{
              width: '100%', padding: '15px',
              backgroundColor: C.ink, color: '#fff',
              border: 'none', borderRadius: '14px',
              fontSize: '15px', fontWeight: 600, fontFamily: C.sans,
              cursor: 'pointer',
            }}
          >
            {qIndex < QUESTIONS.length - 1 ? 'Next question' : 'See result'}
          </button>
        )}
      </div>
    </div>
  );
}
