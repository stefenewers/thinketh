import { useState } from 'react';
import BottomNav from '../components/BottomNav';
import type { ScreenProps } from '../types';
import logoColor from '../imports/ChatGPT_Image_Sep_22__2026_at_11_27_38_AM__1_.png';
import featuredImg from '../imports/ChatGPT_Image_Sep_22__2026_at_11_27_38_AM__2_.png';
import KnowledgeAtlas from '../components/KnowledgeAtlas';

const C = {
  coral: '#C0553A',
  coralTint: '#F7EAE6',
  ground: '#F6F5F2',
  panel: '#FFFFFF',
  ink: '#1A1918',
  ink2: '#6B6560',
  ink3: '#A09A93',
  fog: '#EEEAE4',
  edge: '#E6E2DA',
  serif: "'Playfair Display', Georgia, serif",
  sans: "'Inter', system-ui, sans-serif",
};


const secondaryDevs = [
  {
    source: 'GOOGLE DEEPMIND',
    importance: 'Major',
    isMajor: true,
    time: '5h ago',
    readTime: '3 min',
    title: 'Gemini 2.5 Pro goes natively multimodal',
    delta: 'Updates your model: LLMs no longer process modalities separately — they can reason across all of them simultaneously.',
  },
  {
    source: 'META AI',
    importance: 'Notable',
    isMajor: false,
    time: '8h ago',
    readTime: '4 min',
    title: 'Llama 3.1 adds structured toolkit for real-world agents',
    delta: 'Extends your model: open-source agents now have a standard toolkit for computer use and web browsing.',
  },
  {
    source: 'OPENAI',
    importance: 'Notable',
    isMajor: false,
    time: '11h ago',
    readTime: '2 min',
    title: 'o3-mini achieves top scores on math and coding benchmarks',
    delta: 'Confirms a pattern: smaller reasoning-tuned models can match larger general models on structured tasks.',
  },
  {
    source: 'DEEPMIND',
    importance: 'Emerging',
    isMajor: false,
    time: '14h ago',
    readTime: '5 min',
    title: 'AlphaProof demonstrates formal mathematical reasoning at olympiad level',
    delta: 'Adjacent to your interests in reasoning models — formal proof search is now entering practical range.',
  },
];

const FILTER_BREAKDOWN = [
  {
    count: '68',
    label: 'Duplicate reports',
    def: 'Multiple sources covering the same event. Thinketh surfaces the highest-quality version only.',
  },
  {
    count: '31',
    label: 'Low-signal opinions',
    def: 'Commentary that interprets or reacts to events without adding new facts or evidence.',
  },
  {
    count: '22',
    label: 'Concepts already understood',
    def: 'Developments that fall entirely within what your Knowledge Atlas already represents as established.',
  },
  {
    count: '15',
    label: 'Minor updates',
    def: 'Incremental changes that extend a known pattern but do not require a mental-model update.',
  },
  {
    count: '7',
    label: 'Low-confidence claims',
    def: 'Reports lacking sufficient corroboration or primary sources to meet Thinketh\'s evidence threshold.',
  },
];

export default function Today({ onNavigate, activeTab, onTabChange }: ScreenProps) {
  const [skippedExpanded, setSkippedExpanded] = useState(false);

  return (
    <div className="flex flex-col h-full" style={{ backgroundColor: C.ground }}>
      <div className="flex-1 overflow-y-auto pb-4">

        {/* ── Hero ─────────────────────────────────────────── */}
        <div style={{ position: 'relative', overflow: 'hidden', padding: '40px 24px 44px' }}>

          {/* Atlas crop — right-side background */}
          <div style={{
            position: 'absolute', right: 0, top: 0, bottom: 0, width: '58%',
            pointerEvents: 'none', overflow: 'hidden',
          }}>
            <KnowledgeAtlas
              mode="mini"
              showNewNode={true}
              style={{ position: 'absolute', inset: '-20px', opacity: 0.32 }}
            />
            <div style={{
              position: 'absolute', inset: 0,
              background: `linear-gradient(to right, ${C.ground} 0%, ${C.ground}cc 20%, transparent 65%)`,
            }} />
          </div>

          <div style={{ position: 'relative', zIndex: 1 }}>
            {/* Wordmark + avatar */}
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '36px' }}>
              <img src={logoColor} alt="thinketh" style={{ height: '22px', width: 'auto', display: 'block' }} />
              <div style={{
                width: '30px', height: '30px', borderRadius: '50%',
                backgroundColor: C.edge, display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                <span style={{ fontSize: '11px', fontWeight: 600, color: C.ink2, fontFamily: C.sans }}>JS</span>
              </div>
            </div>

            {/* Date */}
            <p style={{
              fontSize: '11px', letterSpacing: '0.12em', textTransform: 'uppercase',
              fontWeight: 500, color: C.ink3, fontFamily: C.sans, marginBottom: '12px',
            }}>
              Tuesday, September 22
            </p>

            {/* Headline */}
            <h1 style={{
              fontFamily: C.serif, fontSize: '34px', lineHeight: 1.14,
              letterSpacing: '-0.02em', color: C.ink, marginBottom: '14px',
              fontWeight: 600, maxWidth: '70%',
            }}>
              You missed 7 things worth knowing.
            </h1>

            <p style={{
              fontSize: '14px', color: C.ink3, fontFamily: C.sans,
              marginBottom: '28px', maxWidth: '70%',
            }}>
              3 are major. Estimated catch-up: 11 minutes.
            </p>

            {/* CTA + tagline row */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
              <button
                onClick={() => onNavigate('detail')}
                style={{
                  backgroundColor: C.ink, color: '#FFFFFF',
                  fontFamily: C.sans, fontWeight: 500, fontSize: '14px',
                  padding: '11px 22px', borderRadius: '100px',
                  letterSpacing: '-0.01em', border: 'none', cursor: 'pointer',
                  display: 'inline-flex', alignItems: 'center', gap: '7px',
                  flexShrink: 0,
                }}
              >
                Catch me up
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.3" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M5 12h14M12 5l7 7-7 7"/>
                </svg>
              </button>

              <p style={{
                fontSize: '11px', color: C.ink3, fontFamily: C.sans, lineHeight: 1.7, fontWeight: 400,
                letterSpacing: '0.04em',
              }}>
                A calmer way<br />to stay ahead
              </p>
            </div>
          </div>
        </div>

        {/* ── Featured Development ─────────────────────────── */}
        <div style={{ padding: '0 16px', marginBottom: '10px' }}>
          <div
            onClick={() => onNavigate('detail')}
            style={{
              backgroundColor: C.panel, borderRadius: '20px', overflow: 'hidden',
              cursor: 'pointer',
              boxShadow: '0 2px 12px rgba(0,0,0,0.07), 0 0 0 1px rgba(0,0,0,0.04)',
            }}
          >
            <div style={{ padding: '18px 18px 0' }}>
              {/* Source row — 2-line layout */}
              <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: '14px' }}>
                <div>
                  <p style={{
                    fontSize: '10px', letterSpacing: '0.12em', textTransform: 'uppercase',
                    fontWeight: 700, color: C.ink2, fontFamily: C.sans, marginBottom: '4px',
                  }}>
                    Anthropic
                  </p>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
                    <span style={{
                      width: '6px', height: '6px', borderRadius: '50%',
                      backgroundColor: C.coral, display: 'inline-block', flexShrink: 0,
                    }} />
                    <span style={{ fontSize: '10px', color: C.ink3, fontFamily: C.sans, fontWeight: 500 }}>
                      HIGH IMPACT · 2h ago
                    </span>
                  </div>
                </div>
                {/* Impact badge */}
                <div style={{
                  backgroundColor: C.coralTint, borderRadius: '6px', padding: '5px 10px',
                  flexShrink: 0,
                }}>
                  <span style={{ fontSize: '11px', color: C.coral, fontFamily: C.sans, fontWeight: 600, letterSpacing: '0.02em' }}>Major development</span>
                </div>
              </div>

              {/* Headline + thumbnail */}
              <div style={{ display: 'flex', gap: '14px', marginBottom: '10px' }}>
                <h2 style={{
                  fontFamily: C.serif, fontSize: '19px', lineHeight: 1.25,
                  color: C.ink, fontWeight: 600, flex: 1, letterSpacing: '-0.01em',
                }}>
                  Anthropic expands long-term agent memory
                </h2>
                <div style={{
                  flexShrink: 0, width: '84px', height: '84px',
                  borderRadius: '10px', overflow: 'hidden', backgroundColor: C.fog,
                }}>
                  <img
                    src={featuredImg}
                    alt="Build more capable agents"
                    style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }}
                  />
                </div>
              </div>

              {/* Summary */}
              <p style={{
                fontSize: '13px', color: C.ink2, fontFamily: C.sans,
                lineHeight: 1.5, marginBottom: '16px',
              }}>
                Anthropic introduced a persistent memory system for Claude, allowing agents to retain context across sessions, tools, and longer time horizons.
              </p>
            </div>

            {/* Why this matters */}
            <div style={{
              margin: '0 10px 10px',
              backgroundColor: C.fog, borderRadius: '12px', padding: '12px 14px',
            }}>
              <div style={{ display: 'flex', alignItems: 'flex-start', gap: '9px' }}>
                <span style={{ fontSize: '15px', lineHeight: 1, marginTop: '1px', flexShrink: 0 }}>✦</span>
                <div>
                  <p style={{ fontSize: '12px', fontWeight: 600, color: C.ink, fontFamily: C.sans, marginBottom: '3px' }}>
                    Why this matters to you
                  </p>
                  <p style={{ fontSize: '12px', color: C.ink2, fontFamily: C.sans, lineHeight: 1.5 }}>
                    You follow agentic AI and developer tools. This could unlock more reliable, autonomous workflows in the tools you use.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* ── Supporting Developments — editorial rows ─────── */}
        <div style={{ padding: '0 24px' }}>
          <div style={{ borderTop: `1px solid ${C.edge}` }}>
            {secondaryDevs.map((dev, i) => (
              <div
                key={i}
                style={{
                  padding: '16px 0',
                  borderBottom: `1px solid ${C.edge}`,
                  cursor: 'pointer',
                }}
              >
                {/* Source + meta row */}
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '6px' }}>
                  <span style={{
                    fontSize: '9px', letterSpacing: '0.1em', textTransform: 'uppercase',
                    fontWeight: 700, color: C.ink3, fontFamily: C.sans,
                  }}>
                    {dev.source}
                  </span>
                  <span style={{ color: C.edge, fontSize: '10px' }}>·</span>
                  {dev.isMajor ? (
                    <span style={{
                      fontSize: '9px', letterSpacing: '0.06em', textTransform: 'uppercase',
                      fontWeight: 600, color: C.coral, fontFamily: C.sans,
                    }}>
                      Major
                    </span>
                  ) : (
                    <span style={{ fontSize: '10px', color: C.ink3, fontFamily: C.sans }}>
                      {dev.importance}
                    </span>
                  )}
                  <span style={{ color: C.edge, fontSize: '10px' }}>·</span>
                  <span style={{ fontSize: '10px', color: C.ink3, fontFamily: C.sans }}>
                    {dev.readTime}
                  </span>
                </div>

                {/* Headline */}
                <p style={{
                  fontSize: '15px', color: C.ink, fontFamily: C.sans,
                  lineHeight: 1.38, fontWeight: 500, marginBottom: '6px',
                }}>
                  {dev.title}
                </p>

                {/* Knowledge delta */}
                <p style={{
                  fontSize: '12px', color: C.ink3, fontFamily: C.sans,
                  lineHeight: 1.45, fontStyle: 'italic',
                }}>
                  {dev.delta}
                </p>
              </div>
            ))}

            {/* Remaining count */}
            <div style={{
              padding: '14px 0',
              display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            }}>
              <span style={{ fontSize: '12px', color: C.ink3, fontFamily: C.sans }}>
                3 more developments
              </span>
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke={C.ink3} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                <polyline points="6 9 12 15 18 9"/>
              </svg>
            </div>
          </div>
        </div>

        {/* ── Knowledge Atlas preview ─────────────────────── */}
        <div style={{ padding: '16px 16px 0' }}>
          <div
            onClick={() => onNavigate('library')}
            style={{
              position: 'relative', borderRadius: '20px', overflow: 'hidden',
              height: '110px', backgroundColor: C.ink, cursor: 'pointer',
              marginBottom: '4px',
            }}
          >
            {/* Atlas behind */}
            <div style={{ position: 'absolute', inset: 0 }}>
              <KnowledgeAtlas
                mode="mini"
                showNewNode={true}
                style={{ position: 'absolute', inset: 0, opacity: 0.45 }}
              />
              <div style={{
                position: 'absolute', inset: 0,
                background: 'linear-gradient(to right, rgba(26,25,24,0.88) 40%, rgba(26,25,24,0.55) 100%)',
              }} />
            </div>

            {/* Text */}
            <div style={{
              position: 'absolute', left: '18px', bottom: '16px', right: '48px',
            }}>
              <p style={{
                fontSize: '10px', letterSpacing: '0.12em', textTransform: 'uppercase',
                color: 'rgba(255,255,255,0.5)', fontFamily: C.sans, fontWeight: 500, marginBottom: '4px',
              }}>
                Your knowledge changed today
              </p>
              <p style={{ fontSize: '13px', color: '#fff', fontFamily: C.sans, fontWeight: 500, lineHeight: 1.4 }}>
                Persistent Memory connected to Agent Memory, Claude, and Long-running Agents.
              </p>
            </div>

            {/* Arrow */}
            <div style={{
              position: 'absolute', right: '14px', top: '50%',
              transform: 'translateY(-50%)',
            }}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.5)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M5 12h14M12 5l7 7-7 7"/>
              </svg>
            </div>
          </div>
          <p style={{
            fontSize: '11px', color: C.ink3, fontFamily: C.sans,
            textAlign: 'center', padding: '4px 0 8px',
          }}>
            View in your Knowledge Atlas
          </p>
        </div>

        {/* ── Filtered items ───────────────────────────────── */}
        <div style={{ padding: '0 24px' }}>
          <button
            onClick={() => setSkippedExpanded(!skippedExpanded)}
            style={{
              background: 'none', border: 'none', width: '100%',
              display: 'flex', alignItems: 'center', justifyContent: 'space-between',
              padding: '16px 0 14px', cursor: 'pointer',
            }}
          >
            <span style={{ fontSize: '12px', color: C.ink3, fontFamily: C.sans }}>
              143 items filtered for you
            </span>
            <svg
              width="13" height="13" viewBox="0 0 24 24" fill="none"
              stroke={C.ink3} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"
              style={{ transition: 'transform 0.2s' }}
            >
              <polyline points="6 9 12 15 18 9"/>
            </svg>
          </button>

        </div>

        <div style={{ height: '12px' }} />
      </div>

      <BottomNav activeTab={activeTab} onTabChange={onTabChange} onNavigate={onNavigate} />

      {/* ── Filter transparency bottom sheet ─────────────── */}
      {skippedExpanded && (
        <>
          {/* Backdrop */}
          <div
            onClick={() => setSkippedExpanded(false)}
            style={{
              position: 'absolute', inset: 0, zIndex: 40,
              backgroundColor: 'rgba(26,25,24,0.4)',
            }}
          />
          {/* Sheet */}
          <div style={{
            position: 'absolute', bottom: 0, left: 0, right: 0, zIndex: 50,
            backgroundColor: C.panel,
            borderRadius: '24px 24px 0 0',
            padding: '0 0 36px',
            boxShadow: '0 -4px 32px rgba(0,0,0,0.12)',
          }}>
            {/* Handle */}
            <div style={{
              width: '36px', height: '4px', borderRadius: '2px',
              backgroundColor: C.edge,
              margin: '12px auto 20px',
            }} />

            <div style={{ padding: '0 24px' }}>
              <div style={{ marginBottom: '18px' }}>
                <h3 style={{
                  fontFamily: C.serif, fontSize: '20px', fontWeight: 600,
                  color: C.ink, letterSpacing: '-0.02em', marginBottom: '6px',
                }}>
                  How Thinketh filtered today
                </h3>
                <p style={{ fontSize: '13px', color: C.ink2, fontFamily: C.sans, lineHeight: 1.5 }}>
                  143 items reviewed. 7 passed Thinketh's relevance and quality checks.
                </p>
              </div>

              <div style={{ display: 'flex', flexDirection: 'column', gap: '0' }}>
                {FILTER_BREAKDOWN.map((item, i) => (
                  <div
                    key={item.label}
                    style={{
                      padding: '14px 0',
                      borderTop: i === 0 ? `1px solid ${C.edge}` : `1px solid ${C.edge}`,
                    }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: '4px' }}>
                      <span style={{ fontSize: '13px', color: C.ink, fontFamily: C.sans, fontWeight: 500 }}>
                        {item.label}
                      </span>
                      <span style={{
                        fontSize: '13px', color: C.ink3, fontFamily: C.sans, fontWeight: 500,
                        marginLeft: '12px', flexShrink: 0,
                      }}>
                        {item.count}
                      </span>
                    </div>
                    <p style={{ fontSize: '12px', color: C.ink3, fontFamily: C.sans, lineHeight: 1.5 }}>
                      {item.def}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
