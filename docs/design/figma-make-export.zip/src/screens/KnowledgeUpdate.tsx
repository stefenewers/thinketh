import { useState, useEffect } from 'react';
import type { Screen } from '../types';

interface Props {
  onNavigate: (screen: Screen) => void;
}

const C = {
  coral: '#C0553A',
  coralTint: '#F7EAE6',
  ground: '#F6F5F2',
  panel: '#FFFFFF',
  ink: '#1A1918',
  ink2: '#6B6560',
  ink3: '#A09A93',
  fog: '#EEEAE4',
  edge: '#E6E2DA',
  warmTint: '#F4EFE7',
  sans: "'Inter', system-ui, sans-serif",
  serif: "'Playfair Display', Georgia, serif",
};

// Sub-cluster nodes for animation (local coords, centered for 280x260 viewBox)
const ANIM_NODES = [
  { id: 'agent-arch',  x: 96,  y: 68,  r: 13, label: 'Agent Architecture', state: 'established' as const },
  { id: 'agent-memory',x: 80,  y: 128, r: 10, label: 'Agent Memory',        state: 'new'         as const },
  { id: 'tool-use',    x: 36,  y: 140, r: 8,  label: 'Tool Use',            state: 'established' as const },
  { id: 'long-running',x: 134, y: 150, r: 8,  label: 'Long-running Agents', state: 'developing'  as const },
  { id: 'claude',      x: 172, y: 82,  r: 9,  label: 'Claude',              state: 'established' as const },
  { id: 'foundation',  x: 220, y: 62,  r: 12, label: 'Foundation Models',   state: 'established' as const },
];

const NEW_NODE = { id: 'persistent-memory', x: 136, y: 108, r: 9, label: 'Persistent Memory', state: 'new' as const };

// After nodes shift apart (step >= 2): delta offsets
const SHIFT: Record<string, [number, number]> = {
  'agent-memory': [-8, 6],
  'tool-use': [-6, 4],
  'long-running': [8, 6],
  'claude': [6, -4],
};

const STATE_FILL: Record<string, string> = {
  established: '#1A1918',
  developing: '#6B6560',
  new: '#C0553A',
  emerging: '#A09A93',
};
const STATE_OPQ: Record<string, number> = {
  established: 0.88, developing: 0.72, new: 1.0, emerging: 0.46,
};

type Phase = 'reading' | 'animating';

export default function KnowledgeUpdate({ onNavigate }: Props) {
  const [phase, setPhase] = useState<Phase>('reading');
  const [visibleCards, setVisibleCards] = useState(0); // 0=none, 1=before, 2=+new, 3=+changes
  const [animStep, setAnimStep] = useState(0);

  // Stagger the reading cards
  useEffect(() => {
    const t1 = setTimeout(() => setVisibleCards(1), 300);
    const t2 = setTimeout(() => setVisibleCards(2), 900);
    const t3 = setTimeout(() => setVisibleCards(3), 1500);
    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3); };
  }, []);

  // Atlas animation sequence
  useEffect(() => {
    if (phase !== 'animating') return;
    // step 1: nodes shift (600ms)
    const t1 = setTimeout(() => setAnimStep(2), 600);
    // step 2: new node fades in (1200ms)
    const t2 = setTimeout(() => setAnimStep(3), 1200);
    // step 3: first connection draws (1800ms)
    const t3 = setTimeout(() => setAnimStep(4), 1800);
    // step 4: second+third connections (2400ms)
    const t4 = setTimeout(() => setAnimStep(5), 2400);
    // step 5: glow (2800ms)
    const t5 = setTimeout(() => setAnimStep(6), 2800);
    // step 6: "mental model updated" message (3400ms)
    const t6 = setTimeout(() => setAnimStep(7), 3400);
    // step 7: supporting text (4000ms)
    const t7 = setTimeout(() => setAnimStep(8), 4000);
    // step 8: continue button (4600ms)
    const t8 = setTimeout(() => setAnimStep(9), 4600);
    return () => { [t1,t2,t3,t4,t5,t6,t7,t8].forEach(clearTimeout); };
  }, [phase]);

  const getNodePos = (node: typeof ANIM_NODES[0], step: number) => {
    const shift = step >= 2 ? (SHIFT[node.id] ?? [0, 0]) : [0, 0];
    return { x: node.x + shift[0], y: node.y + shift[1] };
  };

  // Edge connection line component
  const AnimEdge = ({
    fromId, toId, isNew = false, drawStep, currentStep,
  }: {
    fromId: string; toId: string; isNew?: boolean; drawStep: number; currentStep: number;
  }) => {
    const allNodes = [...ANIM_NODES, NEW_NODE];
    const from = allNodes.find(n => n.id === fromId);
    const to = allNodes.find(n => n.id === toId);
    if (!from || !to) return null;
    const fp = fromId === NEW_NODE.id ? { x: NEW_NODE.x, y: NEW_NODE.y }
      : getNodePos(from as typeof ANIM_NODES[0], currentStep);
    const tp = toId === NEW_NODE.id ? { x: NEW_NODE.x, y: NEW_NODE.y }
      : getNodePos(to as typeof ANIM_NODES[0], currentStep);
    const drawn = currentStep >= drawStep;
    return (
      <path
        d={`M ${fp.x} ${fp.y} L ${tp.x} ${tp.y}`}
        stroke={isNew ? C.coral : '#C8C3BB'}
        strokeWidth={isNew ? 2 : 1.2}
        fill="none"
        opacity={isNew ? 0.9 : 0.55}
        strokeLinecap="round"
        pathLength={isNew ? 1 : undefined}
        strokeDasharray={isNew ? 1 : undefined}
        strokeDashoffset={isNew ? (drawn ? 0 : 1) : undefined}
        style={isNew ? { transition: 'stroke-dashoffset 0.6s ease' } : undefined}
      />
    );
  };

  if (phase === 'animating') {
    const showNew = animStep >= 3;
    const showGlow = animStep >= 6;

    return (
      <div style={{
        display: 'flex', flexDirection: 'column', height: '100%',
        backgroundColor: C.ground, overflow: 'hidden',
      }}>
        {/* Header */}
        <div style={{ padding: '44px 24px 8px' }}>
          <p style={{
            fontSize: '10px', letterSpacing: '0.14em', textTransform: 'uppercase',
            color: C.ink3, fontFamily: C.sans, fontWeight: 500, marginBottom: '4px',
          }}>
            Agent Memory
          </p>
          <p style={{
            fontFamily: C.serif, fontSize: '20px', fontWeight: 600,
            color: C.ink, lineHeight: 1.2,
          }}>
            Watching your knowledge connect.
          </p>
        </div>

        {/* Atlas animation SVG */}
        <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '8px 24px 0' }}>
          <div style={{ position: 'relative', width: '100%', maxWidth: '300px' }}>
            <svg viewBox="0 0 280 220" style={{ width: '100%', display: 'block' }} preserveAspectRatio="xMidYMid meet">

              {/* Glow behind new node */}
              {showGlow && (
                <circle
                  cx={NEW_NODE.x} cy={NEW_NODE.y} r="30"
                  fill={C.coral} opacity="0"
                >
                  <animate attributeName="opacity" values="0;0.08;0.06" dur="1.2s" fill="freeze" />
                  <animate attributeName="r" values="15;38;32" dur="1.2s" fill="freeze" />
                </circle>
              )}

              {/* Static edges */}
              <AnimEdge fromId="agent-arch" toId="agent-memory" drawStep={0} currentStep={animStep} />
              <AnimEdge fromId="agent-arch" toId="tool-use" drawStep={0} currentStep={animStep} />
              <AnimEdge fromId="agent-arch" toId="long-running" drawStep={0} currentStep={animStep} />
              <AnimEdge fromId="foundation" toId="claude" drawStep={0} currentStep={animStep} />
              <AnimEdge fromId="claude" toId="agent-memory" drawStep={0} currentStep={animStep} />

              {/* New animated connections */}
              <AnimEdge fromId="agent-memory" toId="persistent-memory" isNew drawStep={4} currentStep={animStep} />
              <AnimEdge fromId="long-running" toId="persistent-memory" isNew drawStep={5} currentStep={animStep} />
              <AnimEdge fromId="claude" toId="persistent-memory" isNew drawStep={5} currentStep={animStep} />

              {/* Existing nodes (shifted at step 2) */}
              {ANIM_NODES.map(node => {
                const pos = getNodePos(node, animStep);
                return (
                  <g key={node.id} style={{ transition: 'transform 0.5s ease' }}>
                    <circle
                      cx={pos.x} cy={pos.y} r={node.r}
                      fill={STATE_FILL[node.state]}
                      opacity={STATE_OPQ[node.state]}
                      style={{ transition: 'cx 0.5s ease, cy 0.5s ease' }}
                    />
                    {node.state === 'new' && (
                      <circle cx={pos.x} cy={pos.y} r={node.r + 3} fill="none" stroke={C.coral} strokeWidth="0.8">
                        <animate attributeName="r" values={`${node.r+2};${node.r+10};${node.r+2}`} dur="2.8s" repeatCount="indefinite" />
                        <animate attributeName="opacity" values="0.45;0;0.45" dur="2.8s" repeatCount="indefinite" />
                      </circle>
                    )}
                  </g>
                );
              })}

              {/* New node (fades in at step 3) */}
              {showNew && (
                <g>
                  <circle cx={NEW_NODE.x} cy={NEW_NODE.y} r={NEW_NODE.r + 4} fill="none" stroke={C.coral} strokeWidth="0.8">
                    <animate attributeName="r" values={`${NEW_NODE.r+2};${NEW_NODE.r+12};${NEW_NODE.r+2}`} dur="2.8s" repeatCount="indefinite" />
                    <animate attributeName="opacity" values="0.45;0;0.45" dur="2.8s" repeatCount="indefinite" />
                  </circle>
                  <circle cx={NEW_NODE.x} cy={NEW_NODE.y} r={NEW_NODE.r} fill={C.coral} opacity="0">
                    <animate attributeName="opacity" values="0;1" dur="0.5s" fill="freeze" />
                  </circle>
                </g>
              )}

              {/* Labels */}
              {ANIM_NODES.filter(n => n.r >= 9).map(node => {
                const pos = getNodePos(node, animStep);
                return (
                  <text
                    key={`l-${node.id}`}
                    x={pos.x} y={pos.y + node.r + 9}
                    textAnchor="middle" fontSize="6"
                    fill={node.state === 'new' ? C.coral : '#6B6560'}
                    fontFamily="Inter, system-ui, sans-serif"
                    opacity="0.8"
                    style={{ transition: 'x 0.5s ease, y 0.5s ease' }}
                  >
                    {node.label.split(' ')[0]}
                  </text>
                );
              })}

              {showNew && (
                <text
                  x={NEW_NODE.x} y={NEW_NODE.y + NEW_NODE.r + 9}
                  textAnchor="middle" fontSize="6"
                  fill={C.coral} fontFamily="Inter, system-ui, sans-serif" opacity="0"
                >
                  Persistent Memory
                  <animate attributeName="opacity" values="0;0.85" dur="0.5s" fill="freeze" begin="0.3s" />
                </text>
              )}
            </svg>
          </div>
        </div>

        {/* Messages */}
        <div style={{ padding: '8px 28px 0', minHeight: '80px' }}>
          <p
            style={{
              fontFamily: C.serif, fontSize: '22px', fontWeight: 600, color: C.ink,
              lineHeight: 1.22, marginBottom: '8px', textAlign: 'center',
              transition: 'opacity 0.6s ease, transform 0.6s ease',
              opacity: animStep >= 7 ? 1 : 0,
              transform: animStep >= 7 ? 'translateY(0)' : 'translateY(8px)',
            }}
          >
            Your mental model was updated.
          </p>
          <p
            style={{
              fontSize: '13px', color: C.ink2, fontFamily: C.sans, lineHeight: 1.5,
              textAlign: 'center',
              transition: 'opacity 0.6s ease',
              opacity: animStep >= 8 ? 1 : 0,
            }}
          >
            Persistent Memory is now connected to 3 concepts you already understand.
          </p>
        </div>

        {/* Continue */}
        <div style={{ padding: '20px 24px 36px' }}>
          <button
            onClick={() => onNavigate('today-updated')}
            style={{
              width: '100%', backgroundColor: C.ink, color: '#fff',
              fontFamily: C.sans, fontWeight: 500, fontSize: '15px',
              padding: '14px', borderRadius: '100px', border: 'none', cursor: 'pointer',
              transition: 'opacity 0.5s ease, transform 0.5s ease',
              opacity: animStep >= 9 ? 1 : 0,
              transform: animStep >= 9 ? 'translateY(0)' : 'translateY(8px)',
            }}
          >
            Continue
          </button>
        </div>
      </div>
    );
  }

  // ── Phase: reading ──────────────────────────────────────────────────────────

  return (
    <div style={{
      display: 'flex', flexDirection: 'column', height: '100%',
      backgroundColor: C.ground, overflow: 'hidden',
    }}>
      <div style={{ flex: 1, overflowY: 'auto', padding: '44px 24px 0' }}>

        {/* Label */}
        <p style={{
          fontSize: '10px', letterSpacing: '0.14em', textTransform: 'uppercase',
          color: C.ink3, fontFamily: C.sans, fontWeight: 500, marginBottom: '10px',
          textAlign: 'center',
        }}>
          Knowledge Updated
        </p>

        {/* Tag */}
        <div style={{ display: 'flex', justifyContent: 'center', marginBottom: '12px' }}>
          <span style={{
            fontSize: '12px', backgroundColor: C.coralTint, color: C.coral,
            padding: '5px 14px', borderRadius: '100px', fontFamily: C.sans, fontWeight: 500,
          }}>
            Agent Memory
          </span>
        </div>

        {/* Headline */}
        <h1 style={{
          fontFamily: C.serif, fontSize: '30px', fontWeight: 600,
          color: C.ink, lineHeight: 1.18, letterSpacing: '-0.02em',
          textAlign: 'center', marginBottom: '40px',
        }}>
          Your understanding deepened.
        </h1>

        {/* Before card */}
        <div
          style={{
            backgroundColor: C.fog, borderRadius: '16px', padding: '18px 20px',
            marginBottom: '8px',
            transition: 'opacity 0.5s ease, transform 0.5s ease',
            opacity: visibleCards >= 1 ? 1 : 0,
            transform: visibleCards >= 1 ? 'translateY(0)' : 'translateY(10px)',
          }}
        >
          <p style={{
            fontSize: '9px', letterSpacing: '0.14em', textTransform: 'uppercase',
            color: C.ink3, fontFamily: C.sans, fontWeight: 600, marginBottom: '10px',
          }}>
            Your existing mental model
          </p>
          <p style={{
            fontFamily: C.serif, fontSize: '17px', fontWeight: 400,
            color: C.ink2, lineHeight: 1.48, fontStyle: 'italic',
          }}>
            "Agents can use tools and retain context during an active session."
          </p>
        </div>

        {/* New understanding card */}
        <div
          style={{
            backgroundColor: C.coralTint, borderRadius: '16px', padding: '18px 20px',
            marginBottom: '8px', border: `1px solid rgba(192,85,58,0.15)`,
            transition: 'opacity 0.5s ease, transform 0.5s ease',
            opacity: visibleCards >= 2 ? 1 : 0,
            transform: visibleCards >= 2 ? 'translateY(0)' : 'translateY(10px)',
          }}
        >
          <p style={{
            fontSize: '9px', letterSpacing: '0.14em', textTransform: 'uppercase',
            color: C.coral, fontFamily: C.sans, fontWeight: 600, marginBottom: '10px',
          }}>
            New understanding
          </p>
          <p style={{
            fontFamily: C.serif, fontSize: '17px', fontWeight: 600,
            color: C.ink, lineHeight: 1.48,
          }}>
            "Persistent memory allows an agent to retain useful context across separate sessions."
          </p>
        </div>

        {/* What this changes */}
        <div
          style={{
            padding: '18px 4px',
            transition: 'opacity 0.5s ease, transform 0.5s ease',
            opacity: visibleCards >= 3 ? 1 : 0,
            transform: visibleCards >= 3 ? 'translateY(0)' : 'translateY(10px)',
          }}
        >
          <p style={{
            fontSize: '9px', letterSpacing: '0.14em', textTransform: 'uppercase',
            color: C.ink3, fontFamily: C.sans, fontWeight: 600, marginBottom: '10px',
          }}>
            What this changes
          </p>
          <p style={{
            fontFamily: C.serif, fontSize: '18px', fontWeight: 400,
            color: C.ink, lineHeight: 1.44, letterSpacing: '-0.01em',
          }}>
            "An agent can now behave less like an isolated task and more like a persistent software worker."
          </p>
        </div>

        <div style={{ height: '8px' }} />
      </div>

      {/* CTA */}
      <div style={{ padding: '16px 24px 36px', flexShrink: 0 }}>
        <button
          onClick={() => { setPhase('animating'); setAnimStep(1); }}
          style={{
            width: '100%', backgroundColor: C.ink, color: '#fff',
            fontFamily: C.sans, fontWeight: 500, fontSize: '15px',
            padding: '14px', borderRadius: '100px', border: 'none', cursor: 'pointer',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '7px',
            transition: 'opacity 0.5s ease',
            opacity: visibleCards >= 3 ? 1 : 0,
          }}
        >
          See how your knowledge changed
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M5 12h14M12 5l7 7-7 7"/>
          </svg>
        </button>
      </div>
    </div>
  );
}
