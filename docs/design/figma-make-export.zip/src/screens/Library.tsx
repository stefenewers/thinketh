import { useState } from 'react';
import BottomNav from '../components/BottomNav';
import KnowledgeAtlas from '../components/KnowledgeAtlas';
import type { AtlasFilter } from '../components/KnowledgeAtlas';
import LearningQueueView from '../components/LearningQueueView';
import type { ScreenProps } from '../types';

const C = {
  coral: '#C0553A',
  coralTint: '#F7EAE6',
  ground: '#F6F5F2',
  panel: '#FFFFFF',
  ink: '#1A1918',
  ink2: '#6B6560',
  ink3: '#A09A93',
  fog: '#EEEAE4',
  edge: '#E6E2DA',
  sans: "'Inter', system-ui, sans-serif",
  serif: "'Playfair Display', Georgia, serif",
};

type CategoryTab = 'Learning Queue' | 'Storylines' | 'Concepts' | 'Sources';
const TABS: CategoryTab[] = ['Learning Queue', 'Storylines', 'Concepts', 'Sources'];

const storylineEntries = [
  { month: 'May', title: 'Context windows improve significantly across frontier models', isNew: false },
  { month: 'Jun', title: 'External memory architectures gain adoption in agent frameworks', isNew: false },
  { month: 'Aug', title: 'Cross-session retrieval systems mature in production deployments', isNew: false },
  { month: 'Sep', title: 'Native persistent memory arrives via Anthropic API', isNew: true },
];

const concepts = [
  { label: 'Persistent Memory', state: 'Emerging', isNew: true },
  { label: 'Tool Calling', state: 'Established', isNew: false },
  { label: 'Model Context Protocol', state: 'Developing', isNew: false },
  { label: 'Context Window', state: 'Established', isNew: false },
  { label: 'Agent Loop', state: 'Developing', isNew: false },
  { label: 'RAG Architecture', state: 'Developing', isNew: false },
  { label: 'Fine-tuning', state: 'Emerging', isNew: false },
  { label: 'Prompt Engineering', state: 'Established', isNew: false },
];

const stateColor: Record<string, string> = {
  Established: '#1A1918',
  Developing: C.ink2,
  Emerging: C.ink3,
};

export default function Library({ onNavigate, activeTab, onTabChange }: ScreenProps) {
  const [catTab, setCatTab] = useState<CategoryTab>('Learning Queue');
  const [atlasOpen, setAtlasOpen] = useState(false);
  const [atlasFilter, setAtlasFilter] = useState<AtlasFilter>('all');

  const ATLAS_FILTERS: { id: AtlasFilter; label: string }[] = [
    { id: 'all',      label: 'All' },
    { id: 'today',    label: 'Changed today' },
    { id: 'concepts', label: 'Concepts' },
    { id: 'companies',label: 'Companies' },
    { id: 'models',   label: 'Models' },
    { id: 'papers',   label: 'Papers' },
  ];

  return (
    <div className="flex flex-col h-full" style={{ backgroundColor: C.ground }}>

      {/* ── Full-screen Atlas overlay ─────────────────────── */}
      {atlasOpen && (
        <div style={{
          position: 'absolute', inset: 0, zIndex: 30,
          backgroundColor: C.ground,
          display: 'flex', flexDirection: 'column',
        }}>
          {/* Atlas header */}
          <div style={{
            padding: '44px 20px 0',
            flexShrink: 0,
          }}>
            <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: '14px' }}>
              <div>
                <p style={{
                  fontSize: '10px', letterSpacing: '0.13em', textTransform: 'uppercase',
                  color: C.ink3, fontFamily: C.sans, fontWeight: 500, marginBottom: '4px',
                }}>
                  Your Knowledge Atlas
                </p>
                <p style={{ fontSize: '13px', color: C.ink2, fontFamily: C.sans }}>
                  A living map of what you understand.
                </p>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <button
                  onClick={() => onNavigate('desktop-atlas')}
                  style={{
                    background: 'none', border: `1px solid ${C.edge}`, cursor: 'pointer',
                    fontSize: '11px', color: C.ink2, fontFamily: C.sans,
                    display: 'flex', alignItems: 'center', gap: '4px',
                    padding: '5px 10px', borderRadius: '100px',
                  }}
                >
                  <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                    <rect x="2" y="3" width="20" height="14" rx="2" ry="2"/>
                    <line x1="8" y1="21" x2="16" y2="21"/>
                    <line x1="12" y1="17" x2="12" y2="21"/>
                  </svg>
                  Desktop view
                </button>
                <button
                  onClick={() => { setAtlasOpen(false); setAtlasFilter('all'); }}
                  style={{
                    background: 'none', border: 'none', cursor: 'pointer',
                    fontSize: '13px', color: C.ink2, fontFamily: C.sans,
                    display: 'flex', alignItems: 'center', gap: '4px', padding: 0,
                  }}
                >
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M19 12H5M12 19l-7-7 7-7"/>
                  </svg>
                  Library
                </button>
              </div>
            </div>

            {/* Filter chips */}
            <div style={{
              display: 'flex', gap: '6px', overflowX: 'auto',
              paddingBottom: '14px',
            }}>
              {ATLAS_FILTERS.map(f => (
                <button
                  key={f.id}
                  onClick={() => setAtlasFilter(f.id)}
                  style={{
                    flexShrink: 0, padding: '6px 13px', borderRadius: '100px',
                    border: 'none', cursor: 'pointer',
                    fontFamily: C.sans, fontSize: '12px', fontWeight: 500,
                    backgroundColor: atlasFilter === f.id
                      ? (f.id === 'today' ? C.coral : C.ink)
                      : C.panel,
                    color: atlasFilter === f.id ? '#fff' : C.ink2,
                    boxShadow: atlasFilter === f.id ? 'none' : `0 0 0 1px ${C.edge}`,
                    transition: 'background 0.15s, color 0.15s',
                  }}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </div>

          {/* "Changed today" context strip */}
          {atlasFilter === 'today' && (
            <div style={{
              marginLeft: '20px', marginRight: '20px', marginBottom: '10px',
              backgroundColor: C.coralTint, borderRadius: '12px',
              padding: '10px 14px',
              display: 'flex', alignItems: 'flex-start', gap: '8px',
              flexShrink: 0,
            }}>
              <div style={{
                width: '6px', height: '6px', borderRadius: '50%',
                backgroundColor: C.coral, flexShrink: 0, marginTop: '5px',
              }} />
              <div>
                <p style={{ fontSize: '12px', fontWeight: 600, color: C.ink, fontFamily: C.sans, marginBottom: '2px' }}>
                  1 concept updated today
                </p>
                <p style={{ fontSize: '11px', color: C.ink2, fontFamily: C.sans, lineHeight: 1.4 }}>
                  Persistent Memory connected to Agent Memory, Claude, and Long-running Agents.
                </p>
              </div>
            </div>
          )}

          {/* Atlas — fills remaining space */}
          <div style={{ flex: 1, overflow: 'hidden' }}>
            <KnowledgeAtlas
              mode="full"
              showNewNode={true}
              filterMode={atlasFilter}
              style={{ height: '100%' }}
            />
          </div>

          <BottomNav activeTab={activeTab} onTabChange={onTabChange} onNavigate={onNavigate} />
        </div>
      )}

      {/* ── Library content ──────────────────────────────── */}
      <div className="flex-1 overflow-y-auto pb-4">
        <div style={{ padding: '44px 20px 0' }}>

          {/* Header */}
          <h1 style={{
            fontFamily: C.serif, fontSize: '28px', fontWeight: 600,
            letterSpacing: '-0.02em', color: C.ink, lineHeight: 1.2,
            marginBottom: '4px',
          }}>
            Your Knowledge
          </h1>
          <p style={{ fontSize: '14px', color: C.ink3, fontFamily: C.sans, marginBottom: '24px' }}>
            What you understand, and how it's changing.
          </p>

          {/* Knowledge Atlas card */}
          {catTab !== 'Learning Queue' && <button
            onClick={() => setAtlasOpen(true)}
            style={{
              width: '100%', textAlign: 'left',
              backgroundColor: C.ink, borderRadius: '20px', overflow: 'hidden',
              padding: '0', border: 'none', cursor: 'pointer', marginBottom: '20px',
              position: 'relative', display: 'block',
            }}
          >
            {/* Mini atlas preview */}
            <div style={{ height: '130px', position: 'relative', overflow: 'hidden' }}>
              <KnowledgeAtlas
                mode="mini"
                showNewNode={true}
                style={{ position: 'absolute', inset: 0, opacity: 0.55 }}
              />
              {/* Fade to dark overlay */}
              <div style={{
                position: 'absolute', inset: 0,
                background: 'linear-gradient(to bottom, transparent 0%, rgba(26,25,24,0.7) 80%)',
              }} />
            </div>

            {/* Card text */}
            <div style={{ padding: '14px 18px 18px' }}>
              <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between' }}>
                <div>
                  <p style={{
                    fontSize: '10px', letterSpacing: '0.12em', textTransform: 'uppercase',
                    color: 'rgba(255,255,255,0.5)', fontFamily: C.sans, fontWeight: 500, marginBottom: '4px',
                  }}>
                    Your Knowledge Atlas
                  </p>
                  <p style={{ fontSize: '15px', color: '#fff', fontFamily: C.sans, fontWeight: 500 }}>
                    A living map of what you understand.
                  </p>
                </div>
                <div style={{
                  width: '28px', height: '28px', borderRadius: '50%',
                  backgroundColor: 'rgba(255,255,255,0.15)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  flexShrink: 0,
                }}>
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M5 12h14M12 5l7 7-7 7"/>
                  </svg>
                </div>
              </div>
            </div>

            {/* Updated today badge */}
            <div style={{
              position: 'absolute', top: '12px', left: '14px',
              backgroundColor: C.coral, borderRadius: '6px',
              padding: '3px 8px',
              display: 'flex', alignItems: 'center', gap: '4px',
            }}>
              <div style={{
                width: '5px', height: '5px', borderRadius: '50%',
                backgroundColor: 'rgba(255,255,255,0.8)',
              }} />
              <span style={{ fontSize: '10px', color: '#fff', fontFamily: C.sans, fontWeight: 600 }}>
                Updated today
              </span>
            </div>
          </button>}

          {/* Category tabs */}
          <div style={{
            display: 'flex', gap: '7px', overflowX: 'auto',
            paddingBottom: '2px', marginBottom: '18px',
          }}>
            {TABS.map(tab => (
              <button
                key={tab}
                onClick={() => setCatTab(tab)}
                style={{
                  flexShrink: 0, padding: '7px 14px', borderRadius: '100px',
                  border: 'none', cursor: 'pointer',
                  fontFamily: C.sans, fontSize: '12px', fontWeight: 500,
                  backgroundColor: catTab === tab ? C.ink : C.panel,
                  color: catTab === tab ? '#fff' : C.ink2,
                  boxShadow: catTab === tab ? 'none' : `0 0 0 1px ${C.edge}`,
                  transition: 'background 0.15s',
                }}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>

        {/* Tab content */}
        <div style={{ padding: '0 20px' }}>
          {catTab === 'Learning Queue' ? (
            <LearningQueueView onNavigate={onNavigate} />
          ) : catTab === 'Storylines' ? (
            <div
              style={{
                backgroundColor: C.panel, borderRadius: '20px', overflow: 'hidden',
                boxShadow: '0 1px 8px rgba(0,0,0,0.05)',
              }}
            >
              <div style={{ padding: '18px 20px 14px', borderBottom: `1px solid ${C.edge}` }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <div>
                    <p style={{
                      fontSize: '10px', letterSpacing: '0.1em', textTransform: 'uppercase',
                      color: C.ink3, fontFamily: C.sans, marginBottom: '4px',
                    }}>
                      Featured Storyline
                    </p>
                    <h3 style={{
                      fontFamily: C.serif, fontSize: '20px', fontWeight: 600,
                      color: C.ink, marginBottom: '2px',
                    }}>
                      Agent Memory
                    </h3>
                    <p style={{ fontSize: '11px', color: C.ink3, fontFamily: C.sans }}>May 2026 — present</p>
                  </div>
                  <span style={{ fontSize: '10px', color: C.coral, fontFamily: C.sans, fontWeight: 500 }}>4 chapters</span>
                </div>
              </div>

              <div style={{ padding: '16px 20px 6px' }}>
                {storylineEntries.map((entry, i) => (
                  <div key={i} style={{ display: 'flex', gap: '16px', marginBottom: '16px' }}>
                    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', flexShrink: 0 }}>
                      <span style={{ fontSize: '10px', fontWeight: 500, color: C.ink3, fontFamily: C.sans, width: '28px', textAlign: 'center' }}>
                        {entry.month}
                      </span>
                      {i < storylineEntries.length - 1 && (
                        <div style={{ width: '1px', flex: 1, backgroundColor: C.edge, marginTop: '4px' }} />
                      )}
                    </div>
                    <div style={{ paddingBottom: '8px' }}>
                      <p style={{
                        fontSize: '13px', lineHeight: 1.42, fontFamily: C.sans,
                        color: entry.isNew ? C.ink : C.ink2,
                        fontWeight: entry.isNew ? 500 : 400,
                        marginBottom: entry.isNew ? '5px' : 0,
                      }}>
                        {entry.title}
                      </p>
                      {entry.isNew && (
                        <span style={{
                          fontSize: '9px', letterSpacing: '0.08em', textTransform: 'uppercase',
                          backgroundColor: C.coralTint, color: C.coral,
                          padding: '2px 7px', borderRadius: '100px', fontFamily: C.sans, fontWeight: 600,
                        }}>
                          New
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : catTab === 'Concepts' ? (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1px' }}>
              {concepts.map((concept, i) => (
                <div
                  key={concept.label}
                  style={{
                    display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                    padding: '13px 4px',
                    borderBottom: i < concepts.length - 1 ? `1px solid ${C.edge}` : 'none',
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                    <div style={{
                      width: '7px', height: '7px', borderRadius: '50%',
                      backgroundColor: stateColor[concept.state] ?? C.ink3,
                      flexShrink: 0,
                    }} />
                    <span style={{ fontSize: '14px', color: C.ink, fontFamily: C.sans }}>
                      {concept.label}
                    </span>
                    {concept.isNew && (
                      <span style={{
                        fontSize: '9px', letterSpacing: '0.08em', textTransform: 'uppercase',
                        backgroundColor: C.coralTint, color: C.coral,
                        padding: '2px 7px', borderRadius: '100px', fontFamily: C.sans, fontWeight: 600,
                      }}>
                        New
                      </span>
                    )}
                  </div>
                  <span style={{ fontSize: '11px', color: C.ink3, fontFamily: C.sans }}>{concept.state}</span>
                </div>
              ))}
            </div>
          ) : (
            <div style={{
              backgroundColor: C.fog, borderRadius: '16px',
              padding: '36px 20px', textAlign: 'center',
            }}>
              <p style={{ fontSize: '14px', color: C.ink3, fontFamily: C.sans, marginBottom: '4px' }}>
                No {catTab.toLowerCase()} tracked yet.
              </p>
              <p style={{ fontSize: '12px', color: C.ink3, fontFamily: C.sans }}>
                These build as you learn more developments.
              </p>
            </div>
          )}

        </div>

        <div style={{ height: '16px' }} />
      </div>

      <BottomNav activeTab={activeTab} onTabChange={onTabChange} onNavigate={onNavigate} />
    </div>
  );
}
