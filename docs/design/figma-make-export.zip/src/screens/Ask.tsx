import { useState, useRef } from 'react';
import BottomNav from '../components/BottomNav';
import type { ScreenProps } from '../types';

const C = {
  coral: '#C0553A',
  coralTint: '#F5EAE7',
  ground: '#F6F5F2',
  panel: '#FFFFFF',
  ink: '#1A1918',
  ink2: '#6B6560',
  ink3: '#A09A93',
  fog: '#EDE9E3',
  edge: '#E4E0D9',
  sans: "'Inter', system-ui, sans-serif",
  serif: "'Playfair Display', Georgia, serif",
};

type LearningMode = 'quick' | 'teach-me' | 'go-deep' | 'challenge' | 'connect';
const MODES: { id: LearningMode; label: string; desc: string }[] = [
  { id: 'quick', label: 'Quick answer', desc: 'Concise answer, central idea, and sources.' },
  { id: 'teach-me', label: 'Teach me', desc: 'Guided explanation based on existing knowledge, with suggested learning sequence.' },
  { id: 'go-deep', label: 'Go deep', desc: 'Technical treatment with papers, competing viewpoints, and unresolved questions.' },
  { id: 'challenge', label: 'Challenge me', desc: 'Socratic mode — Thinketh asks questions and withholds the full explanation.' },
  { id: 'connect', label: 'Connect this', desc: 'Relates the question to concepts and gaps in your Knowledge Atlas.' },
];

interface Action { label: string; key: string; primary?: boolean; }
interface Source { title: string; pub: string; kind: string; date?: string; }
interface Disclosure { label: string; content: string; }

type MsgKind =
  | { t: 'user'; text: string }
  | { t: 'thinking' }
  | {
      t: 'prose';
      text: string;
      relation?: string; // e.g. "Context Windows → Persistent Memory → Long-running Agents"
      whyConnects?: string;
      actions?: Action[];
      sources?: Source[];
      disclosures?: Disclosure[];
      nodes?: string[];
    }
  | {
      t: 'gap';
      intro: string;
      nodes: { label: string; state: 'established' | 'developing' | 'gap' }[];
      actions: Action[];
    }
  | {
      t: 'path';
      intro: string;
      steps: { name: string; skipped?: boolean }[];
      time: string;
      actions: Action[];
    }
  | {
      t: 'teaching';
      concept: string;
      step: number;
      total: number;
      text: string;
      example: string;
      sources: Source[];
      actions: Action[];
    }
  | {
      t: 'outside';
      concept: string;
      text: string;
      actions: Action[];
    };

interface Message { id: string; msg: MsgKind }

const uid = () => Math.random().toString(36).slice(2, 9);

const SUGGESTED_PROMPTS = [
  'What should I learn next to build reliable agents?',
  'Explain persistent memory using concepts I already understand.',
  'Where is my agent architecture knowledge weakest?',
  'Build me a 10-minute path through context engineering.',
];

const HISTORY = [
  'Persistent memory and agents',
  'My weakest architecture gaps',
  'Reliable agent learning path',
  'MCP compared with tool use',
];

function buildResponse(text: string): MsgKind | null {
  const t = text.toLowerCase();

  if (t.includes('reliable agents') || (t.includes('reliable') && t.includes('agent'))) {
    return {
      t: 'gap',
      intro: "Your Atlas shows established knowledge of Tool Use and developing knowledge of MCP. Context Engineering is the missing bridge between those concepts and your emerging understanding of Persistent Memory.",
      nodes: [
        { label: 'Tool Use', state: 'established' },
        { label: 'MCP', state: 'developing' },
        { label: 'Context Engineering', state: 'gap' },
        { label: 'Persistent Memory', state: 'developing' },
      ],
      actions: [
        { label: 'Build me a 10-minute learning path', key: 'build-path', primary: true },
        { label: 'Why this concept?', key: 'why-concept' },
        { label: 'Show in Atlas', key: 'show-atlas' },
        { label: 'Choose another gap', key: 'another-gap' },
      ],
    };
  }

  if (t.includes('context engineering') && (t.includes('path') || t.includes('10-minute'))) {
    return {
      t: 'path',
      intro: "Since you asked specifically about Context Engineering, I've built a focused path — it connects directly to your established Tool Use knowledge and bridges toward Retrieval.",
      steps: [
        { name: 'Context Engineering' },
        { name: 'Retrieval' },
        { name: 'Tool Use', skipped: true },
      ],
      time: 'Estimated time: 10 minutes',
      actions: [
        { label: 'Start this path', key: 'start-path', primary: true },
        { label: 'Make it more technical', key: 'make-technical' },
        { label: 'Add Persistent Memory', key: 'add-memory' },
      ],
    };
  }

  if (t.includes('10-minute') || t.includes('10 minute') || t.includes('learning path') || (t.includes('build') && t.includes('path'))) {
    return {
      t: 'path',
      intro: "Your Atlas shows established Tool Use knowledge and developing MCP knowledge — so I've shortened or skipped those. The three concepts below are the real gaps between where you are now and reliable production agents.",
      steps: [
        { name: 'Context Engineering' },
        { name: 'Retrieval' },
        { name: 'Persistent Memory' },
        { name: 'Tool Use', skipped: true },
        { name: 'MCP', skipped: true },
      ],
      time: 'Estimated time: 12 minutes',
      actions: [
        { label: 'Start this path', key: 'start-path', primary: true },
        { label: 'Make it shorter', key: 'make-shorter' },
        { label: 'Make it more technical', key: 'make-technical' },
        { label: 'Connect it to a project', key: 'connect-project' },
      ],
    };
  }

  if (t.includes('quantum')) {
    return {
      t: 'outside',
      concept: 'Quantum computing',
      text: "Quantum computing sits outside your current learning model. I can begin a new knowledge branch, look for a connection to what you already understand, or answer without updating your Atlas.",
      actions: [
        { label: 'Start a new branch', key: 'new-branch', primary: true },
        { label: 'Find the connection', key: 'find-connection' },
        { label: 'Answer once', key: 'answer-once' },
      ],
    };
  }

  if (t.includes('persistent memory') || t.includes('explain persistent')) {
    return {
      t: 'prose',
      text: "Persistent memory allows an agent to retain selected information after the current session ends. Since you already understand context windows, the key distinction is persistence: a context window belongs to the active interaction, while persistent memory survives beyond it.",
      relation: 'Context Windows → Persistent Memory → Long-running Agents',
      whyConnects: 'You have established knowledge of Context Windows and developing knowledge of Agent Memory.',
      actions: [
        { label: 'Teach me this', key: 'teach-this', primary: true },
        { label: 'Go deeper', key: 'go-deeper' },
        { label: 'Add to path', key: 'add-to-path' },
        { label: 'Check my understanding', key: 'check-understanding' },
        { label: 'Show in Atlas', key: 'show-atlas' },
      ],
      sources: [
        { title: 'Persistent memory for Claude agents', pub: 'Anthropic', kind: 'Announcement', date: 'Sep 22' },
        { title: 'Memory and state in the Claude API', pub: 'Anthropic Docs', kind: 'Documentation', date: 'Sep 22' },
        { title: 'Memory Mechanisms in LLM Agents', pub: 'arXiv 2409.14184', kind: 'Paper', date: 'Sep 21' },
      ],
      disclosures: [
        { label: 'What the sources say', content: 'Anthropic announced persistent memory support in the Claude API on September 22. Agents can now retain context across separate sessions without external workarounds.' },
        { label: 'What Thinketh infers', content: 'This is an architectural shift rather than an incremental improvement. Making persistent memory a native primitive lowers the threshold for durable agent workflows significantly.' },
        { label: 'What remains uncertain', content: "Production reliability under load hasn't been independently verified yet. Thinketh is monitoring for corroborating reports before treating this as fully established." },
      ],
      nodes: ['Agent Memory', 'Persistent Memory', 'Claude', 'Tool Use'],
    };
  }

  if (t.includes('weakest') || t.includes('architecture knowledge') || t.includes('architecture weakest')) {
    return {
      t: 'prose',
      text: "Based on your Atlas, two areas show significantly lower confidence. Context Engineering appears as Developing with low connection density — you understand the concept but haven't integrated it with adjacent knowledge. Retrieval is marked Emerging, with few verified relationships to your stronger areas.",
      whyConnects: 'Both Context Engineering and Retrieval are load-bearing for the kinds of agents you\'re building.',
      actions: [
        { label: 'Build a path for these gaps', key: 'build-path', primary: true },
        { label: 'Show in Atlas', key: 'show-atlas' },
        { label: 'Go deeper on Context Engineering', key: 'deeper-context' },
      ],
      nodes: ['Context Engineering', 'Retrieval', 'Agent Architecture', 'Agent Memory'],
    };
  }

  if (t === 'start this path' || t.includes('start path') || t.includes('begin path')) {
    return buildTeachingResponse();
  }

  return {
    t: 'prose',
    text: "Good question. Your Atlas provides some useful context here — let me connect this to what you already understand and flag where the relevant gaps are.",
    actions: [
      { label: 'Go deeper', key: 'go-deeper', primary: true },
      { label: 'Show in Atlas', key: 'show-atlas' },
    ],
  };
}

function buildTeachingResponse(): MsgKind {
  return {
    t: 'teaching',
    concept: 'Context Engineering',
    step: 1,
    total: 3,
    text: "Context engineering is the practice of deliberately shaping what goes into an LLM's context window — and what stays out. You already understand that a context window is a fixed-size working memory. Context engineering asks: given that constraint, how do you choose what to include, in what order, and in what form?\n\nThe most common failure mode in agents isn't model capability — it's sending the wrong information at the wrong moment. A well-engineered context keeps the model oriented, focused, and not distracted by stale or irrelevant content.",
    example: "In a support agent, you might include: the current customer issue, the three most recent messages, and the relevant product documentation section — and deliberately exclude the full conversation history, which dilutes focus.",
    sources: [
      { title: 'Anthropic cookbook: context design', pub: 'Anthropic', kind: 'Guide' },
      { title: 'Building effective agents', pub: 'Anthropic Research', kind: 'Article' },
    ],
    actions: [
      { label: 'Continue', key: 'continue-path', primary: true },
      { label: 'Go deeper', key: 'go-deeper' },
      { label: 'Ask a question', key: 'ask-question' },
      { label: 'Check my understanding', key: 'check-understanding' },
      { label: 'View connection', key: 'show-atlas' },
    ],
  };
}

// ── Sub-components ───────────────────────────────────────────────────────────

function GapVisualization({ nodes }: { nodes: { label: string; state: 'established' | 'developing' | 'gap' }[] }) {
  return (
    <div style={{ marginTop: '16px', marginBottom: '4px', overflowX: 'auto' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '6px', minWidth: 'max-content' }}>
        {nodes.map((node, i) => (
          <div key={i} style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
            <div style={{
              padding: '6px 12px',
              borderRadius: '6px',
              border: node.state === 'gap'
                ? `1.5px dashed ${C.coral}`
                : `1.5px solid ${node.state === 'established' ? C.ink2 : C.edge}`,
              backgroundColor: node.state === 'gap'
                ? 'transparent'
                : node.state === 'established'
                  ? C.fog
                  : C.panel,
              fontSize: '12px',
              fontFamily: C.sans,
              color: node.state === 'gap' ? C.coral : node.state === 'established' ? C.ink : C.ink2,
              fontWeight: node.state === 'established' ? 500 : 400,
              flexShrink: 0,
            }}>
              {node.state === 'gap' && (
                <span style={{ marginRight: '4px', opacity: 0.7 }}>◌</span>
              )}
              {node.label}
            </div>
            {i < nodes.length - 1 && (
              <svg width="16" height="10" viewBox="0 0 16 10" fill="none" style={{ flexShrink: 0 }}>
                <path d="M0 5h12M9 1l4 4-4 4" stroke={C.ink3} strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

function RelationChain({ relation }: { relation: string }) {
  const parts = relation.split('→').map(s => s.trim());
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: '5px',
      flexWrap: 'wrap', marginTop: '14px', marginBottom: '4px',
    }}>
      {parts.map((p, i) => (
        <span key={i} style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
          <span style={{
            fontSize: '12px', color: C.ink2, fontFamily: C.sans,
            backgroundColor: C.fog, padding: '3px 9px', borderRadius: '4px',
            cursor: 'pointer',
          }}>{p}</span>
          {i < parts.length - 1 && (
            <svg width="12" height="8" viewBox="0 0 12 8" fill="none">
              <path d="M0 4h9M6 1l3 3-3 3" stroke={C.ink3} strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          )}
        </span>
      ))}
    </div>
  );
}

function SourceRow({ src }: { src: Source }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between',
      padding: '10px 0', gap: '12px',
    }}>
      <div style={{ flex: 1 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '5px', marginBottom: '2px' }}>
          <span style={{ fontSize: '11px', color: C.ink3, fontFamily: C.sans }}>{src.kind}</span>
          <span style={{ color: C.edge }}>·</span>
          <span style={{ fontSize: '11px', color: C.ink2, fontFamily: C.sans, fontWeight: 500 }}>{src.pub}</span>
          {src.date && <>
            <span style={{ color: C.edge }}>·</span>
            <span style={{ fontSize: '11px', color: C.ink3, fontFamily: C.sans }}>{src.date}</span>
          </>}
        </div>
        <p style={{ fontSize: '13px', color: C.ink, fontFamily: C.sans, lineHeight: 1.35 }}>{src.title}</p>
      </div>
      <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke={C.ink3} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" style={{ flexShrink: 0, marginTop: '2px' }}>
        <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>
        <polyline points="15 3 21 3 21 9"/>
        <line x1="10" y1="14" x2="21" y2="3"/>
      </svg>
    </div>
  );
}

function DisclosureRow({ label, content }: Disclosure) {
  const [open, setOpen] = useState(false);
  return (
    <div style={{ borderTop: `1px solid ${C.edge}` }}>
      <button
        onClick={() => setOpen(v => !v)}
        style={{
          width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          background: 'none', border: 'none', cursor: 'pointer', padding: '11px 0',
        }}
      >
        <span style={{ fontSize: '13px', color: C.ink2, fontFamily: C.sans }}>{label}</span>
        <svg
          width="13" height="13" viewBox="0 0 24 24" fill="none"
          stroke={C.ink3} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"
          style={{ transform: open ? 'rotate(180deg)' : 'none', transition: 'transform 0.18s', flexShrink: 0 }}
        >
          <polyline points="6 9 12 15 18 9"/>
        </svg>
      </button>
      {open && (
        <p style={{ fontSize: '13px', color: C.ink2, fontFamily: C.sans, lineHeight: 1.6, paddingBottom: '12px' }}>
          {content}
        </p>
      )}
    </div>
  );
}

function ActionRow({ actions, onAction }: { actions: Action[]; onAction: (key: string, label: string) => void }) {
  const primary = actions.find(a => a.primary);
  const rest = actions.filter(a => !a.primary);
  return (
    <div style={{ marginTop: '18px', display: 'flex', flexDirection: 'column', gap: '8px' }}>
      {primary && (
        <button
          onClick={() => onAction(primary.key, primary.label)}
          style={{
            backgroundColor: C.ink, color: '#fff',
            fontFamily: C.sans, fontWeight: 500, fontSize: '14px',
            padding: '11px 18px', borderRadius: '10px',
            border: 'none', cursor: 'pointer', textAlign: 'left',
            transition: 'opacity 0.12s',
          }}
        >
          {primary.label}
        </button>
      )}
      {rest.length > 0 && (
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '7px' }}>
          {rest.map(a => (
            <button
              key={a.key}
              onClick={() => onAction(a.key, a.label)}
              style={{
                backgroundColor: 'transparent', color: C.ink2,
                fontFamily: C.sans, fontSize: '13px',
                padding: '7px 13px', borderRadius: '8px',
                border: `1px solid ${C.edge}`, cursor: 'pointer',
                transition: 'border-color 0.12s',
              }}
            >
              {a.label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function InlineNode({ label }: { label: string }) {
  return (
    <button
      style={{
        display: 'inline',
        backgroundColor: C.fog, color: C.ink2,
        padding: '1px 7px', borderRadius: '4px',
        fontSize: 'inherit', fontFamily: C.sans,
        border: `1px solid ${C.edge}`, cursor: 'pointer',
        verticalAlign: 'baseline',
      }}
    >
      {label}
    </button>
  );
}

function MessageBubble({ msg, onAction }: { msg: MsgKind; onAction: (key: string, label: string) => void }) {
  if (msg.t === 'thinking') {
    return (
      <div style={{ padding: '20px 0 4px' }}>
        <p style={{ fontSize: '13px', color: C.ink3, fontFamily: C.sans, fontStyle: 'italic' }}>
          Comparing this with your Knowledge Atlas…
        </p>
      </div>
    );
  }

  if (msg.t === 'user') {
    return (
      <div style={{ display: 'flex', justifyContent: 'flex-end', margin: '8px 0' }}>
        <div style={{
          backgroundColor: C.fog, borderRadius: '14px 14px 4px 14px',
          padding: '11px 15px', maxWidth: '80%',
        }}>
          <p style={{ fontSize: '14px', color: C.ink, fontFamily: C.sans, lineHeight: 1.45, margin: 0 }}>
            {msg.text}
          </p>
        </div>
      </div>
    );
  }

  if (msg.t === 'gap') {
    return (
      <div style={{ padding: '20px 0 4px' }}>
        <p style={{ fontSize: '15px', color: C.ink, fontFamily: C.sans, lineHeight: 1.65 }}>
          {msg.intro}
        </p>
        <GapVisualization nodes={msg.nodes} />
        <ActionRow actions={msg.actions} onAction={onAction} />
      </div>
    );
  }

  if (msg.t === 'path') {
    const active = msg.steps.filter(s => !s.skipped);
    const skipped = msg.steps.filter(s => s.skipped);
    return (
      <div style={{ padding: '20px 0 4px' }}>
        <p style={{ fontSize: '15px', color: C.ink, fontFamily: C.sans, lineHeight: 1.65, marginBottom: '16px' }}>
          {msg.intro}
        </p>

        <div style={{ marginBottom: '12px' }}>
          <p style={{
            fontSize: '11px', letterSpacing: '0.08em', textTransform: 'uppercase',
            color: C.ink3, fontFamily: C.sans, fontWeight: 500, marginBottom: '10px',
          }}>
            Your recommended path
          </p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0' }}>
            {active.map((step, i) => (
              <div key={i} style={{
                display: 'flex', alignItems: 'center', gap: '12px',
                padding: '10px 0',
                borderBottom: i < active.length - 1 ? `1px solid ${C.edge}` : 'none',
              }}>
                <span style={{
                  width: '22px', height: '22px', borderRadius: '50%', flexShrink: 0,
                  backgroundColor: C.ink, color: '#fff',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: '11px', fontWeight: 600, fontFamily: C.sans,
                }}>
                  {i + 1}
                </span>
                <span style={{ fontSize: '14px', color: C.ink, fontFamily: C.sans, fontWeight: 500 }}>
                  {step.name}
                </span>
              </div>
            ))}
          </div>
        </div>

        {skipped.length > 0 && (
          <p style={{ fontSize: '12px', color: C.ink3, fontFamily: C.sans, marginBottom: '10px', lineHeight: 1.5 }}>
            Skipped because you already understand: {skipped.map(s => s.name).join(', ')}
          </p>
        )}

        <p style={{ fontSize: '13px', color: C.ink2, fontFamily: C.sans, marginBottom: '4px' }}>
          {msg.time}
        </p>

        <ActionRow actions={msg.actions} onAction={onAction} />
      </div>
    );
  }

  if (msg.t === 'teaching') {
    return (
      <div style={{ padding: '20px 0 4px' }}>
        <div style={{
          display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '14px',
        }}>
          <div style={{
            height: '2px', flex: 1, backgroundColor: C.edge, borderRadius: '1px', overflow: 'hidden',
          }}>
            <div style={{
              height: '100%', width: `${(msg.step / msg.total) * 100}%`,
              backgroundColor: C.coral, borderRadius: '1px', transition: 'width 0.3s',
            }} />
          </div>
          <span style={{ fontSize: '12px', color: C.ink3, fontFamily: C.sans, flexShrink: 0 }}>
            {msg.step} of {msg.total} · {msg.concept}
          </span>
        </div>

        {msg.text.split('\n\n').map((para, i) => (
          <p key={i} style={{ fontSize: '15px', color: C.ink, fontFamily: C.sans, lineHeight: 1.7, marginBottom: '14px' }}>
            {para}
          </p>
        ))}

        <div style={{
          borderLeft: `3px solid ${C.edge}`, paddingLeft: '14px',
          marginBottom: '16px',
        }}>
          <p style={{ fontSize: '12px', color: C.ink3, fontFamily: C.sans, marginBottom: '5px', textTransform: 'uppercase', letterSpacing: '0.08em', fontWeight: 500 }}>
            Example
          </p>
          <p style={{ fontSize: '13px', color: C.ink2, fontFamily: C.sans, lineHeight: 1.6 }}>
            {msg.example}
          </p>
        </div>

        <div style={{ borderTop: `1px solid ${C.edge}`, paddingTop: '12px', marginBottom: '4px' }}>
          {msg.sources.map((src, i) => (
            <SourceRow key={i} src={src} />
          ))}
        </div>

        <ActionRow actions={msg.actions} onAction={onAction} />
      </div>
    );
  }

  if (msg.t === 'outside') {
    return (
      <div style={{ padding: '20px 0 4px' }}>
        <p style={{
          fontSize: '13px', color: C.ink3, fontFamily: C.sans,
          letterSpacing: '0.08em', textTransform: 'uppercase', fontWeight: 500, marginBottom: '8px',
        }}>
          Outside your current model
        </p>
        <p style={{ fontSize: '15px', color: C.ink, fontFamily: C.sans, lineHeight: 1.65 }}>
          {msg.text}
        </p>
        <ActionRow actions={msg.actions} onAction={onAction} />
      </div>
    );
  }

  // prose
  const prose = msg as Extract<MsgKind, { t: 'prose' }>;
  return (
    <div style={{ padding: '20px 0 4px' }}>
      <p style={{ fontSize: '15px', color: C.ink, fontFamily: C.sans, lineHeight: 1.7, marginBottom: '4px' }}>
        {prose.text}
      </p>

      {prose.relation && <RelationChain relation={prose.relation} />}

      {prose.whyConnects && (
        <p style={{ fontSize: '13px', color: C.ink2, fontFamily: C.sans, lineHeight: 1.55, marginTop: '10px' }}>
          <span style={{ fontWeight: 500 }}>Why this connects · </span>{prose.whyConnects}
        </p>
      )}

      {prose.nodes && prose.nodes.length > 0 && (
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px', marginTop: '14px' }}>
          {prose.nodes.map(n => (
            <InlineNode key={n} label={n} />
          ))}
        </div>
      )}

      {prose.disclosures && prose.disclosures.length > 0 && (
        <div style={{ marginTop: '14px' }}>
          {prose.disclosures.map((d, i) => <DisclosureRow key={i} {...d} />)}
        </div>
      )}

      {prose.sources && prose.sources.length > 0 && (
        <div style={{ borderTop: `1px solid ${C.edge}`, marginTop: '14px', paddingTop: '4px' }}>
          {prose.sources.map((src, i) => <SourceRow key={i} src={src} />)}
        </div>
      )}

      {prose.actions && <ActionRow actions={prose.actions} onAction={onAction} />}
    </div>
  );
}

// ── Main component ───────────────────────────────────────────────────────────

export default function Ask({ onNavigate, activeTab, onTabChange }: ScreenProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [mode, setMode] = useState<LearningMode>('teach-me');
  const [showModeDropdown, setShowModeDropdown] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const thinking = messages.some(m => m.msg.t === 'thinking');

  const scrollToBottom = () => {
    setTimeout(() => bottomRef.current?.scrollIntoView({ behavior: 'smooth' }), 60);
  };

  const removeThinkingAndAppend = (response: MsgKind) => {
    const responseMsg: Message = { id: uid(), msg: response };
    setMessages(prev => [...prev.filter(m => m.msg.t !== 'thinking'), responseMsg]);
    scrollToBottom();
  };

  const sendMessage = (text: string) => {
    const trimmed = text.trim();
    if (!trimmed) return;

    const userMsg: Message = { id: uid(), msg: { t: 'user', text: trimmed } };
    const thinkingMsg: Message = { id: uid(), msg: { t: 'thinking' } };

    setMessages(prev => [...prev, userMsg, thinkingMsg]);
    setInput('');
    if (textareaRef.current) textareaRef.current.style.height = 'auto';
    scrollToBottom();

    setTimeout(() => {
      const response = buildResponse(trimmed);
      removeThinkingAndAppend(response ?? {
        t: 'prose',
        text: "Something went wrong. Please try again.",
      });
    }, 900);
  };

  const handleAction = (key: string, label: string) => {
    if (key === 'start-path') {
      const responseMsg: Message = { id: uid(), msg: buildTeachingResponse() };
      setMessages(prev => [...prev, responseMsg]);
      setTimeout(() => bottomRef.current?.scrollIntoView({ behavior: 'smooth' }), 60);
      return;
    }
    sendMessage(label);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage(input);
    }
  };

  const modeLabel = MODES.find(m => m.id === mode)!.label;
  const hasMessages = messages.length > 0;
  const canSend = input.trim().length > 0 && !thinking;

  return (
    <div style={{
      display: 'flex', flexDirection: 'column', height: '100%',
      backgroundColor: C.ground, position: 'relative',
    }}>

      {/* ── Header ──────────────────────────────────────────────────────────── */}
      <div style={{
        flexShrink: 0,
        padding: '44px 20px 12px',
        borderBottom: `1px solid ${C.edge}`,
        backgroundColor: C.ground,
      }}>
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
          <div>
            <h1 style={{
              fontFamily: C.serif, fontSize: '22px', fontWeight: 600,
              color: C.ink, letterSpacing: '-0.02em', lineHeight: 1.2, marginBottom: '3px',
            }}>
              Ask Thinketh
            </h1>
            <p style={{ fontSize: '12px', color: C.ink3, fontFamily: C.sans }}>
              Grounded in your Knowledge Atlas
            </p>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', paddingTop: '4px' }}>
            <span style={{ fontSize: '11px', color: C.ink3, fontFamily: C.sans }}>
              47 concepts · 12 verified connections
            </span>
            {/* History */}
            <button
              onClick={() => setShowHistory(v => !v)}
              style={{ background: 'none', border: 'none', cursor: 'pointer', padding: '4px', color: C.ink3 }}
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="12" cy="12" r="10"/>
                <polyline points="12 6 12 12 16 14"/>
              </svg>
            </button>
          </div>
        </div>
      </div>

      {/* ── History dropdown ─────────────────────────────────────────────────── */}
      {showHistory && (
        <>
          <div
            onClick={() => setShowHistory(false)}
            style={{ position: 'fixed', inset: 0, zIndex: 30 }}
          />
          <div style={{
            position: 'absolute', top: '100px', right: '16px', zIndex: 40,
            backgroundColor: C.panel, borderRadius: '12px', overflow: 'hidden',
            boxShadow: '0 4px 20px rgba(0,0,0,0.1)', minWidth: '220px',
            border: `1px solid ${C.edge}`,
          }}>
            <div style={{ padding: '10px 14px 8px' }}>
              <p style={{ fontSize: '11px', color: C.ink3, fontFamily: C.sans, letterSpacing: '0.08em', textTransform: 'uppercase', fontWeight: 500 }}>
                Recent conversations
              </p>
            </div>
            {HISTORY.map((h, i) => (
              <button
                key={i}
                onClick={() => { setShowHistory(false); }}
                style={{
                  width: '100%', textAlign: 'left', background: 'none', border: 'none', cursor: 'pointer',
                  padding: '10px 14px',
                  borderTop: `1px solid ${C.edge}`,
                  fontSize: '13px', color: C.ink, fontFamily: C.sans,
                }}
              >
                {h}
              </button>
            ))}
          </div>
        </>
      )}

      {/* ── Conversation / Empty ─────────────────────────────────────────────── */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '0 20px' }}>

        {!hasMessages && (
          <div style={{ paddingTop: '32px', paddingBottom: '16px' }}>
            <h2 style={{
              fontFamily: C.serif, fontSize: '24px', fontWeight: 600,
              color: C.ink, letterSpacing: '-0.02em', lineHeight: 1.25, marginBottom: '8px',
            }}>
              What are you trying to understand?
            </h2>
            <p style={{ fontSize: '14px', color: C.ink2, fontFamily: C.sans, lineHeight: 1.6, marginBottom: '28px' }}>
              Ask a question, explore a gap, or build a learning path from what you already know.
            </p>

            <p style={{
              fontSize: '11px', color: C.ink3, fontFamily: C.sans,
              letterSpacing: '0.08em', textTransform: 'uppercase', fontWeight: 500, marginBottom: '10px',
            }}>
              Based on your Atlas
            </p>
            <div style={{ borderTop: `1px solid ${C.edge}` }}>
              {SUGGESTED_PROMPTS.map((p) => (
                <button
                  key={p}
                  onClick={() => sendMessage(p)}
                  style={{
                    width: '100%', textAlign: 'left', background: 'none', border: 'none', cursor: 'pointer',
                    padding: '13px 0', borderBottom: `1px solid ${C.edge}`,
                    display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '12px',
                  }}
                >
                  <span style={{ fontSize: '14px', color: C.ink, fontFamily: C.sans, lineHeight: 1.4 }}>
                    {p}
                  </span>
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke={C.ink3} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ flexShrink: 0 }}>
                    <path d="M5 12h14M12 5l7 7-7 7"/>
                  </svg>
                </button>
              ))}
            </div>
          </div>
        )}

        {hasMessages && (
          <div style={{ paddingTop: '8px', paddingBottom: '16px' }}>
            {messages.map(m => (
              <MessageBubble key={m.id} msg={m.msg} onAction={handleAction} />
            ))}
          </div>
        )}

        <div ref={bottomRef} />
      </div>

      {/* ── Composer ─────────────────────────────────────────────────────────── */}
      <div style={{
        flexShrink: 0,
        borderTop: `1px solid ${C.edge}`,
        backgroundColor: C.ground,
        padding: '10px 16px 12px',
      }}>
        {/* Mode selector row */}
        <div style={{ position: 'relative', marginBottom: '8px' }}>
          <button
            onClick={() => setShowModeDropdown(v => !v)}
            style={{
              display: 'flex', alignItems: 'center', gap: '5px',
              background: 'none', border: 'none', cursor: 'pointer', padding: '0 2px',
            }}
          >
            <span style={{ fontSize: '12px', color: C.ink2, fontFamily: C.sans, fontWeight: 500 }}>
              {modeLabel}
            </span>
            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke={C.ink3} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="6 9 12 15 18 9"/>
            </svg>
          </button>

          {showModeDropdown && (
            <>
              <div
                onClick={() => setShowModeDropdown(false)}
                style={{ position: 'fixed', inset: 0, zIndex: 30 }}
              />
              <div style={{
                position: 'absolute', bottom: '28px', left: 0, zIndex: 40,
                backgroundColor: C.panel, borderRadius: '12px', overflow: 'hidden',
                boxShadow: '0 -4px 24px rgba(0,0,0,0.1)', minWidth: '240px',
                border: `1px solid ${C.edge}`,
              }}>
                {MODES.map(m => (
                  <button
                    key={m.id}
                    onClick={() => { setMode(m.id); setShowModeDropdown(false); }}
                    style={{
                      width: '100%', textAlign: 'left', background: 'none', border: 'none', cursor: 'pointer',
                      padding: '11px 14px',
                      borderBottom: `1px solid ${C.edge}`,
                      backgroundColor: mode === m.id ? C.fog : 'transparent',
                    }}
                  >
                    <p style={{ fontSize: '13px', color: C.ink, fontFamily: C.sans, fontWeight: 500, marginBottom: '2px' }}>
                      {m.label}
                    </p>
                    <p style={{ fontSize: '11px', color: C.ink3, fontFamily: C.sans, lineHeight: 1.4 }}>
                      {m.desc}
                    </p>
                  </button>
                ))}
              </div>
            </>
          )}
        </div>

        {/* Textarea + send */}
        <div style={{
          display: 'flex', alignItems: 'flex-end', gap: '10px',
          backgroundColor: C.panel,
          border: `1px solid ${C.edge}`, borderRadius: '12px',
          padding: '10px 12px',
        }}>
          <textarea
            ref={textareaRef}
            value={input}
            onChange={e => {
              setInput(e.target.value);
              e.target.style.height = 'auto';
              e.target.style.height = Math.min(e.target.scrollHeight, 120) + 'px';
            }}
            onKeyDown={handleKeyDown}
            placeholder="Ask, explore, or build a learning path…"
            rows={1}
            style={{
              flex: 1, fontSize: '14px', color: C.ink, backgroundColor: 'transparent',
              border: 'none', outline: 'none', fontFamily: C.sans, resize: 'none',
              lineHeight: 1.5, maxHeight: '120px', overflowY: 'auto',
            }}
          />
          <button
            onClick={() => sendMessage(input)}
            disabled={!canSend}
            style={{
              flexShrink: 0,
              width: '32px', height: '32px', borderRadius: '8px',
              backgroundColor: canSend ? C.ink : C.edge,
              border: 'none', cursor: canSend ? 'pointer' : 'default',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              transition: 'background-color 0.15s',
            }}
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke={canSend ? '#fff' : C.ink3} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
              <line x1="12" y1="19" x2="12" y2="5"/>
              <polyline points="5 12 12 5 19 12"/>
            </svg>
          </button>
        </div>
      </div>

      <BottomNav activeTab={activeTab} onTabChange={onTabChange} onNavigate={onNavigate} />
    </div>
  );
}
