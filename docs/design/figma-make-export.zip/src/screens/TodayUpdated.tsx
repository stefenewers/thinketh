import BottomNav from '../components/BottomNav';
import type { ScreenProps } from '../types';
import logoColor from '../imports/ChatGPT_Image_Sep_22__2026_at_11_27_38_AM__1_.png';
import KnowledgeAtlas from '../components/KnowledgeAtlas';

const C = {
  coral: '#C0553A',
  coralTint: '#F7EAE6',
  ground: '#F9F7F4',
  panel: '#FFFFFF',
  ink: '#1A1918',
  ink2: '#6B6560',
  ink3: '#A09A93',
  fog: '#EEEAE4',
  edge: '#E4E0D9',
  serif: "'Playfair Display', Georgia, 'Times New Roman', serif",
  sans: "'Inter', system-ui, -apple-system, sans-serif",
};

export default function TodayUpdated({ onNavigate, activeTab, onTabChange }: ScreenProps) {
  return (
    <div className="flex flex-col h-full" style={{ backgroundColor: C.ground }}>
      <div className="flex-1 overflow-y-auto pb-4">
        <div style={{ padding: '44px 24px 0' }}>

          {/* Wordmark */}
          <img
            src={logoColor}
            alt="thinketh"
            style={{ height: '22px', width: 'auto', display: 'block', marginBottom: '44px' }}
          />

          {/* Date */}
          <p style={{
            fontSize: '11px', letterSpacing: '0.13em', textTransform: 'uppercase',
            fontWeight: 500, color: C.ink3, fontFamily: C.sans, marginBottom: '14px',
          }}>
            Tuesday, September 22
          </p>

          {/* Heading */}
          <h1 style={{
            fontFamily: C.serif, fontSize: '32px', lineHeight: 1.15,
            letterSpacing: '-0.02em', color: C.ink, marginBottom: '8px', fontWeight: 600,
          }}>
            1 of 7 understood.
          </h1>

          <p style={{ fontSize: '14px', color: C.ink3, fontFamily: C.sans, marginBottom: '24px' }}>
            9 minutes remaining
          </p>

          {/* Progress — understated, not gamified */}
          <div style={{ marginBottom: '40px' }}>
            <div style={{
              height: '2px', backgroundColor: C.edge, borderRadius: '2px',
              overflow: 'hidden',
            }}>
              <div style={{
                height: '100%', width: '14%', backgroundColor: C.coral,
                borderRadius: '2px', transition: 'width 0.8s ease',
              }} />
            </div>
          </div>
        </div>

        {/* ── Knowledge changed today module ───────────────── */}
        <div style={{ padding: '0 24px', marginBottom: '32px' }}>
          <button
            onClick={() => onNavigate('library')}
            style={{
              width: '100%', textAlign: 'left',
              backgroundColor: C.ink, borderRadius: '18px', overflow: 'hidden',
              padding: 0, border: 'none', cursor: 'pointer',
              position: 'relative', display: 'block',
            }}
          >
            {/* Mini atlas preview */}
            <div style={{ height: '100px', position: 'relative', overflow: 'hidden' }}>
              <KnowledgeAtlas
                mode="mini"
                showNewNode={true}
                style={{ position: 'absolute', inset: 0, opacity: 0.45 }}
              />
              <div style={{
                position: 'absolute', inset: 0,
                background: 'linear-gradient(to bottom, transparent 10%, rgba(26,25,24,0.75) 100%)',
              }} />
            </div>
            <div style={{ padding: '12px 18px 16px' }}>
              <p style={{
                fontSize: '10px', letterSpacing: '0.1em', textTransform: 'uppercase',
                color: 'rgba(255,255,255,0.5)', fontFamily: C.sans, fontWeight: 500,
                marginBottom: '4px',
              }}>
                Your knowledge changed today
              </p>
              <p style={{ fontSize: '13px', color: '#fff', fontFamily: C.sans, lineHeight: 1.45, marginBottom: '10px' }}>
                Persistent Memory connected to Agent Memory, Claude, and Long-running Agents.
              </p>
              <span style={{
                fontSize: '12px', color: C.coral, fontFamily: C.sans, fontWeight: 500,
                display: 'flex', alignItems: 'center', gap: '4px',
              }}>
                View in Knowledge Atlas
                <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.3" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M5 12h14M12 5l7 7-7 7"/>
                </svg>
              </span>
            </div>
          </button>
        </div>

        {/* ── Next Up ──────────────────────────────────────── */}
        <div style={{ borderTop: `1px solid ${C.edge}`, margin: '0 24px' }} />

        <div style={{ padding: '28px 24px 28px' }}>
          <p style={{
            fontSize: '10px', letterSpacing: '0.14em', textTransform: 'uppercase',
            fontWeight: 600, color: C.coral, fontFamily: C.sans, marginBottom: '12px',
          }}>
            Next · Major development · 2 min
          </p>

          <h2 style={{
            fontFamily: C.serif, fontSize: '22px', lineHeight: 1.28,
            letterSpacing: '-0.01em', color: C.ink, fontWeight: 600,
            marginBottom: '20px',
          }}>
            OpenAI releases reasoning model with improved math and code performance
          </h2>

          <button
            style={{
              background: 'none', border: 'none', cursor: 'pointer', padding: 0,
              display: 'inline-flex', alignItems: 'center', gap: '5px',
              fontSize: '13px', fontWeight: 500, color: C.coral, fontFamily: C.sans,
            }}
          >
            Read development
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.3" strokeLinecap="round" strokeLinejoin="round">
              <path d="M5 12h14M12 5l7 7-7 7"/>
            </svg>
          </button>
        </div>

        {/* ── Completed ────────────────────────────────────── */}
        <div style={{ borderTop: `1px solid ${C.edge}`, margin: '0 24px' }} />

        <div style={{ padding: '20px 24px' }}>
          <p style={{
            fontSize: '10px', letterSpacing: '0.14em', textTransform: 'uppercase',
            fontWeight: 600, color: C.ink3, fontFamily: C.sans, marginBottom: '16px',
          }}>
            Verified
          </p>

          <div style={{ display: 'flex', alignItems: 'flex-start', gap: '12px' }}>
            <div style={{
              flexShrink: 0, width: '18px', height: '18px',
              borderRadius: '50%', backgroundColor: C.coral,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              marginTop: '1px',
            }}>
              <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2.8" strokeLinecap="round" strokeLinejoin="round">
                <polyline points="20 6 9 17 4 12"/>
              </svg>
            </div>
            <div>
              <p style={{
                fontSize: '14px', color: C.ink2, fontFamily: C.sans,
                lineHeight: 1.4,
                marginBottom: '3px',
              }}>
                Anthropic expands long-term agent memory
              </p>
              <p style={{ fontSize: '11px', color: C.ink3, fontFamily: C.sans }}>
                Initial understanding verified · Persistent Memory added to Atlas
              </p>
            </div>
          </div>
        </div>

        <div style={{ height: '12px' }} />
      </div>

      <BottomNav activeTab={activeTab} onTabChange={onTabChange} onNavigate={onNavigate} />
    </div>
  );
}
