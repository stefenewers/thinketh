import { useState } from 'react';
import BottomNav from '../components/BottomNav';
import type { ScreenProps } from '../types';

const C = {
  coral: '#C0553A',
  coralTint: '#F7EAE6',
  ground: '#F6F5F2',
  panel: '#FFFFFF',
  ink: '#1A1918',
  ink2: '#6B6560',
  ink3: '#A09A93',
  fog: '#EEEAE4',
  edge: '#E6E2DA',
  sans: "'Inter', system-ui, sans-serif",
  serif: "'Playfair Display', Georgia, serif",
};

type DeltaStep = 'overview' | 'check' | 'check-q2' | 'check-q3' | 'verified' | 'add-to-path' | 'connect-project';

const understandingQuestions = [
  {
    type: 'Mechanism',
    q: 'What is the key distinction Anthropic draws between a workflow and an agent?',
    correct: 'Workflows follow fixed, predefined sequences of steps. Agents dynamically decide which tools to call and in what order based on the current state.',
    options: [
      'Workflows use APIs; agents use local code',
      'Workflows follow fixed sequences; agents decide dynamically',
      'Agents are faster; workflows are more reliable',
    ],
    correctIdx: 1,
  },
  {
    type: 'Transfer',
    q: 'You\'re building an ingestion pipeline that reads a PDF, extracts text, and saves to a database. Which architecture fits best?',
    correct: 'A workflow — the steps are deterministic and predefined, so an agentic loop would add unnecessary complexity and unpredictability.',
    options: [
      'An agent, for maximum flexibility',
      'A workflow, because the steps are fixed and deterministic',
      'Neither — use a simple script',
    ],
    correctIdx: 1,
  },
  {
    type: 'Boundary',
    q: 'When does the agent architecture become appropriate over a workflow?',
    correct: 'When the steps cannot be determined in advance — the system must observe the environment and choose actions dynamically, such as when debugging an unknown codebase.',
    options: [
      'Whenever latency is acceptable',
      'Only when using Claude models',
      'When steps can\'t be predetermined and the system must choose actions dynamically',
    ],
    correctIdx: 2,
  },
];

export default function TeachDelta({ onNavigate, activeTab, onTabChange }: ScreenProps) {
  const [step, setStep] = useState<DeltaStep>('overview');
  const [qIdx, setQIdx] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [answered, setAnswered] = useState(false);
  const [correctCount, setCorrectCount] = useState(0);
  const [addedToPath, setAddedToPath] = useState(false);
  const [pathAccepted, setPathAccepted] = useState(false);
  const [connectedToProject, setConnectedToProject] = useState(false);

  const currentQ = understandingQuestions[qIdx];

  const handleAnswer = (idx: number) => {
    if (answered) return;
    setSelected(idx);
    setAnswered(true);
    if (idx === currentQ.correctIdx) setCorrectCount(c => c + 1);
  };

  const handleNext = () => {
    if (qIdx < understandingQuestions.length - 1) {
      setQIdx(q => q + 1);
      setSelected(null);
      setAnswered(false);
    } else {
      setStep('verified');
    }
  };

  return (
    <div className="flex flex-col h-full" style={{ backgroundColor: C.ground }}>
      <div className="flex-1 overflow-y-auto">

        {/* Header */}
        <div style={{ padding: '44px 20px 20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <button
            onClick={() => onNavigate('library')}
            style={{
              display: 'flex', alignItems: 'center', gap: '5px',
              background: 'none', border: 'none', cursor: 'pointer', padding: 0,
              fontSize: '14px', color: C.ink2, fontFamily: C.sans,
            }}
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
              <path d="M19 12H5M12 19l-7-7 7-7"/>
            </svg>
            Learning Queue
          </button>
          <span style={{
            fontSize: '10px', letterSpacing: '0.1em', textTransform: 'uppercase',
            color: C.ink3, fontFamily: C.sans, fontWeight: 500,
          }}>
            Teach me the delta
          </span>
        </div>

        {/* Resource context strip */}
        <div style={{ padding: '0 20px 20px' }}>
          <div style={{
            backgroundColor: C.panel, borderRadius: '14px', padding: '12px 16px',
            display: 'flex', alignItems: 'center', gap: '12px',
            boxShadow: `0 0 0 1px ${C.edge}`,
          }}>
            <div style={{
              width: '36px', height: '36px', borderRadius: '8px',
              backgroundColor: C.coralTint, display: 'flex', alignItems: 'center', justifyContent: 'center',
              flexShrink: 0,
            }}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke={C.coral} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                <polyline points="14 2 14 8 20 8"/>
              </svg>
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <p style={{ fontSize: '13px', fontWeight: 600, color: C.ink, fontFamily: C.sans, marginBottom: '1px' }}>
                Building Effective Agents
              </p>
              <p style={{ fontSize: '11px', color: C.ink3, fontFamily: C.sans }}>
                Anthropic · Technical article · 6 useful minutes
              </p>
            </div>
          </div>
        </div>

        {step === 'overview' && (
          <div style={{ padding: '0 20px 24px' }}>

            {/* Thinketh opening */}
            <div style={{
              backgroundColor: C.panel, borderRadius: '20px', padding: '20px',
              marginBottom: '20px', boxShadow: `0 0 0 1px ${C.edge}`,
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '12px' }}>
                <div style={{
                  width: '24px', height: '24px', borderRadius: '50%',
                  backgroundColor: C.ink, display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>
                  <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="12" cy="12" r="3"/>
                    <path d="M12 2v3M12 19v3M4.22 4.22l2.12 2.12M17.66 17.66l2.12 2.12M2 12h3M19 12h3M4.22 19.78l2.12-2.12M17.66 6.34l2.12-2.12"/>
                  </svg>
                </div>
                <span style={{ fontSize: '12px', fontWeight: 600, color: C.ink, fontFamily: C.sans }}>Thinketh</span>
              </div>

              <p style={{ fontSize: '14px', color: C.ink, fontFamily: C.sans, lineHeight: 1.55, marginBottom: '16px' }}>
                I compared this resource with your current Knowledge Atlas. Most of the Tool Use section reinforces what you already understand. The genuinely new material is the distinction between workflows and agents.
              </p>

              <div style={{ borderTop: `1px solid ${C.edge}`, paddingTop: '16px', display: 'flex', flexDirection: 'column', gap: '16px' }}>

                {/* What you already know */}
                <div>
                  <p style={{
                    fontSize: '10px', letterSpacing: '0.1em', textTransform: 'uppercase',
                    color: C.ink3, fontFamily: C.sans, fontWeight: 500, marginBottom: '6px',
                  }}>
                    What you already know
                  </p>
                  <p style={{ fontSize: '13px', color: C.ink2, fontFamily: C.sans, lineHeight: 1.5 }}>
                    Tool use, basic agent loops, prompt chaining, and the general structure of LLM-powered systems. The article's tool-calling examples will be familiar.
                  </p>
                </div>

                {/* What is new */}
                <div>
                  <p style={{
                    fontSize: '10px', letterSpacing: '0.1em', textTransform: 'uppercase',
                    color: C.coral, fontFamily: C.sans, fontWeight: 500, marginBottom: '6px',
                  }}>
                    What is new
                  </p>
                  <p style={{ fontSize: '13px', color: C.ink, fontFamily: C.sans, lineHeight: 1.5, marginBottom: '10px' }}>
                    Anthropic's precise distinction between <em>workflows</em> — fixed, deterministic sequences — and <em>agents</em> — systems that dynamically choose their next action. This changes when you'd reach for each architecture.
                  </p>
                  <div style={{
                    backgroundColor: C.coralTint, borderRadius: '12px', padding: '12px 14px',
                  }}>
                    <p style={{
                      fontFamily: C.serif, fontSize: '14px', fontStyle: 'italic',
                      color: C.ink, lineHeight: 1.5,
                    }}>
                      "Use workflows when the steps are predictable. Use agents when they aren't."
                    </p>
                    <p style={{ fontSize: '10px', color: C.coral, fontFamily: C.sans, fontWeight: 500, marginTop: '6px' }}>
                      Best evidence — Section 3: Choosing the right pattern
                    </p>
                  </div>
                </div>

                {/* Why it matters */}
                <div>
                  <p style={{
                    fontSize: '10px', letterSpacing: '0.1em', textTransform: 'uppercase',
                    color: C.ink3, fontFamily: C.sans, fontWeight: 500, marginBottom: '6px',
                  }}>
                    Why it matters for you
                  </p>
                  <p style={{ fontSize: '13px', color: C.ink2, fontFamily: C.sans, lineHeight: 1.5 }}>
                    Your HackGT project involves an ingestion pipeline. This framework helps you decide which parts should be deterministic workflows and which need agentic decision-making.
                  </p>
                </div>

                {/* Updated mental model */}
                <div style={{
                  backgroundColor: C.fog, borderRadius: '12px', padding: '12px 14px',
                }}>
                  <p style={{
                    fontSize: '10px', letterSpacing: '0.1em', textTransform: 'uppercase',
                    color: C.ink3, fontFamily: C.sans, fontWeight: 500, marginBottom: '6px',
                  }}>
                    Updated mental model
                  </p>
                  <p style={{
                    fontFamily: C.serif, fontSize: '14px', color: C.ink, lineHeight: 1.5,
                  }}>
                    "Agent" and "workflow" are not synonyms. An agent is appropriate only when the required sequence of steps cannot be determined in advance.
                  </p>
                </div>
              </div>
            </div>

            {/* Actions */}
            <button
              onClick={() => setStep('check')}
              style={{
                width: '100%', padding: '15px', borderRadius: '14px',
                backgroundColor: C.ink, border: 'none', cursor: 'pointer',
                fontSize: '14px', fontWeight: 600, color: '#fff', fontFamily: C.sans,
                marginBottom: '10px',
              }}
            >
              Check my understanding
            </button>

            <div style={{ display: 'flex', gap: '8px' }}>
              <button
                onClick={() => setStep('add-to-path')}
                style={{
                  flex: 1, padding: '12px', borderRadius: '12px',
                  backgroundColor: pathAccepted ? C.coralTint : C.panel,
                  border: `1px solid ${pathAccepted ? C.coral : C.edge}`,
                  cursor: 'pointer', fontSize: '12px', fontWeight: 500,
                  color: pathAccepted ? C.coral : C.ink2, fontFamily: C.sans,
                  transition: 'all 0.2s',
                }}
              >
                {pathAccepted ? '✓ Added to path' : 'Add to path'}
              </button>
              <button
                onClick={() => setStep('connect-project')}
                style={{
                  flex: 1, padding: '12px', borderRadius: '12px',
                  backgroundColor: connectedToProject ? '#EAF4ED' : C.panel,
                  border: `1px solid ${connectedToProject ? '#4A9E6B' : C.edge}`,
                  cursor: 'pointer', fontSize: '12px', fontWeight: 500,
                  color: connectedToProject ? '#1E5C35' : C.ink2, fontFamily: C.sans,
                }}
              >
                {connectedToProject ? '✓ Connected' : 'Connect to project'}
              </button>
            </div>
          </div>
        )}

        {(step === 'check' || step === 'check-q2' || step === 'check-q3') && (
          <div style={{ padding: '0 20px 24px' }}>
            <div style={{ marginBottom: '16px' }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '4px' }}>
                <span style={{
                  fontSize: '10px', letterSpacing: '0.1em', textTransform: 'uppercase',
                  color: C.coral, fontFamily: C.sans, fontWeight: 600,
                }}>
                  {currentQ.type} question
                </span>
                <span style={{ fontSize: '11px', color: C.ink3, fontFamily: C.sans }}>
                  {qIdx + 1} of {understandingQuestions.length}
                </span>
              </div>

              {/* Progress bar */}
              <div style={{ height: '2px', backgroundColor: C.edge, borderRadius: '2px' }}>
                <div style={{
                  height: '100%', borderRadius: '2px', backgroundColor: C.coral,
                  width: `${((qIdx) / understandingQuestions.length) * 100}%`,
                  transition: 'width 0.3s',
                }} />
              </div>
            </div>

            <p style={{
              fontFamily: C.serif, fontSize: '18px', color: C.ink, lineHeight: 1.45,
              marginBottom: '20px',
            }}>
              {currentQ.q}
            </p>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', marginBottom: '20px' }}>
              {currentQ.options.map((opt, i) => {
                const isCorrect = i === currentQ.correctIdx;
                const isSelected = selected === i;
                let bg = C.panel;
                let border = C.edge;
                let textColor = C.ink;
                if (answered && isCorrect) { bg = '#EAF4ED'; border = '#4A9E6B'; textColor = '#1E5C35'; }
                else if (answered && isSelected && !isCorrect) { bg = C.coralTint; border = C.coral; textColor = C.coral; }

                return (
                  <button
                    key={i}
                    onClick={() => handleAnswer(i)}
                    style={{
                      width: '100%', textAlign: 'left', padding: '13px 16px',
                      borderRadius: '12px', border: `1px solid ${border}`,
                      backgroundColor: bg, cursor: answered ? 'default' : 'pointer',
                      fontSize: '13px', color: textColor, fontFamily: C.sans, lineHeight: 1.45,
                      transition: 'all 0.2s',
                    }}
                  >
                    {opt}
                  </button>
                );
              })}
            </div>

            {answered && (
              <div style={{
                backgroundColor: selected === currentQ.correctIdx ? '#EAF4ED' : C.coralTint,
                borderRadius: '12px', padding: '14px 16px', marginBottom: '16px',
              }}>
                <p style={{
                  fontSize: '12px', fontWeight: 600,
                  color: selected === currentQ.correctIdx ? '#1E5C35' : C.coral,
                  fontFamily: C.sans, marginBottom: '5px',
                }}>
                  {selected === currentQ.correctIdx ? 'Correct' : 'Not quite'}
                </p>
                <p style={{ fontSize: '13px', color: C.ink2, fontFamily: C.sans, lineHeight: 1.5 }}>
                  {currentQ.correct}
                </p>
              </div>
            )}

            {answered && (
              <button
                onClick={handleNext}
                style={{
                  width: '100%', padding: '14px', borderRadius: '12px',
                  backgroundColor: C.ink, border: 'none', cursor: 'pointer',
                  fontSize: '14px', fontWeight: 600, color: '#fff', fontFamily: C.sans,
                }}
              >
                {qIdx < understandingQuestions.length - 1 ? 'Next question' : 'See results'}
              </button>
            )}
          </div>
        )}

        {step === 'verified' && (
          <div style={{ padding: '0 20px 24px' }}>
            <div style={{
              backgroundColor: C.panel, borderRadius: '20px', padding: '24px 20px',
              boxShadow: `0 0 0 1px ${C.edge}`, textAlign: 'center', marginBottom: '16px',
            }}>
              <div style={{
                width: '48px', height: '48px', borderRadius: '50%',
                backgroundColor: '#EAF4ED', display: 'flex', alignItems: 'center',
                justifyContent: 'center', margin: '0 auto 12px',
              }}>
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#4A9E6B" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                  <polyline points="20 6 9 17 4 12"/>
                </svg>
              </div>
              <p style={{
                fontFamily: C.serif, fontSize: '20px', fontWeight: 600,
                color: C.ink, marginBottom: '8px',
              }}>
                Understanding verified
              </p>
              <p style={{ fontSize: '13px', color: C.ink2, fontFamily: C.sans, lineHeight: 1.5, marginBottom: '16px' }}>
                {correctCount} of 3 correct. The workflows-versus-agents distinction is now part of your Knowledge Atlas.
              </p>

              <div style={{
                backgroundColor: C.fog, borderRadius: '12px', padding: '12px 14px',
                textAlign: 'left', marginBottom: '16px',
              }}>
                <p style={{
                  fontSize: '10px', letterSpacing: '0.1em', textTransform: 'uppercase',
                  color: C.ink3, fontFamily: C.sans, fontWeight: 500, marginBottom: '4px',
                }}>
                  Atlas updated
                </p>
                <p style={{ fontSize: '13px', color: C.ink, fontFamily: C.sans }}>
                  Agent Architecture ← workflow vs. agent distinction
                </p>
                <p style={{ fontSize: '11px', color: C.ink3, fontFamily: C.sans, marginTop: '3px' }}>
                  Connected to your HackGT project
                </p>
              </div>

              <div style={{ display: 'flex', gap: '8px' }}>
                <button
                  onClick={() => onNavigate('library')}
                  style={{
                    flex: 1, padding: '13px', borderRadius: '12px',
                    backgroundColor: C.ink, border: 'none', cursor: 'pointer',
                    fontSize: '13px', fontWeight: 600, color: '#fff', fontFamily: C.sans,
                  }}
                >
                  Back to Queue
                </button>
                <button
                  style={{
                    flex: 1, padding: '13px', borderRadius: '12px',
                    backgroundColor: C.panel, border: `1px solid ${C.edge}`,
                    cursor: 'pointer', fontSize: '13px', color: C.ink2, fontFamily: C.sans,
                  }}
                >
                  Go deeper
                </button>
              </div>
            </div>
          </div>
        )}

        {step === 'add-to-path' && (
          <div style={{ padding: '0 20px 24px' }}>
            <button
              onClick={() => setStep('overview')}
              style={{
                display: 'flex', alignItems: 'center', gap: '5px',
                background: 'none', border: 'none', cursor: 'pointer', padding: 0,
                fontSize: '14px', color: C.ink2, fontFamily: C.sans, marginBottom: '20px',
              }}
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                <path d="M19 12H5M12 19l-7-7 7-7"/>
              </svg>
              Back
            </button>

            <p style={{
              fontFamily: C.serif, fontSize: '20px', fontWeight: 600,
              color: C.ink, marginBottom: '4px',
            }}>
              Add to learning path
            </p>
            <p style={{ fontSize: '13px', color: C.ink3, fontFamily: C.sans, marginBottom: '20px' }}>
              Thinketh recommends where this fits best.
            </p>

            {/* Path selector */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', marginBottom: '20px' }}>
              {[
                { name: 'Reliable Production Agents', nodes: 6, active: true },
                { name: 'Foundation Models', nodes: 4, active: false },
                { name: 'New path…', nodes: null, active: false },
              ].map((path, i) => (
                <button key={i} style={{
                  padding: '13px 16px', borderRadius: '12px', textAlign: 'left',
                  backgroundColor: i === 0 ? C.ink : C.panel,
                  border: `1px solid ${i === 0 ? C.ink : C.edge}`,
                  cursor: 'pointer',
                }}>
                  <p style={{ fontSize: '13px', fontWeight: 600, color: i === 0 ? '#fff' : C.ink, fontFamily: C.sans, marginBottom: '2px' }}>
                    {path.name}
                  </p>
                  {path.nodes && (
                    <p style={{ fontSize: '11px', color: i === 0 ? 'rgba(255,255,255,0.6)' : C.ink3, fontFamily: C.sans }}>
                      {path.nodes} resources
                    </p>
                  )}
                </button>
              ))}
            </div>

            {/* Placement recommendation */}
            <div style={{
              backgroundColor: C.panel, borderRadius: '16px', overflow: 'hidden',
              boxShadow: `0 0 0 1px ${C.edge}`, marginBottom: '20px',
            }}>
              <div style={{ padding: '12px 16px', borderBottom: `1px solid ${C.edge}` }}>
                <p style={{
                  fontSize: '10px', letterSpacing: '0.1em', textTransform: 'uppercase',
                  color: C.ink3, fontFamily: C.sans, fontWeight: 500,
                }}>
                  Recommended position
                </p>
              </div>
              {/* Path visualization */}
              <div style={{ padding: '16px' }}>
                {[
                  { label: 'Prompt Engineering', state: 'verified' },
                  { label: 'Tool Use', state: 'verified' },
                  { label: 'Building Effective Agents', state: 'new', isInserted: true },
                  { label: 'Persistent Memory', state: 'next' },
                  { label: 'Long-running Agents', state: 'pending' },
                ].map((node, i, arr) => (
                  <div key={i} style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: i < arr.length - 1 ? '0' : '0' }}>
                    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', flexShrink: 0 }}>
                      <div style={{
                        width: '10px', height: '10px', borderRadius: '50%', flexShrink: 0,
                        backgroundColor: node.state === 'verified' ? '#4A9E6B' : node.isInserted ? C.coral : node.state === 'next' ? C.ink : C.edge,
                        border: node.isInserted ? `2px solid ${C.coral}` : 'none',
                        boxShadow: node.isInserted ? `0 0 0 3px ${C.coralTint}` : 'none',
                      }} />
                      {i < arr.length - 1 && (
                        <div style={{
                          width: '1px', height: '28px',
                          backgroundColor: node.isInserted ? C.coral : C.edge,
                          borderStyle: node.state === 'pending' ? 'dashed' : 'solid',
                        }} />
                      )}
                    </div>
                    <p style={{
                      fontSize: node.isInserted ? '13px' : '12px',
                      fontWeight: node.isInserted ? 600 : 400,
                      color: node.isInserted ? C.coral : node.state === 'verified' ? C.ink : node.state === 'next' ? C.ink : C.ink3,
                      fontFamily: node.isInserted ? C.serif : C.sans,
                      paddingBottom: i < arr.length - 1 ? '18px' : '0',
                    }}>
                      {node.label}
                      {node.isInserted && (
                        <span style={{
                          display: 'inline-block', marginLeft: '8px',
                          fontSize: '9px', letterSpacing: '0.08em', textTransform: 'uppercase',
                          backgroundColor: C.coralTint, color: C.coral,
                          padding: '2px 7px', borderRadius: '100px', fontFamily: C.sans, fontWeight: 600,
                          verticalAlign: 'middle',
                        }}>
                          New
                        </span>
                      )}
                    </p>
                  </div>
                ))}
              </div>

              <div style={{ padding: '12px 16px', backgroundColor: C.fog, borderTop: `1px solid ${C.edge}` }}>
                <p style={{ fontSize: '12px', color: C.ink2, fontFamily: C.sans, lineHeight: 1.5 }}>
                  This resource introduces agent/workflow architecture before the path moves into memory systems.
                </p>
              </div>
            </div>

            <button
              onClick={() => { setPathAccepted(true); setStep('overview'); }}
              style={{
                width: '100%', padding: '14px', borderRadius: '12px',
                backgroundColor: C.ink, border: 'none', cursor: 'pointer',
                fontSize: '14px', fontWeight: 600, color: '#fff', fontFamily: C.sans,
                marginBottom: '8px',
              }}
            >
              Place here — after Tool Use
            </button>
            <button
              onClick={() => setStep('overview')}
              style={{
                width: '100%', padding: '12px', borderRadius: '12px',
                backgroundColor: C.panel, border: `1px solid ${C.edge}`,
                cursor: 'pointer', fontSize: '13px', color: C.ink2, fontFamily: C.sans,
              }}
            >
              Choose a different position
            </button>
          </div>
        )}

        {step === 'connect-project' && (
          <div style={{ padding: '0 20px 24px' }}>
            <button
              onClick={() => setStep('overview')}
              style={{
                display: 'flex', alignItems: 'center', gap: '5px',
                background: 'none', border: 'none', cursor: 'pointer', padding: 0,
                fontSize: '14px', color: C.ink2, fontFamily: C.sans, marginBottom: '20px',
              }}
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                <path d="M19 12H5M12 19l-7-7 7-7"/>
              </svg>
              Back
            </button>

            <p style={{
              fontFamily: C.serif, fontSize: '20px', fontWeight: 600,
              color: C.ink, marginBottom: '4px',
            }}>
              Connect to project
            </p>
            <p style={{ fontSize: '13px', color: C.ink3, fontFamily: C.sans, marginBottom: '20px' }}>
              Link this resource to an active project.
            </p>

            {/* Project card */}
            <div style={{
              backgroundColor: C.panel, borderRadius: '16px',
              boxShadow: `0 0 0 1px ${C.edge}`, marginBottom: '16px', overflow: 'hidden',
            }}>
              <div style={{ padding: '14px 16px', borderBottom: `1px solid ${C.edge}` }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <div>
                    <p style={{
                      fontSize: '10px', letterSpacing: '0.1em', textTransform: 'uppercase',
                      color: C.coral, fontFamily: C.sans, fontWeight: 600, marginBottom: '3px',
                    }}>
                      Active project
                    </p>
                    <p style={{ fontSize: '15px', fontWeight: 600, color: C.ink, fontFamily: C.sans }}>
                      Thinketh — HackGT
                    </p>
                  </div>
                  <div style={{
                    width: '36px', height: '36px', borderRadius: '10px',
                    backgroundColor: C.coralTint, display: 'flex', alignItems: 'center', justifyContent: 'center',
                  }}>
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke={C.coral} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                      <rect x="3" y="3" width="18" height="18" rx="2"/>
                      <path d="M3 9h18M9 21V9"/>
                    </svg>
                  </div>
                </div>
              </div>

              <div style={{ padding: '14px 16px', backgroundColor: C.fog }}>
                <p style={{
                  fontSize: '10px', letterSpacing: '0.1em', textTransform: 'uppercase',
                  color: C.ink3, fontFamily: C.sans, fontWeight: 500, marginBottom: '8px',
                }}>
                  How this applies
                </p>
                <p style={{ fontSize: '13px', color: C.ink, fontFamily: C.sans, lineHeight: 1.55 }}>
                  This article may help you decide which parts of the ingestion pipeline should be deterministic workflows and which require agentic behavior.
                </p>
              </div>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', marginBottom: '16px' }}>
              <button
                onClick={() => { setConnectedToProject(true); setStep('overview'); }}
                style={{
                  padding: '14px', borderRadius: '12px',
                  backgroundColor: C.ink, border: 'none', cursor: 'pointer',
                  fontSize: '14px', fontWeight: 600, color: '#fff', fontFamily: C.sans,
                }}
              >
                Add to project learning
              </button>
              <button
                style={{
                  padding: '12px', borderRadius: '12px',
                  backgroundColor: C.panel, border: `1px solid ${C.edge}`,
                  cursor: 'pointer', fontSize: '13px', color: C.ink2, fontFamily: C.sans,
                }}
              >
                Ask how to apply this
              </button>
              <button
                onClick={() => setStep('overview')}
                style={{
                  padding: '12px', borderRadius: '12px',
                  backgroundColor: C.panel, border: `1px solid ${C.edge}`,
                  cursor: 'pointer', fontSize: '13px', color: C.ink3, fontFamily: C.sans,
                }}
              >
                Leave unconnected
              </button>
            </div>
          </div>
        )}
      </div>

      <BottomNav activeTab={activeTab} onTabChange={onTabChange} onNavigate={onNavigate} />
    </div>
  );
}
