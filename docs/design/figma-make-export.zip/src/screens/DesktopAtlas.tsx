import { useState } from 'react';
import KnowledgeAtlas from '../components/KnowledgeAtlas';
import type { AtlasFilter } from '../components/KnowledgeAtlas';
import { NODES, EDGES } from '../components/KnowledgeAtlas';
import type { Screen } from '../types';

const C = {
  coral: '#C0553A',
  coralTint: '#F7EAE6',
  ground: '#F6F5F2',
  panel: '#FFFFFF',
  ink: '#1A1918',
  ink2: '#6B6560',
  ink3: '#A09A93',
  fog: '#EEEAE4',
  edge: '#E6E2DA',
  warmTint: '#FAF5EF',
  sans: "'Inter', system-ui, sans-serif",
  serif: "'Playfair Display', Georgia, serif",
};

const STATE_LABEL: Record<string, string> = {
  established: 'Established',
  developing: 'Developing',
  new: 'Emerging',
  emerging: 'Emerging',
  unfamiliar: 'Unfamiliar',
};

const STATE_COLOR: Record<string, string> = {
  established: C.ink,
  developing: C.ink2,
  new: C.coral,
  emerging: C.ink3,
  unfamiliar: '#C8C3BB',
};

const FILTER_OPTIONS: { id: AtlasFilter; label: string }[] = [
  { id: 'all', label: 'All' },
  { id: 'today', label: 'Changed today' },
  { id: 'concepts', label: 'Concepts' },
  { id: 'companies', label: 'Companies' },
  { id: 'models', label: 'Models' },
  { id: 'papers', label: 'Papers' },
];

const CONCEPT_SUMMARIES: Record<string, { state: string; understanding: string; updated: string; related: string[]; next: string }> = {
  'agent-memory': {
    state: 'developing',
    understanding: "You understand how Claude uses tools and maintains context within a session. You now know that memory can persist across separate sessions via the persistent memory API.",
    updated: 'Sep 22, 2026',
    related: ['Persistent Memory', 'Tool Use', 'Long-running Agents', 'Claude'],
    next: 'Context Engineering',
  },
  'persistent-memory': {
    state: 'new',
    understanding: 'Persistent memory allows agents to retain useful context across separate sessions, enabling longer-running workflows that behave like persistent software workers.',
    updated: 'Sep 22, 2026 · Added today',
    related: ['Agent Memory', 'Long-running Agents', 'Claude', 'Tool Use'],
    next: 'Long-running Agents',
  },
  'claude': {
    state: 'established',
    understanding: "Strong working understanding of Claude's API, capabilities, and tool-use patterns. You actively build agent workflows with it.",
    updated: 'Sep 22, 2026',
    related: ['Foundation Models', 'Tool Use', 'Agent Memory', 'MCP'],
    next: 'Context Engineering',
  },
  'tool-use': {
    state: 'established',
    understanding: 'You understand how LLMs call external tools, handle structured outputs, and chain multi-step actions within agent loops.',
    updated: 'No recent changes',
    related: ['Agent Architecture', 'MCP', 'Agent Memory', 'Context Engineering'],
    next: 'Agent Memory',
  },
  'mcp': {
    state: 'developing',
    understanding: 'You understand the Model Context Protocol as a standard for connecting AI models to external tools and data sources.',
    updated: 'No recent changes',
    related: ['Developer Tooling', 'Tool Use', 'Claude', 'Context Engineering'],
    next: 'Context Engineering',
  },
};

const DEFAULT_SUMMARY = {
  state: 'emerging',
  understanding: 'This concept is adjacent to your current understanding. Continue learning to build a clearer mental model.',
  updated: 'No recent changes',
  related: [] as string[],
  next: 'Agent Memory',
};

export default function DesktopAtlas({ onNavigate }: { onNavigate: (s: Screen) => void }) {
  const [filter, setFilter] = useState<AtlasFilter>('all');
  const [selectedId, setSelectedId] = useState<string | null>('agent-memory');

  const selectedNode = NODES.find(n => n.id === selectedId);
  const summary = selectedId ? (CONCEPT_SUMMARIES[selectedId] ?? DEFAULT_SUMMARY) : null;

  const connectedIds = selectedId
    ? EDGES.filter(e => e.from === selectedId || e.to === selectedId)
        .map(e => (e.from === selectedId ? e.to : e.from))
    : [];

  return (
    <div style={{
      position: 'fixed', inset: 0, zIndex: 100,
      backgroundColor: C.ground,
      display: 'flex', flexDirection: 'column',
      fontFamily: C.sans,
    }}>
      {/* Top bar */}
      <div style={{
        flexShrink: 0,
        height: '56px',
        borderBottom: `1px solid ${C.edge}`,
        display: 'flex', alignItems: 'center',
        padding: '0 28px',
        backgroundColor: C.panel,
        gap: '20px',
      }}>
        {/* Wordmark */}
        <button
          onClick={() => onNavigate('library')}
          style={{
            background: 'none', border: 'none', cursor: 'pointer', padding: 0,
            display: 'flex', alignItems: 'center', gap: '8px',
          }}
        >
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke={C.ink3} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
            <path d="M19 12H5M12 19l-7-7 7-7"/>
          </svg>
          <span style={{
            fontFamily: C.serif, fontSize: '16px', fontWeight: 600,
            color: C.ink, letterSpacing: '-0.02em',
          }}>
            Thinketh
          </span>
        </button>

        <div style={{ width: '1px', height: '18px', backgroundColor: C.edge }} />

        <p style={{
          fontSize: '13px', color: C.ink2,
          flex: 1,
        }}>
          Your Knowledge Atlas
        </p>

        {/* Filter chips */}
        <div style={{ display: 'flex', gap: '6px' }}>
          {FILTER_OPTIONS.map(f => (
            <button
              key={f.id}
              onClick={() => setFilter(f.id)}
              style={{
                padding: '5px 12px', borderRadius: '100px',
                border: 'none', cursor: 'pointer',
                fontSize: '12px', fontWeight: 500,
                fontFamily: C.sans,
                backgroundColor: filter === f.id
                  ? (f.id === 'today' ? C.coral : C.ink)
                  : 'transparent',
                color: filter === f.id ? '#fff' : C.ink3,
                boxShadow: filter === f.id ? 'none' : `0 0 0 1px ${C.edge}`,
                transition: 'all 0.15s',
              }}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* Body: atlas + detail panel */}
      <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>

        {/* Atlas canvas */}
        <div style={{ flex: 1, position: 'relative', overflow: 'hidden' }}>
          {filter === 'today' && (
            <div style={{
              position: 'absolute', top: '20px', left: '24px', zIndex: 10,
              backgroundColor: C.coralTint, borderRadius: '12px',
              padding: '10px 14px',
              display: 'flex', alignItems: 'flex-start', gap: '8px',
              maxWidth: '320px',
            }}>
              <div style={{
                width: '6px', height: '6px', borderRadius: '50%',
                backgroundColor: C.coral, flexShrink: 0, marginTop: '5px',
              }} />
              <div>
                <p style={{ fontSize: '12px', fontWeight: 600, color: C.ink, marginBottom: '2px' }}>
                  1 concept updated today
                </p>
                <p style={{ fontSize: '11px', color: C.ink2, lineHeight: 1.4 }}>
                  Persistent Memory connected to Agent Memory, Claude, and Long-running Agents.
                </p>
              </div>
            </div>
          )}

          <KnowledgeAtlas
            mode="full"
            showNewNode={true}
            filterMode={filter}
            onNodeTap={setSelectedId}
            style={{ width: '100%', height: '100%' }}
          />
        </div>

        {/* Right detail panel */}
        <div style={{
          width: '320px', flexShrink: 0,
          borderLeft: `1px solid ${C.edge}`,
          backgroundColor: C.panel,
          display: 'flex', flexDirection: 'column',
          overflow: 'hidden',
        }}>
          {selectedNode && summary ? (
            <>
              {/* Panel header */}
              <div style={{
                padding: '24px 24px 18px',
                borderBottom: `1px solid ${C.edge}`,
                flexShrink: 0,
              }}>
                <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: '8px' }}>
                  <h2 style={{
                    fontFamily: C.serif, fontSize: '22px', fontWeight: 600,
                    color: C.ink, letterSpacing: '-0.02em', lineHeight: 1.2,
                    flex: 1,
                  }}>
                    {selectedNode.label}
                  </h2>
                  <button
                    onClick={() => setSelectedId(null)}
                    style={{
                      background: 'none', border: 'none', cursor: 'pointer',
                      color: C.ink3, fontSize: '20px', padding: '0 0 0 8px',
                      lineHeight: 1,
                    }}
                  >
                    ×
                  </button>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                  <div style={{
                    width: '7px', height: '7px', borderRadius: '50%',
                    backgroundColor: STATE_COLOR[summary.state],
                    flexShrink: 0,
                  }} />
                  <span style={{
                    fontSize: '12px', color: STATE_COLOR[summary.state],
                    fontWeight: 500,
                  }}>
                    {STATE_LABEL[summary.state]}
                  </span>
                  {summary.state === 'new' && (
                    <span style={{
                      fontSize: '9px', letterSpacing: '0.08em', textTransform: 'uppercase',
                      backgroundColor: C.coralTint, color: C.coral,
                      padding: '2px 7px', borderRadius: '100px', fontWeight: 600,
                    }}>
                      New today
                    </span>
                  )}
                </div>
              </div>

              {/* Scrollable panel body */}
              <div style={{ flex: 1, overflowY: 'auto', padding: '20px 24px' }}>

                {/* Understanding */}
                <section style={{ marginBottom: '22px' }}>
                  <p style={{
                    fontSize: '10px', letterSpacing: '0.1em', textTransform: 'uppercase',
                    color: C.ink3, fontWeight: 600, marginBottom: '8px',
                  }}>
                    What you understand
                  </p>
                  <p style={{
                    fontFamily: C.serif, fontSize: '14px', fontStyle: 'italic',
                    color: C.ink2, lineHeight: 1.6,
                  }}>
                    "{summary.understanding}"
                  </p>
                </section>

                {/* Last updated */}
                <section style={{
                  marginBottom: '22px',
                  padding: '10px 12px',
                  backgroundColor: C.fog,
                  borderRadius: '10px',
                  display: 'flex', alignItems: 'center', gap: '8px',
                }}>
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke={C.ink3} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="12" cy="12" r="10"/>
                    <polyline points="12 6 12 12 16 14"/>
                  </svg>
                  <p style={{ fontSize: '11px', color: C.ink2 }}>
                    {summary.updated}
                  </p>
                </section>

                {/* Connected concepts */}
                {summary.related.length > 0 && (
                  <section style={{ marginBottom: '22px' }}>
                    <p style={{
                      fontSize: '10px', letterSpacing: '0.1em', textTransform: 'uppercase',
                      color: C.ink3, fontWeight: 600, marginBottom: '10px',
                    }}>
                      Related concepts
                    </p>
                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
                      {summary.related.map(r => {
                        const relNode = NODES.find(n => n.label === r);
                        const isConnected = relNode && connectedIds.includes(relNode.id);
                        return (
                          <button
                            key={r}
                            onClick={() => relNode && setSelectedId(relNode.id)}
                            style={{
                              padding: '6px 12px', borderRadius: '100px',
                              border: 'none', cursor: relNode ? 'pointer' : 'default',
                              fontSize: '12px', fontFamily: C.sans,
                              backgroundColor: isConnected ? C.coralTint : C.fog,
                              color: isConnected ? C.coral : C.ink2,
                              fontWeight: isConnected ? 500 : 400,
                            }}
                          >
                            {r}
                          </button>
                        );
                      })}
                    </div>
                  </section>
                )}

                {/* Knowledge graph connections */}
                <section style={{ marginBottom: '22px' }}>
                  <p style={{
                    fontSize: '10px', letterSpacing: '0.1em', textTransform: 'uppercase',
                    color: C.ink3, fontWeight: 600, marginBottom: '10px',
                  }}>
                    Graph connections
                  </p>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                    {EDGES
                      .filter(e => e.from === selectedId || e.to === selectedId)
                      .map(edge => {
                        const otherId = edge.from === selectedId ? edge.to : edge.from;
                        const other = NODES.find(n => n.id === otherId);
                        if (!other) return null;
                        return (
                          <div
                            key={edge.id}
                            style={{
                              display: 'flex', alignItems: 'center', gap: '8px',
                              padding: '6px 0',
                              borderBottom: `1px solid ${C.edge}`,
                            }}
                          >
                            <div style={{
                              width: '6px', height: '6px', borderRadius: '50%',
                              backgroundColor: edge.isNew ? C.coral : STATE_COLOR[other.state],
                              flexShrink: 0,
                            }} />
                            <span style={{
                              fontSize: '12px', color: C.ink, flex: 1,
                              cursor: 'pointer',
                            }}
                            onClick={() => setSelectedId(otherId)}
                            >
                              {other.label}
                            </span>
                            <span style={{
                              fontSize: '10px', color: C.ink3,
                            }}>
                              {edge.solid ? '——' : '- - -'}
                            </span>
                            {edge.isNew && (
                              <span style={{
                                fontSize: '9px', color: C.coral, fontWeight: 600,
                                letterSpacing: '0.06em', textTransform: 'uppercase',
                              }}>new</span>
                            )}
                          </div>
                        );
                      })
                    }
                  </div>
                </section>

                {/* Suggested next */}
                <section style={{
                  padding: '14px 16px',
                  backgroundColor: C.warmTint,
                  borderRadius: '12px',
                  marginBottom: '16px',
                }}>
                  <p style={{
                    fontSize: '10px', letterSpacing: '0.1em', textTransform: 'uppercase',
                    color: C.ink3, fontWeight: 600, marginBottom: '6px',
                  }}>
                    Suggested next
                  </p>
                  <p style={{ fontSize: '13px', color: C.ink, fontWeight: 500, marginBottom: '10px' }}>
                    {summary.next}
                  </p>
                  <button
                    onClick={() => {
                      const next = NODES.find(n => n.label === summary.next);
                      if (next) setSelectedId(next.id);
                    }}
                    style={{
                      padding: '7px 14px', borderRadius: '100px',
                      backgroundColor: C.ink, color: '#fff',
                      border: 'none', cursor: 'pointer',
                      fontSize: '12px', fontWeight: 500, fontFamily: C.sans,
                    }}
                  >
                    Explore concept
                  </button>
                </section>

                {/* Ask Thinketh */}
                <button style={{
                  width: '100%', padding: '12px',
                  backgroundColor: 'transparent',
                  border: `1px solid ${C.edge}`,
                  borderRadius: '12px',
                  cursor: 'pointer',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px',
                  fontSize: '13px', color: C.ink2, fontFamily: C.sans,
                  fontWeight: 500,
                }}>
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
                  </svg>
                  Ask Thinketh about this
                </button>
              </div>
            </>
          ) : (
            /* Empty state */
            <div style={{
              flex: 1, display: 'flex', flexDirection: 'column',
              alignItems: 'center', justifyContent: 'center',
              padding: '40px 24px', textAlign: 'center',
            }}>
              <div style={{
                width: '48px', height: '48px', borderRadius: '50%',
                backgroundColor: C.fog, display: 'flex', alignItems: 'center', justifyContent: 'center',
                marginBottom: '16px',
              }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={C.ink3} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="11" cy="11" r="8"/>
                  <line x1="21" y1="21" x2="16.65" y2="16.65"/>
                </svg>
              </div>
              <p style={{ fontSize: '14px', color: C.ink, marginBottom: '6px', fontWeight: 500 }}>
                Select a concept
              </p>
              <p style={{ fontSize: '13px', color: C.ink3, lineHeight: 1.5 }}>
                Tap any node on the atlas to inspect your understanding of it.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
