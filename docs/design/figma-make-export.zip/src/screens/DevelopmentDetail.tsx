import { useState } from 'react';
import BottomNav from '../components/BottomNav';
import type { ScreenProps } from '../types';
import storyImg from '../imports/ChatGPT_Image_Sep_22__2026_at_11_27_38_AM__2_.png';

const C = {
  coral: '#C0553A',
  coralTint: '#F7EAE6',
  ground: '#F6F5F2',
  panel: '#FFFFFF',
  ink: '#1A1918',
  ink2: '#6B6560',
  ink3: '#A09A93',
  fog: '#EEEAE4',
  warmTint: '#F5F0E8',
  edge: '#E6E2DA',
  serif: "'Playfair Display', Georgia, serif",
  sans: "'Inter', system-ui, sans-serif",
};

const relatedTopics = ['Agent Memory', 'Claude', 'Tool Use', 'Long-running Agents', 'Context Engineering'];

const majorReasons = [
  'High source credibility',
  'Changes agent capabilities',
  'Relevant to your work',
  'Connected to an active storyline',
];

export default function DevelopmentDetail({ onNavigate, activeTab, onTabChange }: ScreenProps) {
  const [majorExpanded, setMajorExpanded] = useState(false);
  const [saved, setSaved] = useState(false);
  const [showToast, setShowToast] = useState(false);
  const [showOrganize, setShowOrganize] = useState(false);
  const [toastDismissed, setToastDismissed] = useState(false);
  const [savedSources, setSavedSources] = useState<Set<number>>(new Set());
  const [savedGoDeeper, setSavedGoDeeper] = useState<Set<number>>(new Set());
  const [sourceToastIdx, setSourceToastIdx] = useState<number | null>(null);

  const handleSave = () => {
    if (saved) return;
    setSaved(true);
    setShowToast(true);
    setTimeout(() => {
      setToastDismissed(true);
      setTimeout(() => { setShowToast(false); setToastDismissed(false); }, 300);
    }, 4000);
  };

  const handleSaveSource = (i: number, set: Set<number>, setter: (fn: (s: Set<number>) => Set<number>) => void) => {
    if (set.has(i)) return;
    setter(s => new Set(s).add(i));
    setSourceToastIdx(i);
    setTimeout(() => setSourceToastIdx(null), 2500);
  };

  return (
    <div className="flex flex-col h-full" style={{ backgroundColor: C.ground }}>
      <div className="flex-1 overflow-y-auto pb-0">

        {/* ── Back nav ──────────────────────────────────────── */}
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          padding: '44px 20px 20px',
        }}>
          <button
            onClick={() => onNavigate('today')}
            style={{
              display: 'flex', alignItems: 'center', gap: '5px',
              background: 'none', border: 'none', cursor: 'pointer', padding: 0,
              fontSize: '14px', color: C.ink2, fontFamily: C.sans,
            }}
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
              <path d="M19 12H5M12 19l-7-7 7-7"/>
            </svg>
            Today
          </button>
          <button
            onClick={handleSave}
            style={{
              background: 'none', border: 'none', cursor: saved ? 'default' : 'pointer', padding: '4px',
              color: saved ? C.coral : C.ink3, transition: 'color 0.2s',
            }}
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill={saved ? C.coral : 'none'} stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
              <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>
            </svg>
          </button>
        </div>

        {/* Save toast */}
        {showToast && (
          <div style={{
            position: 'fixed', bottom: '90px', left: '50%', transform: 'translateX(-50%)',
            zIndex: 50, display: 'flex', alignItems: 'center', gap: '10px',
            backgroundColor: C.ink, borderRadius: '100px', padding: '10px 16px',
            boxShadow: '0 4px 20px rgba(0,0,0,0.18)',
            opacity: toastDismissed ? 0 : 1, transition: 'opacity 0.3s',
            whiteSpace: 'nowrap',
          }}>
            <span style={{ fontSize: '13px', color: '#fff', fontFamily: C.sans }}>
              Saved to your Learning Queue
            </span>
            <button
              onClick={() => setShowOrganize(true)}
              style={{
                background: 'none', border: `1px solid rgba(255,255,255,0.3)`,
                borderRadius: '100px', padding: '3px 10px', cursor: 'pointer',
                fontSize: '12px', color: 'rgba(255,255,255,0.8)', fontFamily: C.sans,
              }}
            >
              Organize
            </button>
          </div>
        )}

        {/* Organize bottom sheet */}
        {showOrganize && (
          <div
            style={{
              position: 'fixed', inset: 0, zIndex: 60,
              backgroundColor: 'rgba(0,0,0,0.25)',
              display: 'flex', alignItems: 'flex-end',
            }}
            onClick={() => setShowOrganize(false)}
          >
            <div
              style={{
                width: '100%', backgroundColor: C.panel,
                borderRadius: '24px 24px 0 0', padding: '24px 20px 40px',
              }}
              onClick={e => e.stopPropagation()}
            >
              <div style={{
                width: '36px', height: '4px', borderRadius: '2px',
                backgroundColor: C.edge, margin: '0 auto 20px',
              }} />
              <p style={{
                fontFamily: C.serif, fontSize: '20px', fontWeight: 600,
                color: C.ink, marginBottom: '20px',
              }}>
                Save this to learn
              </p>

              <p style={{
                fontSize: '10px', letterSpacing: '0.1em', textTransform: 'uppercase',
                color: C.ink3, fontFamily: C.sans, fontWeight: 500, marginBottom: '8px',
              }}>
                Destination
              </p>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', marginBottom: '20px' }}>
                {['Learning Queue', 'Reliable Production Agents path', 'Thinketh — HackGT project'].map((dest, i) => (
                  <button key={dest} style={{
                    padding: '11px 14px', borderRadius: '10px', textAlign: 'left',
                    backgroundColor: i === 0 ? C.ink : C.fog,
                    border: 'none', cursor: 'pointer',
                    fontSize: '13px', color: i === 0 ? '#fff' : C.ink2, fontFamily: C.sans,
                  }}>
                    {dest}
                  </button>
                ))}
              </div>

              <p style={{
                fontSize: '10px', letterSpacing: '0.1em', textTransform: 'uppercase',
                color: C.ink3, fontFamily: C.sans, fontWeight: 500, marginBottom: '8px',
              }}>
                Relevant concepts
              </p>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px', marginBottom: '20px' }}>
                {['Agent Architecture', 'Tool Use', 'Agent Memory'].map(c => (
                  <span key={c} style={{
                    padding: '5px 10px', borderRadius: '100px',
                    backgroundColor: C.coralTint, border: `1px solid ${C.coral}`,
                    fontSize: '12px', color: C.coral, fontFamily: C.sans,
                  }}>
                    {c}
                  </span>
                ))}
              </div>

              <p style={{
                fontSize: '10px', letterSpacing: '0.1em', textTransform: 'uppercase',
                color: C.ink3, fontFamily: C.sans, fontWeight: 500, marginBottom: '8px',
              }}>
                Learning intention
              </p>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', marginBottom: '24px' }}>
                {['Understand the central idea', 'Go deep technically', 'Apply this to a project', 'Revisit later'].map((intent, i) => (
                  <button key={intent} style={{
                    padding: '11px 14px', borderRadius: '10px', textAlign: 'left',
                    backgroundColor: i === 0 ? C.coralTint : C.fog,
                    border: `1px solid ${i === 0 ? C.coral : 'transparent'}`,
                    cursor: 'pointer', fontSize: '13px',
                    color: i === 0 ? C.coral : C.ink2, fontFamily: C.sans,
                  }}>
                    {intent}
                  </button>
                ))}
              </div>

              <button
                onClick={() => setShowOrganize(false)}
                style={{
                  width: '100%', padding: '15px', borderRadius: '14px',
                  backgroundColor: C.ink, border: 'none', cursor: 'pointer',
                  fontSize: '14px', fontWeight: 600, color: '#fff', fontFamily: C.sans,
                }}
              >
                Save to learn
              </button>
            </div>
          </div>
        )}

        {/* ── Headline section ──────────────────────────────── */}
        <div style={{ padding: '0 20px 24px', position: 'relative' }}>
          {/* Source + meta row — 2-line layout */}
          <div style={{
            display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between',
            marginBottom: '14px',
          }}>
            <div>
              <p style={{
                fontSize: '10px', letterSpacing: '0.12em', textTransform: 'uppercase',
                fontWeight: 700, color: C.ink2, fontFamily: C.sans, marginBottom: '4px',
              }}>
                Anthropic
              </p>
              <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
                <span style={{
                  width: '6px', height: '6px', borderRadius: '50%',
                  backgroundColor: C.coral, display: 'inline-block', flexShrink: 0,
                }} />
                <span style={{ fontSize: '10px', color: C.ink3, fontFamily: C.sans, fontWeight: 500 }}>
                  HIGH IMPACT · 2h ago
                </span>
              </div>
            </div>
            <div style={{ flexShrink: 0 }}>
              <button
                onClick={() => setMajorExpanded(v => !v)}
                style={{
                  backgroundColor: C.coralTint, borderRadius: '6px', padding: '5px 10px',
                  border: 'none', cursor: 'pointer',
                  display: 'flex', alignItems: 'center', gap: '4px',
                }}
              >
                <span style={{ fontSize: '10px', color: C.coral, fontFamily: C.sans, fontWeight: 600, letterSpacing: '0.04em' }}>
                  Major development
                </span>
                <svg
                  width="10" height="10" viewBox="0 0 24 24" fill="none"
                  stroke={C.coral} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"
                  style={{ transition: 'transform 0.2s', transform: majorExpanded ? 'rotate(180deg)' : 'none' }}
                >
                  <polyline points="6 9 12 15 18 9"/>
                </svg>
              </button>
              {majorExpanded && (
                <div style={{
                  position: 'absolute', right: '20px', top: '70px',
                  backgroundColor: C.panel, borderRadius: '12px', padding: '12px 14px',
                  boxShadow: '0 4px 16px rgba(0,0,0,0.1)', zIndex: 20, minWidth: '200px',
                }}>
                  <p style={{ fontSize: '11px', color: C.ink3, fontFamily: C.sans, marginBottom: '8px' }}>
                    Why this is a major development
                  </p>
                  {majorReasons.map((r, i) => (
                    <div key={i} style={{ display: 'flex', alignItems: 'center', gap: '7px', marginBottom: '6px' }}>
                      <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke={C.coral} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                        <polyline points="20 6 9 17 4 12"/>
                      </svg>
                      <span style={{ fontSize: '12px', color: C.ink2, fontFamily: C.sans }}>{r}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Title */}
          <h1 style={{
            fontFamily: C.serif, fontSize: '30px', lineHeight: 1.16,
            letterSpacing: '-0.02em', color: C.ink, marginBottom: '14px', fontWeight: 600,
          }}>
            Anthropic expands long-term agent memory
          </h1>

          {/* Summary */}
          <p style={{
            fontSize: '15px', color: C.ink2, fontFamily: C.sans,
            lineHeight: 1.6, marginBottom: '0',
          }}>
            Anthropic introduced a persistent memory system for Claude, allowing agents to retain context across sessions, tools, and longer time horizons.
          </p>
        </div>

        {/* ── Full-width editorial image ──────────────────── */}
        <div style={{ width: '100%', height: '200px', backgroundColor: C.fog, overflow: 'hidden', marginBottom: '20px' }}>
          <img
            src={storyImg}
            alt="Build more capable agents"
            style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }}
          />
        </div>

        {/* ── Content sections — live on background, separated by rules ── */}
        <div style={{ padding: '0 24px' }}>

          {/* What happened */}
          <div style={{ padding: '20px 0', borderTop: `1px solid ${C.edge}` }}>
            <p style={{
              fontSize: '10px', letterSpacing: '0.1em', textTransform: 'uppercase',
              fontWeight: 600, color: C.ink3, fontFamily: C.sans, marginBottom: '12px',
            }}>
              What happened
            </p>
            <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'flex', flexDirection: 'column', gap: '8px' }}>
              {[
                'Anthropic launched a persistent memory system for Claude.',
                'Agents can retain context across sessions, tools, and time.',
                'Designed for longer-running, more capable agents in real-world workflows.',
              ].map((item, i) => (
                <li key={i} style={{ display: 'flex', alignItems: 'flex-start', gap: '10px' }}>
                  <span style={{
                    width: '4px', height: '4px', borderRadius: '50%',
                    backgroundColor: C.coral, flexShrink: 0, marginTop: '8px',
                  }} />
                  <span style={{ fontSize: '14px', color: C.ink2, fontFamily: C.sans, lineHeight: 1.55 }}>
                    {item}
                  </span>
                </li>
              ))}
            </ul>
          </div>

          {/* Why this matters */}
          <div style={{ padding: '20px 0', borderTop: `1px solid ${C.edge}` }}>
            <p style={{
              fontSize: '10px', letterSpacing: '0.1em', textTransform: 'uppercase',
              fontWeight: 600, color: C.coral, fontFamily: C.sans, marginBottom: '10px',
            }}>
              Why this matters to you
            </p>
            <p style={{ fontSize: '14px', color: C.ink, fontFamily: C.sans, lineHeight: 1.65 }}>
              You follow agentic AI and developer tools. This unlocks more reliable, autonomous workflows — agents that remember your preferences, carry context across sessions, and behave less like isolated tasks.
            </p>
          </div>

          {/* Knowledge delta — before / after */}
          <div style={{ padding: '20px 0', borderTop: `1px solid ${C.edge}` }}>
          <div style={{ borderRadius: '16px', overflow: 'hidden', boxShadow: '0 1px 8px rgba(0,0,0,0.06)' }}>
            {/* Header strip */}
            <div style={{
              backgroundColor: C.ink, padding: '14px 18px 12px',
              display: 'flex', alignItems: 'center', gap: '8px',
            }}>
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.7)" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="12" cy="12" r="10"/>
                <line x1="12" y1="8" x2="12" y2="12"/>
                <line x1="12" y1="16" x2="12.01" y2="16"/>
              </svg>
              <p style={{
                fontSize: '11px', letterSpacing: '0.1em', textTransform: 'uppercase',
                color: 'rgba(255,255,255,0.6)', fontFamily: C.sans, fontWeight: 500,
              }}>
                How this updates your mental model
              </p>
            </div>

            {/* Before */}
            <div style={{
              backgroundColor: C.fog, padding: '16px 18px',
              borderBottom: `1px solid ${C.edge}`,
            }}>
              <p style={{
                fontSize: '10px', letterSpacing: '0.1em', textTransform: 'uppercase',
                color: C.ink3, fontFamily: C.sans, fontWeight: 600, marginBottom: '8px',
              }}>
                What you already knew
              </p>
              <p style={{
                fontFamily: C.serif, fontSize: '14px', fontStyle: 'italic',
                color: C.ink2, lineHeight: 1.55,
              }}>
                "Claude can use tools and carry context within a single session — but that context resets when the session ends."
              </p>
            </div>

            {/* Arrow connector */}
            <div style={{
              backgroundColor: C.panel, padding: '8px 18px',
              display: 'flex', alignItems: 'center', gap: '10px',
              borderBottom: `1px solid ${C.edge}`,
            }}>
              <div style={{
                flex: 1, height: '1px',
                background: `linear-gradient(to right, ${C.edge}, ${C.coral})`,
              }} />
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke={C.coral} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <line x1="12" y1="5" x2="12" y2="19"/>
                <polyline points="19 12 12 19 5 12"/>
              </svg>
              <div style={{
                flex: 1, height: '1px',
                background: `linear-gradient(to left, ${C.edge}, ${C.coral})`,
              }} />
            </div>

            {/* After */}
            <div style={{ backgroundColor: C.coralTint, padding: '16px 18px' }}>
              <p style={{
                fontSize: '10px', letterSpacing: '0.1em', textTransform: 'uppercase',
                color: C.coral, fontFamily: C.sans, fontWeight: 600, marginBottom: '10px',
              }}>
                New understanding
              </p>
              <p style={{
                fontFamily: C.serif, fontSize: '15px', fontWeight: 600,
                color: C.ink, lineHeight: 1.5, marginBottom: '12px',
              }}>
                "Agents can now remember and build on past sessions — making them genuinely persistent collaborators."
              </p>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '7px' }}>
                {[
                  'Persistent memory survives session resets — context accumulates over days.',
                  'Designed for long-running agents, not just single-session tools.',
                  "Connects to Claude’s existing tool-use and MCP architecture.",
                ].map((point, i) => (
                  <div key={i} style={{ display: 'flex', alignItems: 'flex-start', gap: '8px' }}>
                    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke={C.coral} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" style={{ flexShrink: 0, marginTop: '2px' }}>
                      <polyline points="20 6 9 17 4 12"/>
                    </svg>
                    <span style={{ fontSize: '12px', color: C.ink, fontFamily: C.sans, lineHeight: 1.5 }}>
                      {point}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
          </div>

          {/* Evidence and sources */}
          <div style={{ padding: '20px 0', borderTop: `1px solid ${C.edge}` }}>
            <p style={{
              fontSize: '10px', letterSpacing: '0.1em', textTransform: 'uppercase',
              fontWeight: 600, color: C.ink3, fontFamily: C.sans, marginBottom: '14px',
            }}>
              Evidence and sources
            </p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0' }}>
              {[
                {
                  type: 'Announcement',
                  publisher: 'Anthropic',
                  title: 'Persistent memory for Claude agents',
                  why: 'Primary source. Directly from the team that built the feature.',
                },
                {
                  type: 'Documentation',
                  publisher: 'Anthropic Docs',
                  title: 'Memory and state in the Claude API',
                  why: 'Technical reference. Explains exactly what the API exposes and how it works.',
                },
                {
                  type: 'Analysis',
                  publisher: 'Simon Willison',
                  title: 'Notes on Anthropic\'s persistent memory announcement',
                  why: 'Trusted independent commentary. Explains practical implications for developers.',
                },
                {
                  type: 'Paper',
                  publisher: 'arXiv 2409.14184',
                  title: 'Memory Mechanisms in Large Language Model Agents',
                  why: 'Research context. Situates this development within the broader memory architecture literature.',
                },
              ].map((src, i, arr) => (
                <div
                  key={i}
                  style={{
                    padding: '13px 0',
                    borderBottom: i < arr.length - 1 ? `1px solid ${C.edge}` : 'none',
                    cursor: 'pointer',
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '8px' }}>
                    <div style={{ flex: 1 }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '4px' }}>
                        <span style={{
                          fontSize: '9px', letterSpacing: '0.08em', textTransform: 'uppercase',
                          fontWeight: 600, color: C.ink3, fontFamily: C.sans,
                        }}>
                          {src.type}
                        </span>
                        <span style={{ color: C.edge, fontSize: '10px' }}>·</span>
                        <span style={{ fontSize: '10px', color: C.ink2, fontFamily: C.sans, fontWeight: 500 }}>
                          {src.publisher}
                        </span>
                      </div>
                      <p style={{
                        fontSize: '13px', color: C.ink, fontFamily: C.sans,
                        fontWeight: 500, lineHeight: 1.35, marginBottom: '4px',
                      }}>
                        {src.title}
                      </p>
                      <p style={{ fontSize: '11px', color: C.ink3, fontFamily: C.sans, lineHeight: 1.45 }}>
                        {src.why}
                      </p>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexShrink: 0, marginTop: '2px' }}>
                      <button
                        onClick={() => handleSaveSource(i, savedSources, setSavedSources)}
                        style={{
                          background: 'none', border: 'none', cursor: savedSources.has(i) ? 'default' : 'pointer',
                          padding: '2px', color: savedSources.has(i) ? C.coral : C.ink3, transition: 'color 0.15s',
                          display: 'flex', alignItems: 'center',
                        }}
                        title={savedSources.has(i) ? 'Saved to queue' : 'Save to Learning Queue'}
                      >
                        <svg width="14" height="14" viewBox="0 0 24 24" fill={savedSources.has(i) ? C.coral : 'none'} stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                          <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>
                        </svg>
                      </button>
                      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke={C.ink3} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>
                        <polyline points="15 3 21 3 21 9"/>
                        <line x1="10" y1="14" x2="21" y2="3"/>
                      </svg>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Related concepts */}
          <div style={{ padding: '20px 0', borderTop: `1px solid ${C.edge}` }}>
            <p style={{
              fontSize: '10px', letterSpacing: '0.1em', textTransform: 'uppercase',
              fontWeight: 600, color: C.ink3, fontFamily: C.sans, marginBottom: '12px',
            }}>
              Related concepts
            </p>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '7px' }}>
              {relatedTopics.map((t) => (
                <span
                  key={t}
                  style={{
                    fontSize: '12px', backgroundColor: C.fog, color: C.ink2,
                    padding: '6px 13px', borderRadius: '100px', fontFamily: C.sans,
                    cursor: 'pointer',
                  }}
                >
                  {t}
                </span>
              ))}
            </div>
          </div>

          {/* Go Deeper */}
          <div style={{ padding: '20px 0', borderTop: `1px solid ${C.edge}` }}>
            <p style={{
              fontSize: '10px', letterSpacing: '0.1em', textTransform: 'uppercase',
              fontWeight: 600, color: C.ink3, fontFamily: C.sans, marginBottom: '14px',
            }}>
              Go deeper
            </p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0' }}>
              {[
                {
                  title: 'Building Effective Agents',
                  publisher: 'Anthropic',
                  type: 'Technical article',
                  desc: 'Practical patterns for building reliable production agents.',
                  minutes: '6 useful min',
                },
                {
                  title: 'Memory Mechanisms in LLM Agents: A Survey',
                  publisher: 'arXiv',
                  type: 'Research paper',
                  desc: 'Architecture survey situating persistent memory within the broader agent memory literature.',
                  minutes: '12 useful min',
                },
              ].map((rec, i, arr) => (
                <div key={i} style={{
                  padding: '13px 0',
                  borderBottom: i < arr.length - 1 ? `1px solid ${C.edge}` : 'none',
                }}>
                  <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '8px' }}>
                    <div style={{ flex: 1 }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '4px' }}>
                        <span style={{ fontSize: '9px', letterSpacing: '0.08em', textTransform: 'uppercase', fontWeight: 600, color: C.ink3, fontFamily: C.sans }}>{rec.type}</span>
                        <span style={{ color: C.edge, fontSize: '10px' }}>·</span>
                        <span style={{ fontSize: '10px', color: C.ink2, fontFamily: C.sans, fontWeight: 500 }}>{rec.publisher}</span>
                        <span style={{ color: C.edge, fontSize: '10px' }}>·</span>
                        <span style={{ fontSize: '10px', color: C.coral, fontFamily: C.sans, fontWeight: 500 }}>{rec.minutes}</span>
                      </div>
                      <p style={{ fontSize: '13px', color: C.ink, fontFamily: C.sans, fontWeight: 500, lineHeight: 1.35, marginBottom: '3px' }}>{rec.title}</p>
                      <p style={{ fontSize: '11px', color: C.ink3, fontFamily: C.sans, lineHeight: 1.45 }}>{rec.desc}</p>
                    </div>
                    <button
                      onClick={() => handleSaveSource(i + 10, savedGoDeeper, setSavedGoDeeper)}
                      style={{
                        background: 'none', border: 'none', cursor: savedGoDeeper.has(i + 10) ? 'default' : 'pointer',
                        padding: '2px', color: savedGoDeeper.has(i + 10) ? C.coral : C.ink3,
                        transition: 'color 0.15s', flexShrink: 0, marginTop: '2px',
                        display: 'flex', alignItems: 'center',
                      }}
                      title={savedGoDeeper.has(i + 10) ? 'Saved to queue' : 'Save to Learning Queue'}
                    >
                      <svg width="16" height="16" viewBox="0 0 24 24" fill={savedGoDeeper.has(i + 10) ? C.coral : 'none'} stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>
                      </svg>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Source save mini-toast */}
          {sourceToastIdx !== null && (
            <div style={{
              position: 'fixed', bottom: '90px', left: '50%', transform: 'translateX(-50%)',
              zIndex: 55, backgroundColor: C.ink, borderRadius: '100px', padding: '9px 16px',
              boxShadow: '0 4px 20px rgba(0,0,0,0.18)', whiteSpace: 'nowrap',
              animation: 'fadeIn 0.2s ease',
            }}>
              <style>{`@keyframes fadeIn { from { opacity:0; transform:translateX(-50%) translateY(6px); } to { opacity:1; transform:translateX(-50%) translateY(0); } }`}</style>
              <span style={{ fontSize: '13px', color: '#fff', fontFamily: C.sans }}>Saved to your Learning Queue</span>
            </div>
          )}

          {/* Actions */}
          <div style={{ padding: '8px 0 4px' }}>
            <button
              onClick={() => onNavigate('quiz')}
              style={{
                width: '100%', backgroundColor: C.ink, color: '#FFFFFF',
                fontFamily: C.sans, fontWeight: 600, fontSize: '15px',
                padding: '15px 0', borderRadius: '14px',
                border: 'none', cursor: 'pointer', marginBottom: '8px',
                letterSpacing: '-0.01em',
              }}
            >
              Check my understanding
            </button>
            <p style={{
              textAlign: 'center', fontSize: '12px', color: C.ink3,
              fontFamily: C.sans, lineHeight: 1.4, marginBottom: '12px',
            }}>
              Three questions. Not a test — evidence of understanding.
            </p>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '20px' }}>
              <button style={{
                background: 'none', border: 'none', cursor: 'pointer', padding: '6px 0',
                fontSize: '13px', color: C.ink2, fontFamily: C.sans,
              }}>
                I already knew this
              </button>
              <span style={{ color: C.edge }}>·</span>
              <button style={{
                background: 'none', border: 'none', cursor: 'pointer', padding: '6px 0',
                fontSize: '13px', color: C.ink2, fontFamily: C.sans,
              }}>
                Explain deeper
              </button>
            </div>
          </div>

          <div style={{ height: '8px' }} />
        </div>
      </div>

      {/* ── Next in your catch-up sticky bar ──────────────── */}
      <div style={{
        flexShrink: 0,
        borderTop: `1px solid ${C.edge}`,
        backgroundColor: C.panel,
        padding: '10px 20px',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      }}>
        <div>
          <p style={{ fontSize: '10px', color: C.ink3, fontFamily: C.sans, letterSpacing: '0.04em', marginBottom: '1px' }}>
            Next in your catch-up
          </p>
          <p style={{ fontSize: '13px', color: C.ink, fontFamily: C.sans, fontWeight: 500 }}>
            Gemini 2.5 Pro goes multimodal natively
          </p>
        </div>
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke={C.ink3} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
          <path d="M5 12h14M12 5l7 7-7 7"/>
        </svg>
      </div>

      <BottomNav activeTab={activeTab} onTabChange={onTabChange} onNavigate={onNavigate} />
    </div>
  );
}
