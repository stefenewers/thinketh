import BottomNav from '../components/BottomNav';
import type { ScreenProps } from '../types';

const C = {
  coral: '#C0553A',
  coralTint: '#F7EAE6',
  ground: '#F6F5F2',
  panel: '#FFFFFF',
  ink: '#1A1918',
  ink2: '#6B6560',
  ink3: '#A09A93',
  fog: '#EEEAE4',
  edge: '#E6E2DA',
  sans: "'Inter', system-ui, sans-serif",
  serif: "'Playfair Display', Georgia, serif",
};

interface Recommendation {
  type: 'Storyline' | 'Explainer' | 'Deep Dive' | 'Paper' | 'Course';
  title: string;
  readTime: string;
  reason: string;
}

interface ReasonGroup {
  reason: string;
  reasonDetail: string;
  items: Recommendation[];
}

const GROUPS: ReasonGroup[] = [
  {
    reason: 'Builds on what you learned today',
    reasonDetail: 'Persistent Memory → these extend that understanding',
    items: [
      {
        type: 'Storyline',
        title: 'The rise of persistent agent memory',
        readTime: '6 min',
        reason: 'Traces how memory in agents evolved from workarounds to a first-class API primitive.',
      },
      {
        type: 'Explainer',
        title: 'What persistent memory changes about agent architecture',
        readTime: '4 min',
        reason: "Direct follow-on to today's development — the structural implications for how you build.",
      },
    ],
  },
  {
    reason: 'Strengthens a weak area',
    reasonDetail: 'Context Engineering is adjacent but underexplored in your Atlas',
    items: [
      {
        type: 'Deep Dive',
        title: 'Context engineering: what it is and why it matters',
        readTime: '8 min',
        reason: 'Your Atlas shows Context Engineering as developing. This closes the gap toward established.',
      },
      {
        type: 'Paper',
        title: 'Lost in the Middle: How Language Models Use Long Contexts',
        readTime: '12 min',
        reason: 'Explains why context position matters — a known blind spot in your retrieval understanding.',
      },
    ],
  },
  {
    reason: 'Connects two existing interests',
    reasonDetail: 'Agent Architecture ↔ Developer Tooling — both established in your Atlas',
    items: [
      {
        type: 'Explainer',
        title: 'How MCP bridges model capabilities and developer tools',
        readTime: '5 min',
        reason: 'Your Atlas has strong nodes in both domains. MCP is the explicit connection point.',
      },
    ],
  },
  {
    reason: 'Important emerging storyline',
    reasonDetail: 'Formal reasoning — adjacent to your foundation-model knowledge',
    items: [
      {
        type: 'Storyline',
        title: 'Mathematical reasoning in large language models',
        readTime: '7 min',
        reason: "AlphaProof's results this week open a new front in what reasoning models can do formally.",
      },
    ],
  },
];

const TYPE_COLORS: Record<string, string> = {
  Storyline: C.ink,
  Explainer: C.ink2,
  'Deep Dive': C.coral,
  Paper: C.ink2,
  Course: C.ink3,
};

export default function Explore({ onNavigate, activeTab, onTabChange }: ScreenProps) {
  return (
    <div className="flex flex-col h-full" style={{ backgroundColor: C.ground }}>
      <div className="flex-1 overflow-y-auto pb-4">

        {/* Header */}
        <div style={{ padding: '44px 24px 28px' }}>
          <p style={{
            fontSize: '11px', letterSpacing: '0.13em', textTransform: 'uppercase',
            fontWeight: 500, color: C.ink3, fontFamily: C.sans, marginBottom: '8px',
          }}>
            Explore
          </p>
          <h1 style={{
            fontFamily: C.serif, fontSize: '28px', lineHeight: 1.18,
            letterSpacing: '-0.02em', color: C.ink, fontWeight: 600,
            marginBottom: '8px',
          }}>
            Adjacent knowledge worth your time.
          </h1>
          <p style={{ fontSize: '13px', color: C.ink3, fontFamily: C.sans, lineHeight: 1.5 }}>
            Selected because it strengthens, connects, or extends what you already understand.
          </p>
        </div>

        {/* Reason groups */}
        <div style={{ padding: '0 24px', display: 'flex', flexDirection: 'column', gap: '40px' }}>
          {GROUPS.map((group) => (
            <div key={group.reason}>
              {/* Group header */}
              <div style={{ marginBottom: '16px' }}>
                <p style={{
                  fontSize: '13px', fontWeight: 600, color: C.ink,
                  fontFamily: C.sans, marginBottom: '3px',
                }}>
                  {group.reason}
                </p>
                <p style={{ fontSize: '11px', color: C.ink3, fontFamily: C.sans, fontStyle: 'italic' }}>
                  {group.reasonDetail}
                </p>
              </div>

              {/* Items */}
              <div style={{ borderTop: `1px solid ${C.edge}` }}>
                {group.items.map((item, i) => (
                  <div
                    key={i}
                    style={{
                      padding: '14px 0',
                      borderBottom: `1px solid ${C.edge}`,
                      cursor: 'pointer',
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '5px' }}>
                      <span style={{
                        fontSize: '9px', letterSpacing: '0.08em', textTransform: 'uppercase',
                        fontWeight: 600, color: TYPE_COLORS[item.type] ?? C.ink2, fontFamily: C.sans,
                      }}>
                        {item.type}
                      </span>
                      <span style={{ color: C.edge }}>·</span>
                      <span style={{ fontSize: '10px', color: C.ink3, fontFamily: C.sans }}>
                        {item.readTime} read
                      </span>
                    </div>

                    <p style={{
                      fontSize: '15px', color: C.ink, fontFamily: C.sans,
                      fontWeight: 500, lineHeight: 1.38, marginBottom: '5px',
                    }}>
                      {item.title}
                    </p>

                    <p style={{
                      fontSize: '12px', color: C.ink3, fontFamily: C.sans,
                      lineHeight: 1.45, fontStyle: 'italic',
                    }}>
                      {item.reason}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div style={{ height: '12px' }} />
      </div>

      <BottomNav activeTab={activeTab} onTabChange={onTabChange} onNavigate={onNavigate} />
    </div>
  );
}
