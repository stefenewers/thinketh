Design a high-fidelity, mobile-first product concept for an application called “thinketh,” created by the team P237.

This is a visual-design and prototyping exercise only. Do not generate production architecture or backend implementation. The goal is to establish the product’s visual direction, prototype its primary HackGT demo, and identify every content and visual artifact the team must prepare before development begins.

## Product

Thinketh is a personal AI intelligence and learning system for people trying to keep up with rapidly changing fields. The initial version focuses on artificial intelligence.

Thinketh processes many sources, removes duplicates and low-signal content, identifies the few developments that materially changed, and explains those changes relative to what the user already understands.

It is not another news reader.

Its core promise is:

“Your knowledge continuously updating itself as the world changes.”

Primary tagline:

“Understand what changed.”

Supporting idea:

“Your brain gets a software update.”

The central product distinction is that Thinketh does not merely track what someone reads. It maintains a model of what they understand.

## Core product concepts

Thinketh compares new information against two states:

1. World State: What was previously true, and what changed?
2. Personal Knowledge State: What did this user already understand, and what is genuinely new to them?

The basic unit is a “Development,” not an article.

Multiple reports about the same event should become one development. If nothing meaningfully changed, there should be no card.

Thinketh should make users feel:

* Calm rather than overwhelmed
* Intellectually sharper
* Confident that they are caught up
* Protective of their limited attention
* Motivated to learn more deeply

## Primary user

Design for a technically curious professional or student who follows AI, builds with AI tools, and wants to remain current without spending hours browsing X, newsletters, YouTube, GitHub, research papers, and company announcements.

Use this sample knowledge profile:

* Agent Tool Use — Intermediate
* Agent Memory — Beginner
* MCP — Intermediate
* Robotics — Beginner
* Developer Tooling — Advanced

## Primary HackGT demo flow

Create a polished, clickable mobile prototype covering this exact story:

### Screen 1: Morning Catch-Up

The user opens Thinketh after being away for several days.

Show:

Tuesday, September 22

“You missed 7 things worth knowing.”

“3 major developments”

“11-minute catch-up”

Primary action:

“Catch me up”

Include one visually prominent major development and a restrained preview of several additional developments.

Also include a subtle transparency element:

“143 items skipped for you”

When expanded, it can reveal:

* 68 duplicates
* 31 low-signal opinions
* 22 things you already understand
* 15 minor updates
* 7 low-confidence claims

This should communicate that Thinketh protects the user’s attention.

Bottom navigation:

Today · Library · Explore · Ask

### Screen 2: Development Detail

The user opens this major development:

“Anthropic expands long-term agent memory”

Design the page to teach, rather than merely summarize.

Include:

* Impact level
* Reading time
* Source credibility
* Date
* What happened
* Why this matters to you
* What you already knew
* What changed
* Mental-model change
* Go deeper
* Related topics
* Next development

Sample teaching content:

What you already knew:

“Agents can use tools and maintain context during an active session.”

What changed:

“Agents can now retain useful context across separate sessions and operate over longer time horizons.”

Mental-model change:

“Agents are beginning to behave less like isolated tasks and more like persistent software workers.”

Related topics:

* Agent Memory
* Claude
* Tool Use
* Long-running Agents
* Context Engineering

Go-deeper resources should include visually distinct entries for:

* Primary announcement
* Technical documentation
* Research paper
* GitHub repository
* Technical video

Include the primary action:

“Got it”

Also include quieter secondary actions:

“I already knew this”

“Explain deeper”

### Screen 3: Knowledge Update — Primary Wow Moment

After the user taps “Got it,” create a beautiful transition showing that their Personal Knowledge State has changed.

Example:

Agent Memory

42% → 51%

However, avoid making knowledge look like an arbitrary gamified score. Explore a more thoughtful visual treatment that may combine:

* A concept map becoming clearer
* A new connection appearing
* A topic changing from Beginner toward Developing
* A short explanation of exactly what understanding was added

Possible new relationship:

Agent Memory → Claude → Tool Use → Long-running Agents

Make this moment feel meaningful, intelligent, and emotionally rewarding.

The judge should immediately understand:

“Thinketh isn’t tracking what you read. Thinketh is tracking what you understand.”

### Screen 4: Updated Today View

Return the user to the catch-up experience.

Show:

* One development completed
* Updated remaining catch-up time
* Subtle progress without creating an addictive or childish interface
* The next most relevant development

### Screen 5: Knowledge Library

Design the Library as accumulated understanding, not saved bookmarks.

Include categories such as:

* Concepts
* Storylines
* Companies
* Models
* Papers
* Projects
* People

Show a featured storyline for “Agent Memory” across time:

* May: Context windows improve
* June: External memory architectures gain adoption
* August: Cross-session retrieval improves
* September: Native persistent memory appears

Include a compact representation of the user’s knowledge map. It should feel useful and understandable, not like a decorative web of random nodes.

The Library should answer:

“What do I know?”

### Screen 6: Ask Thinketh

Create a natural-language intelligence interface across both the global knowledge corpus and the user’s Personal Knowledge State.

Use suggested prompts:

* What changed in agent memory this month?
* Explain MCP based on what I already know.
* What developments this week should change how I build agents?
* What am I weakest on within agent architecture?

Show one example answer that references relevant developments, sources, previous learning, and the user’s current knowledge level.

## Visual direction

The desired feeling is:

Apple × Arc × Linear × premium editorial publishing

The interface must feel:

* Calm
* Intelligent
* Premium
* Minimal
* Deliberate
* Trustworthy
* Editorial
* Technically credible

The central design challenge is:

“Make dense information feel calm.”

Avoid:

* Generic vibe-coded SaaS
* Traditional admin dashboards
* AI gradient spam
* Crypto aesthetics
* Excessive glassmorphism
* Endless small cards
* Meaningless charts
* Random pills and badges
* Neon colors
* Generic chatbot layouts
* Decorative knowledge graphs with no functional meaning
* Excessive gamification

## Visual language

Use:

* Warm white or softly tinted editorial backgrounds
* Charcoal text
* Neutral grays
* A restrained muted coral or peach accent for meaningful developments
* Large editorial serif typography for major ideas and headlines
* Clean sans-serif typography for navigation, metadata, and explanations
* Generous whitespace
* Subtle dividers
* Very restrained shadows
* A consistent radius system
* Strong content hierarchy
* High readability on a mobile screen

Do not use arbitrary spacing or introduce unrelated visual patterns between screens.

Create a cohesive design system with:

* Color tokens
* Typography styles and scale
* Spacing scale
* Corner radii
* Borders
* Shadows
* Icon style
* Button hierarchy
* Card construction
* Navigation patterns
* Interaction states
* Impact indicators
* Source/resource patterns

Use accessible contrast and design for an iPhone-sized mobile viewport. Also include one responsive desktop interpretation of the Today experience to show how the visual language scales.

## Motion and interaction direction

Annotate the intended interaction and motion behavior.

Prioritize:

* A development card smoothly expanding into its detail page
* “Got it” triggering the knowledge-state update
* A concept relationship appearing after learning
* Storylines unfolding chronologically
* Catch-up progress changing after a completed development

Motion should communicate continuity and understanding, not spectacle.

Use subtle timing and avoid bouncy, playful, or overly dramatic animation.

## Required Figma pages

Organize the file into these pages:

1. Product Direction
2. Moodboard and Visual References
3. Design System
4. Mobile Screens
5. Clickable Demo Flow
6. Motion and Interaction Notes
7. Hackathon Artifact Checklist
8. Cut Scope and Stretch Ideas

## Hackathon Artifact Checklist

Create a dedicated preparation board identifying everything the team must have ready before coding begins.

Organize the board into these categories:

### Brand

* P237 wordmark or text treatment
* Thinketh wordmark
* App icon
* Tagline treatment
* Color palette
* Typography selections
* Logo usage rules

### Product Content

* Sample user profile
* Sample Personal Knowledge State
* Seven sample AI developments
* Impact level for each development
* Personalized relevance explanation for each
* “What you already knew” content
* “What changed” content
* Mental-model change for each
* Related topics
* Catch-up time estimates

### Source Assets

* Company logos
* Model and tool logos
* Source publication marks
* Author or researcher headshots, if needed
* Primary-source links
* Documentation links
* Research-paper links
* GitHub repository links
* Video thumbnails and links
* Source credibility labels

### Knowledge System

* Initial topic taxonomy
* Concept relationships
* Knowledge-level definitions
* Rules for updating knowledge state
* Example before-and-after knowledge states
* Agent Memory storyline
* Sample knowledge graph data
* Example explanation-depth levels

### Demo Data

* Morning feed dataset
* Duplicate-source examples
* Low-signal examples
* Skipped-item counts
* One complete development cluster
* One complete research bundle
* Prewritten Ask Thinketh questions and answers
* Fallback static demo data

### UI Assets

* Icons
* Development card variants
* Impact indicators
* Source cards
* Topic indicators
* Knowledge-state visualization
* Storyline component
* Loading state
* Empty state
* Error state
* Completed-development state

### Demo Presentation

* 60–90 second demo script
* Exact click path
* Opening problem statement
* Product thesis slide
* Architecture visual
* Differentiation slide
* Closing statement
* Backup video
* Screenshots for submission
* Devpost images
* Product description
* Team description

For every artifact, include:

* What it is
* Why the prototype needs it
* Required format
* Whether it must be ready before Friday
* Suggested owner: Stefen or Nadani
* Priority: Must Have, Should Have, or Stretch

## Scope guidance

Clearly distinguish between:

### HackGT Must Build

* Morning catch-up
* One complete development
* Personalized knowledge delta
* “Got it” interaction
* Visible knowledge-state update
* One small Library view
* A controlled, polished demo path

### Stretch

* Live information ingestion
* Multiple complete storylines
* Full Ask experience
* Interactive knowledge graph
* Advanced onboarding
* Multiple user profiles
* Broad source integrations
* Real-time personalization

Do not let stretch features visually dominate the prototype.

## Final output

Produce:

1. Two distinct but related visual-direction explorations
2. A recommendation for the stronger direction
3. A cohesive design system for that direction
4. High-fidelity mobile screens for the full demo
5. A clickable prototype path
6. Motion annotations
7. One responsive desktop Today screen
8. A detailed Hackathon Artifact Checklist
9. A Must Build vs. Stretch scope board
10. A visual demo storyboard showing what judges see and understand at each step

The final result should feel like an early product concept from a highly funded, design-led technology company—not a collection of disconnected AI-generated screens.

Above all, preserve this idea:

Thinketh filters the world, identifies what genuinely changed, teaches the user the knowledge delta, and updates its model of what the user understands.
