Add a focused “Saved to Learn” feature to the existing Thinketh React prototype.

Do not create a generic bookmarks system.

Do not add a separate primary navigation destination.

Integrate this feature into the existing Library and connect it directly to:

* Knowledge Atlas concepts
* Learning paths
* Ask Thinketh
* Knowledge-delta generation
* Projects
* Understanding verification

The product principle is:

“Save to learn, not save to forget.”

# Core behavior

Users should be able to save:

* Research papers
* Articles
* Technical documentation
* GitHub repositories
* Videos
* Talks
* Thinketh developments
* Individual sources attached to developments

Saving an item should not merely store its URL.

Thinketh should conceptually process the resource and determine:

* What it is
* Who published it
* Its source type
* Estimated learning time
* Central concepts
* Concepts the user already understands
* What appears genuinely new to the user
* Which Knowledge Atlas nodes it connects to
* Whether it fits an existing learning path
* Whether it is relevant to an active project
* The most useful way for the user to consume it

# Language

Name the feature:

“Saved to Learn”

Inside the Library, use:

“Learning Queue”

Avoid:

* Bookmarks
* Favorites
* Reading List
* Saved Links

The distinction is that Thinketh turns saved material into structured learning.

# Save actions

Add a quiet save icon to:

* Development Detail
* Source rows
* Go Deeper resources
* Ask Thinketh responses
* Explore recommendations

Tapping the icon should immediately save the resource and provide subtle confirmation:

“Saved to your Learning Queue”

Then offer one optional action:

“Organize”

Do not open a large modal every time the user saves something.

# Organize bottom sheet

When the user chooses “Organize,” open a refined bottom sheet.

Title:

“Save this to learn”

Include:

## Destination

* Learning Queue
* Current learning path
* Existing project
* New knowledge branch

## Relevant concepts

Preselect concepts inferred by Thinketh.

Example:

* Agent Architecture
* Tool Use
* Agent Memory

Allow the user to remove an incorrect connection or add another concept.

## Learning intention

Options:

* Understand the central idea
* Go deep technically
* Apply this to a project
* Revisit later
* Compare with another source

Primary action:

“Save to learn”

Keep the sheet concise and mobile-friendly.

# Add a URL

Inside the Learning Queue, provide:

“Add a resource”

This opens a compact input:

“Paste an article, paper, video, repository, or documentation URL”

For the prototype, use deterministic local behavior.

When the user submits the example URL, show a processing sequence:

1. Identifying the source
2. Extracting central concepts
3. Comparing with your Knowledge Atlas
4. Preparing the useful knowledge delta

Use one evolving status line rather than four simultaneous loading cards.

Example:

“Comparing this paper with 47 concepts in your Atlas…”

# Resource-added result

After processing, show:

“Ready to learn”

Then provide:

* Resource title
* Publisher
* Resource type
* Estimated full reading time
* Estimated useful learning time
* Connected Atlas concepts
* What the user already understands
* What appears new
* Recommended action

Example resource:

“Building Effective Agents”

Publisher:

Anthropic

Type:

Technical article

Full reading time:

18 minutes

Useful learning time:

6 minutes

Connected concepts:

* Agent Architecture
* Tool Use
* Workflows
* Orchestration

Personalized analysis:

“You already understand tool use and basic agent loops. The most useful new material for you is Anthropic’s distinction between workflows and agents, and when each architecture is appropriate.”

Primary action:

“Teach me the delta”

Secondary actions:

* Read original
* Add to path
* Connect to project
* Save for later

# Learning Queue

Add “Learning Queue” within the existing Library.

The Library’s high-level structure should become:

* Knowledge Atlas
* Learning Queue
* Storylines
* Concepts
* Sources

Do not create another bottom-navigation item.

The Learning Queue should feel curated, not like a database table.

# Queue header

Title:

“Learning Queue”

Supporting copy:

“Resources waiting to become part of what you understand.”

Show a restrained summary:

“6 resources · 42 useful minutes”

Do not show productivity scores, streaks, or completion percentages.

# Queue organization

Organize resources by intention rather than folders.

Suggested sections:

## Learn next

The strongest recommendation based on current Atlas gaps and active learning paths.

## In progress

Resources already opened or partially learned.

## Saved for later

Resources without immediate urgency.

## Integrated

Resources whose central ideas have been verified and connected to the Atlas.

Keep “Integrated” collapsed by default.

# Resource row

Each resource should show only the most useful information:

* Source-type icon
* Title
* Publisher
* Useful learning time
* Two or three connected concepts
* Current state
* Reason it is recommended now

Example:

“Building Effective Agents”

Anthropic · Technical article · 6 useful minutes

Builds:

Agent Architecture · Workflows

Why now:

“This fills the gap between your Tool Use knowledge and your developing model of Agent Architecture.”

State:

Ready to learn

Primary row action:

“Learn”

Use an overflow menu for:

* Open original
* Add to path
* Connect to project
* Move later
* Remove

Do not surround every resource with a large floating card.

Use editorial rows, whitespace, and thin dividers.

# Resource states

Use meaningful states:

* Processing
* Ready to learn
* In progress
* Understanding check available
* Verified
* Integrated
* Revisit later
* Unable to process

Do not use numerical completion percentages.

## Processing

“Comparing with your Atlas…”

## Ready to learn

“Knowledge delta prepared”

## In progress

“Two concepts remaining”

## Verified

“Initial understanding verified”

## Integrated

“Connected to three Atlas concepts”

# Teach me the delta

This is the feature’s primary differentiated interaction.

When selected, open an Ask Thinketh conversation grounded in the saved resource.

Thinketh should say:

“I compared this resource with your current Knowledge Atlas. Most of the Tool Use section reinforces what you already understand. The genuinely new material is the distinction between workflows and agents.”

Then provide:

## What you already know

A concise summary of relevant existing knowledge.

## What is new

Only the meaningful knowledge delta.

## Why it matters

Connect the delta to the user’s goals or projects.

## Best evidence

Link directly to the most useful section of the source when possible.

## Updated mental model

Provide one concise statement showing how the user’s thinking should change.

Actions:

* Continue learning
* Go deeper
* Open source
* Add to path
* Check my understanding

Do not summarize every section of the resource when most of it is already familiar.

# Add to learning path

Allow the user to add a saved resource to:

* An existing path
* A newly generated path
* A project-specific path

When adding it, Thinketh should recommend its position.

Example:

“Place after Tool Use and before Persistent Memory.”

Explain:

“This resource introduces agent/workflow architecture before the path moves into memory systems.”

The user can accept or reposition it.

# Connect to project

Allow the user to connect a saved resource to an active project.

Use the HackGT example:

Project:

“Thinketh — HackGT”

Thinketh explains:

“This article may help you decide which parts of the ingestion pipeline should be deterministic workflows and which require agentic behavior.”

Actions:

* Add to project learning
* Ask how to apply this
* Leave unconnected

# Atlas integration

Saving a resource must not immediately change the user’s verified knowledge.

Instead:

1. Saving creates a source object.
2. Processing creates possible concept relationships.
3. Learning creates encountered knowledge.
4. The understanding check creates verified evidence.
5. Successful verification integrates concepts into the Atlas.

Possible relationships should appear as dotted connections.

Verified relationships become solid.

The selected concept sheet should list:

“Supporting resources”

and show saved resources that contributed to the user’s current understanding.

# Understanding check

After “Teach me the delta,” offer the existing three-question verification:

* Mechanism
* Transfer
* Boundary

Generate questions only from the resource’s meaningful knowledge delta.

Do not test sections Thinketh classified as already understood.

Passing verification should:

* Change the resource state to Verified
* Integrate the new concept or relationship
* Update the Atlas
* Move the resource toward Integrated

# Ask Thinketh integration

Allow the user to reference saved resources conversationally.

Suggested prompts:

* Compare these two saved papers.
* Which saved resource should I learn next?
* What do my saved articles reveal about my interests?
* Build a 20-minute path from my Learning Queue.
* Which saved items mostly repeat what I already know?
* What should I read for my HackGT project?

Thinketh should be able to say:

“You have four saved resources about agent memory. Two largely overlap. I recommend learning from the Anthropic documentation first, then using the research paper for deeper architectural context.”

# Duplicate detection

When the user saves a resource covering the same development or concepts as an existing saved item, show:

“This substantially overlaps with something already in your queue.”

Then offer:

* Save anyway
* Replace existing
* Compare them
* Skip duplicate

Do not silently discard it.

# Source quality

Show quiet source-quality context:

* Primary source
* Documentation
* Peer-reviewed research
* Repository
* Technical analysis
* Commentary

Do not create an unexplained numerical credibility score.

When relevant, explain:

“Primary source, but the performance claims have not yet been independently verified.”

# Visual direction

Preserve Thinketh’s established visual identity.

Use:

* Warm off-white background
* Charcoal text
* Muted gray supporting information
* Coral only for new knowledge or active learning
* Editorial serif for important resource titles and mental-model changes
* Sans-serif for metadata and interaction
* Thin dividers
* Generous whitespace
* Limited shadows
* Consistent radii

Avoid:

* Pinterest-style card grids
* Dense bookmark managers
* Browser-tab aesthetics
* Excessive thumbnails
* Folder trees
* Tag overload
* Bright status colors
* Progress rings
* Productivity dashboards

The queue should feel like an intelligent editorial reading plan.

# HackGT deterministic demo

Implement one polished demonstration path:

1. The user opens an Anthropic resource from Development Detail.
2. The user taps the save icon.
3. Confirmation appears: “Saved to your Learning Queue.”
4. The user opens Library → Learning Queue.
5. “Building Effective Agents” appears under Learn next.
6. Thinketh explains why it is recommended now.
7. The user taps “Teach me the delta.”
8. Ask Thinketh opens with the resource attached.
9. Thinketh explains what the user already knows.
10. Thinketh teaches the workflows-versus-agents distinction.
11. The user adds it to a “Reliable Production Agents” learning path.
12. The resource is placed between Tool Use and Persistent Memory.
13. The user can begin the understanding check.

Use local deterministic data and assets.

Do not require live URL extraction for the demo.

# Scope protection

For this prototype, do not build:

* Browser extensions
* Highlighting
* Inline PDF annotation
* Social sharing
* Public collections
* Collaborative folders
* Bulk import
* Email forwarding
* RSS ingestion
* Complex tagging
* Full-text document storage
* Cloud sync
* Automated copyright-restricted content copying

Represent these only as future possibilities if necessary.

# Acceptance criteria

The feature succeeds when:

* Saving takes one tap.
* Every saved resource has a learning purpose.
* The queue explains why an item matters now.
* Thinketh distinguishes reinforcement from genuinely new material.
* A saved resource can become an Ask conversation.
* A saved resource can enter a learning path.
* A saved resource can connect to a project.
* Saving alone does not falsely update the Knowledge Atlas.
* Verification can turn the resource into integrated knowledge.
* Duplicate and source-quality handling build trust.
* The queue remains calm with several resources.
* The feature feels native to Thinketh rather than added afterward.
* A judge immediately understands why this is more valuable than bookmarks.

The final experience should communicate:

“Anything worth saving can become part of what you understand.”
