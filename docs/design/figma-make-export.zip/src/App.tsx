import { useState } from 'react';
import type { Screen, Tab } from './types';
import Today from './screens/Today';
import DevelopmentDetail from './screens/DevelopmentDetail';
import KnowledgeUpdate from './screens/KnowledgeUpdate';
import TodayUpdated from './screens/TodayUpdated';
import Library from './screens/Library';
import Explore from './screens/Explore';
import Ask from './screens/Ask';
import DesktopAtlas from './screens/DesktopAtlas';
import Quiz from './screens/Quiz';
import TeachDelta from './screens/TeachDelta';

export default function App() {
  const [screen, setScreen] = useState<Screen>('today');
  const [activeTab, setActiveTab] = useState<Tab>('today');

  const navigate = (s: Screen) => {
    setScreen(s);
    if (s === 'library' || s === 'teach-delta') { setActiveTab('library'); }
    else if (s === 'explore') setActiveTab('explore');
    else if (s === 'ask') setActiveTab('ask');
    else if (s === 'today' || s === 'detail' || s === 'update' || s === 'today-updated') {
      setActiveTab('today');
    }
  };

  const onTabChange = (tab: Tab) => {
    setActiveTab(tab);
    if (tab === 'today') setScreen('today');
    if (tab === 'library') setScreen('library');
    if (tab === 'explore') setScreen('explore');
    if (tab === 'ask') setScreen('ask');
  };

  if (screen === 'desktop-atlas') {
    return <DesktopAtlas onNavigate={navigate} />;
  }

  return (
    <div className="min-h-screen bg-[#EDEAE4] flex items-start sm:items-center justify-center sm:py-10">
      {/* Phone frame */}
      <div
        className="relative w-full sm:w-[390px] h-[100dvh] sm:h-[844px] bg-ground sm:rounded-[44px] sm:shadow-2xl overflow-hidden flex flex-col"
        style={{ boxShadow: '0 32px 80px rgba(0,0,0,0.22), 0 0 0 1px rgba(0,0,0,0.06)' }}
      >
        {/* Status bar — desktop phone chrome only */}
        <div className="hidden sm:flex shrink-0 items-center justify-between px-7 pt-4 pb-0 text-[12px] text-ink3 select-none">
          <span className="font-medium">9:41</span>
          <div className="flex items-center gap-2">
            <svg width="16" height="11" viewBox="0 0 16 11" fill="currentColor">
              <rect x="0" y="4" width="3" height="7" rx="0.5" opacity="0.4"/>
              <rect x="4.5" y="2.5" width="3" height="8.5" rx="0.5" opacity="0.6"/>
              <rect x="9" y="0.5" width="3" height="10.5" rx="0.5"/>
              <rect x="13.5" y="1" width="2" height="9" rx="0.5" fill="none" stroke="currentColor" strokeWidth="1"/>
              <rect x="14" y="2.5" width="1.5" height="6" rx="0.3"/>
            </svg>
          </div>
        </div>

        {/* Screen content */}
        <div className="flex-1 overflow-hidden">
          {screen === 'today' && (
            <Today onNavigate={navigate} activeTab={activeTab} onTabChange={onTabChange} />
          )}
          {screen === 'detail' && (
            <DevelopmentDetail onNavigate={navigate} activeTab={activeTab} onTabChange={onTabChange} />
          )}
          {screen === 'update' && (
            <KnowledgeUpdate onNavigate={navigate} />
          )}
          {screen === 'today-updated' && (
            <TodayUpdated onNavigate={navigate} activeTab={activeTab} onTabChange={onTabChange} />
          )}
          {screen === 'library' && (
            <Library onNavigate={navigate} activeTab={activeTab} onTabChange={onTabChange} />
          )}
          {screen === 'explore' && (
            <Explore onNavigate={navigate} activeTab={activeTab} onTabChange={onTabChange} />
          )}
          {screen === 'ask' && (
            <Ask onNavigate={navigate} activeTab={activeTab} onTabChange={onTabChange} />
          )}
          {screen === 'quiz' && (
            <Quiz onNavigate={navigate} />
          )}
          {screen === 'teach-delta' && (
            <TeachDelta onNavigate={navigate} activeTab={activeTab} onTabChange={onTabChange} />
          )}
        </div>
      </div>
    </div>
  );
}
