import { useState } from 'react';

// ─── Types ────────────────────────────────────────────────────────────────────

type NodeState = 'established' | 'developing' | 'new' | 'emerging' | 'unfamiliar';

interface GraphNode {
  id: string;
  label: string;
  shortLabel?: string;
  x: number;
  y: number;
  r: number;
  state: NodeState;
  level: 1 | 2 | 3;
  isAnimated?: boolean; // hidden until showNewNode=true
}

interface GraphEdge {
  id: string;
  from: string;
  to: string;
  solid: boolean;
  weight: number;
  isNew?: boolean;
  isAnimated?: boolean; // draw animation
}

interface ConceptDetail {
  label: string;
  stateLabel: string;
  understanding: string;
  recentUpdate: string;
  related: string[];
  suggestedNext: string;
}

export type AtlasFilter = 'all' | 'today' | 'concepts' | 'companies' | 'models' | 'papers';

export interface KnowledgeAtlasProps {
  mode?: 'full' | 'mini';
  showNewNode?: boolean;
  showNewConnections?: boolean;
  filterMode?: AtlasFilter;
  onNodeTap?: (id: string) => void;
  style?: React.CSSProperties;
  className?: string;
}

// ─── Constants ────────────────────────────────────────────────────────────────

const C = {
  coral: '#C0553A',
  coralTint: '#F7EAE6',
  ground: '#F6F5F2',
  panel: '#FFFFFF',
  ink: '#1A1918',
  ink2: '#6B6560',
  ink3: '#A09A93',
  fog: '#EEEAE4',
  edge: '#E6E2DA',
  sans: "'Inter', system-ui, sans-serif",
  serif: "'Playfair Display', Georgia, serif",
};

const STATE_FILL: Record<NodeState, string> = {
  established: '#1A1918',
  developing: '#6B6560',
  new: '#C0553A',
  emerging: '#A09A93',
  unfamiliar: '#D4CFC8',
};

const STATE_OPACITY: Record<NodeState, number> = {
  established: 0.88,
  developing: 0.72,
  new: 1.0,
  emerging: 0.46,
  unfamiliar: 0.30,
};

// Brain silhouette path (top-down view, within viewBox "30 42 308 438")
const BRAIN_PATH = `
  M 178 56
  C 216 44 294 70 328 116
  C 354 152 344 206 328 248
  C 312 284 314 320 302 354
  C 282 402 250 440 212 458
  C 196 466 176 468 160 464
  C 138 458 116 444 100 426
  C 70 394 48 354 44 310
  C 40 264 52 218 68 178
  C 84 138 84 94 114 70
  C 136 56 160 46 178 56
  Z
`;

// ─── Node data ────────────────────────────────────────────────────────────────

export const NODES: GraphNode[] = [
  // Level 1: Primary domains
  { id: 'agent-arch',  label: 'Agent Architecture', shortLabel: 'Agent Arch.',  x: 110, y: 148, r: 16, state: 'established', level: 1 },
  { id: 'foundation',  label: 'Foundation Models',  shortLabel: 'Foundation',   x: 252, y: 130, r: 16, state: 'established', level: 1 },
  { id: 'dev-tooling', label: 'Developer Tooling',  shortLabel: 'Dev Tooling',  x: 78,  y: 295, r: 15, state: 'established', level: 1 },
  { id: 'research',    label: 'Research',                                        x: 238, y: 306, r: 12, state: 'developing',  level: 1 },
  { id: 'ai-safety',   label: 'AI Safety',                                       x: 318, y: 218, r: 11, state: 'emerging',   level: 1 },
  { id: 'robotics',    label: 'Robotics',                                         x: 88,  y: 408, r: 10, state: 'emerging',   level: 1 },
  { id: 'multimodal',  label: 'Multimodal AI',       shortLabel: 'Multimodal',   x: 270, y: 408, r: 12, state: 'developing',  level: 1 },
  { id: 'infra',       label: 'Infrastructure',                                   x: 180, y: 456, r: 10, state: 'emerging',   level: 1 },

  // Level 2: Key concepts
  { id: 'agent-memory',       label: 'Agent Memory',           x: 124, y: 208, r: 10, state: 'new',          level: 2 },
  { id: 'tool-use',           label: 'Tool Use',               x: 68,  y: 220, r: 9,  state: 'established',  level: 2 },
  { id: 'long-running',       label: 'Long-running Agents',    shortLabel: 'Long-running', x: 162, y: 232, r: 8, state: 'developing', level: 2 },
  { id: 'mcp',                label: 'MCP',                    x: 56,  y: 308, r: 8,  state: 'developing',   level: 2 },
  { id: 'context-eng',        label: 'Context Engineering',    shortLabel: 'Context Eng.', x: 112, y: 330, r: 7, state: 'developing', level: 2 },
  { id: 'retrieval',          label: 'Retrieval',              x: 88,  y: 358, r: 7,  state: 'emerging',     level: 2 },
  { id: 'claude',             label: 'Claude',                 x: 205, y: 160, r: 9,  state: 'established',  level: 2 },
  { id: 'gemini',             label: 'Gemini',                 x: 265, y: 170, r: 8,  state: 'developing',   level: 2 },
  { id: 'llama',              label: 'Llama',                  x: 292, y: 188, r: 7,  state: 'developing',   level: 2 },
  { id: 'computer-use',       label: 'Computer Use',           x: 118, y: 384, r: 7,  state: 'emerging',     level: 2 },

  // The animated new concept (hidden until showNewNode=true)
  { id: 'persistent-memory',  label: 'Persistent Memory',      x: 162, y: 192, r: 9,  state: 'new',          level: 2, isAnimated: true },
];

export const EDGES: GraphEdge[] = [
  { id: 'e1',  from: 'agent-arch',  to: 'agent-memory',       solid: true,  weight: 1.8 },
  { id: 'e2',  from: 'agent-arch',  to: 'tool-use',           solid: true,  weight: 1.5 },
  { id: 'e3',  from: 'agent-arch',  to: 'long-running',       solid: true,  weight: 1.4 },
  { id: 'e4',  from: 'agent-arch',  to: 'dev-tooling',        solid: false, weight: 0.8 },
  { id: 'e5',  from: 'foundation',  to: 'claude',             solid: true,  weight: 2.0 },
  { id: 'e6',  from: 'foundation',  to: 'gemini',             solid: true,  weight: 1.5 },
  { id: 'e7',  from: 'foundation',  to: 'llama',              solid: true,  weight: 1.0 },
  { id: 'e8',  from: 'dev-tooling', to: 'mcp',                solid: true,  weight: 1.5 },
  { id: 'e9',  from: 'dev-tooling', to: 'context-eng',        solid: true,  weight: 1.5 },
  { id: 'e10', from: 'dev-tooling', to: 'retrieval',          solid: true,  weight: 1.0 },
  { id: 'e11', from: 'claude',      to: 'agent-memory',       solid: true,  weight: 1.0 },
  { id: 'e12', from: 'long-running',to: 'agent-memory',       solid: false, weight: 0.8 },
  { id: 'e13', from: 'robotics',    to: 'computer-use',       solid: true,  weight: 1.0 },
  { id: 'e14', from: 'research',    to: 'ai-safety',          solid: false, weight: 0.8 },
  { id: 'e15', from: 'research',    to: 'multimodal',         solid: false, weight: 0.8 },
  // New connections (coral, animated draw)
  { id: 'en1', from: 'agent-memory',  to: 'persistent-memory', solid: true, weight: 2.0, isNew: true, isAnimated: true },
  { id: 'en2', from: 'long-running',  to: 'persistent-memory', solid: true, weight: 1.5, isNew: true, isAnimated: true },
  { id: 'en3', from: 'claude',        to: 'persistent-memory', solid: true, weight: 1.0, isNew: true, isAnimated: true },
];

const CONCEPT_DETAILS: Record<string, ConceptDetail> = {
  'agent-memory': {
    label: 'Agent Memory',
    stateLabel: 'Developing',
    understanding: "You understand how Claude uses tools and maintains context within a session. You now understand that memory can persist across separate sessions via Anthropic's persistent memory API.",
    recentUpdate: 'Anthropic expands long-term agent memory in Claude 4 rollout · Sep 22',
    related: ['Persistent Memory', 'Tool Use', 'Long-running Agents', 'Claude'],
    suggestedNext: 'Context Engineering',
  },
  'persistent-memory': {
    label: 'Persistent Memory',
    stateLabel: 'Emerging',
    understanding: 'Persistent memory allows agents to retain useful context across separate sessions, enabling longer-running workflows and agents that behave like persistent software workers.',
    recentUpdate: 'Anthropic expands long-term agent memory in Claude 4 rollout · Sep 22',
    related: ['Agent Memory', 'Long-running Agents', 'Claude', 'Tool Use'],
    suggestedNext: 'Long-running Agents',
  },
  'claude': {
    label: 'Claude',
    stateLabel: 'Established',
    understanding: "You have a strong working understanding of Claude's API, capabilities, and tool-use patterns. You actively build agent workflows with it.",
    recentUpdate: 'Anthropic expands long-term agent memory in Claude 4 rollout · Sep 22',
    related: ['Foundation Models', 'Tool Use', 'Agent Memory', 'MCP'],
    suggestedNext: 'Context Engineering',
  },
  'tool-use': {
    label: 'Tool Use',
    stateLabel: 'Established',
    understanding: 'You understand how LLMs call external tools, handle structured outputs, and chain multi-step actions within agent loops.',
    recentUpdate: 'No recent developments · Your understanding is current',
    related: ['Agent Architecture', 'MCP', 'Agent Memory', 'Context Engineering'],
    suggestedNext: 'Agent Memory',
  },
  'mcp': {
    label: 'MCP',
    stateLabel: 'Developing',
    understanding: 'You understand the Model Context Protocol as a standard for connecting AI models to external tools and data sources. You work with MCP actively.',
    recentUpdate: 'No recent developments · Your understanding is current',
    related: ['Developer Tooling', 'Tool Use', 'Claude', 'Context Engineering'],
    suggestedNext: 'Context Engineering',
  },
};

const DEFAULT_CONCEPT: ConceptDetail = {
  label: 'Unknown Concept',
  stateLabel: 'Emerging',
  understanding: 'This concept is adjacent to your current understanding. Continue learning to build a clearer mental model of it.',
  recentUpdate: 'No recent developments tracked',
  related: [],
  suggestedNext: 'Agent Memory',
};

// ─── Sub-components ───────────────────────────────────────────────────────────

function EdgeLine({ edge, nodes, visible }: { edge: GraphEdge; nodes: GraphNode[]; visible: boolean }) {
  const from = nodes.find(n => n.id === edge.from);
  const to = nodes.find(n => n.id === edge.to);
  if (!from || !to || !visible) return null;

  const color = edge.isNew ? C.coral : '#C8C3BB';
  const opacity = edge.isNew ? 0.85 : 0.55;

  return (
    <path
      d={`M ${from.x} ${from.y} L ${to.x} ${to.y}`}
      stroke={color}
      strokeWidth={edge.weight}
      strokeDasharray={edge.solid ? undefined : '3 4'}
      fill="none"
      opacity={opacity}
      strokeLinecap="round"
    />
  );
}

function NodeCircle({
  node,
  selected,
  onTap,
  interactive,
  dimmed,
}: {
  node: GraphNode;
  selected: boolean;
  onTap: () => void;
  interactive: boolean;
  dimmed?: boolean;
}) {
  const fill = STATE_FILL[node.state];
  const opacity = dimmed ? 0.12 : (selected ? 1 : STATE_OPACITY[node.state]);

  return (
    <g onClick={interactive ? onTap : undefined} style={{ cursor: interactive ? 'pointer' : 'default' }}>
      {/* Pulse ring for new nodes */}
      {node.state === 'new' && (
        <circle cx={node.x} cy={node.y} r={node.r + 3} fill="none" stroke={C.coral} strokeWidth="0.8">
          <animate attributeName="r" values={`${node.r + 2};${node.r + 11};${node.r + 2}`} dur="2.8s" repeatCount="indefinite" />
          <animate attributeName="opacity" values="0.45;0;0.45" dur="2.8s" repeatCount="indefinite" />
        </circle>
      )}

      {/* Selection ring */}
      {selected && (
        <circle cx={node.x} cy={node.y} r={node.r + 5} fill="none" stroke={C.coral} strokeWidth="1.5" opacity="0.4" />
      )}

      {/* Main circle */}
      <circle
        cx={node.x}
        cy={node.y}
        r={node.r}
        fill={fill}
        opacity={opacity}
      />
    </g>
  );
}

function ConceptBottomSheet({ nodeId, onClose }: { nodeId: string; onClose: () => void }) {
  const node = NODES.find(n => n.id === nodeId);
  const detail = CONCEPT_DETAILS[nodeId] ?? { ...DEFAULT_CONCEPT, label: node?.label ?? 'Concept' };

  const stateColor: Record<string, string> = {
    Established: '#1A1918',
    Developing: C.coral,
    Emerging: C.ink3,
    Unfamiliar: C.ink3,
    Deep: '#1A1918',
  };

  return (
    <div
      style={{
        position: 'absolute', bottom: 0, left: 0, right: 0,
        backgroundColor: C.panel,
        borderTopLeftRadius: '20px', borderTopRightRadius: '20px',
        boxShadow: '0 -4px 32px rgba(0,0,0,0.12)',
        padding: '0 0 24px',
        zIndex: 50,
        maxHeight: '70%',
        overflowY: 'auto',
      }}
    >
      {/* Handle */}
      <div style={{ display: 'flex', justifyContent: 'center', padding: '10px 0 0' }}>
        <div style={{ width: '32px', height: '3px', borderRadius: '2px', backgroundColor: C.edge }} />
      </div>

      <div style={{ padding: '16px 22px 0' }}>
        {/* Header row */}
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: '16px' }}>
          <div>
            <h3 style={{ fontFamily: C.serif, fontSize: '22px', fontWeight: 600, color: C.ink, lineHeight: 1.2, marginBottom: '5px' }}>
              {detail.label}
            </h3>
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
              <div style={{
                width: '7px', height: '7px', borderRadius: '50%',
                backgroundColor: stateColor[detail.stateLabel] ?? C.ink3,
              }} />
              <span style={{ fontSize: '12px', color: C.ink2, fontFamily: C.sans }}>
                {detail.stateLabel}
              </span>
            </div>
          </div>
          <button
            onClick={onClose}
            style={{
              background: 'none', border: 'none', cursor: 'pointer', padding: '4px',
              color: C.ink3, fontSize: '18px', lineHeight: 1,
            }}
          >
            ×
          </button>
        </div>

        {/* Understanding */}
        <div style={{ marginBottom: '16px' }}>
          <p style={{ fontSize: '10px', letterSpacing: '0.1em', textTransform: 'uppercase', color: C.ink3, fontFamily: C.sans, marginBottom: '6px' }}>
            What you understand
          </p>
          <p style={{ fontSize: '14px', color: C.ink2, fontFamily: C.sans, lineHeight: 1.55 }}>
            {detail.understanding}
          </p>
        </div>

        {/* Divider */}
        <div style={{ height: '1px', backgroundColor: C.edge, marginBottom: '16px' }} />

        {/* Recent update */}
        <div style={{ marginBottom: '16px' }}>
          <p style={{ fontSize: '10px', letterSpacing: '0.1em', textTransform: 'uppercase', color: C.ink3, fontFamily: C.sans, marginBottom: '6px' }}>
            Most recent update
          </p>
          <p style={{ fontSize: '13px', color: C.ink, fontFamily: C.sans, lineHeight: 1.45 }}>
            {detail.recentUpdate}
          </p>
        </div>

        {/* Related concepts */}
        {detail.related.length > 0 && (
          <div style={{ marginBottom: '16px' }}>
            <p style={{ fontSize: '10px', letterSpacing: '0.1em', textTransform: 'uppercase', color: C.ink3, fontFamily: C.sans, marginBottom: '8px' }}>
              Related concepts
            </p>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
              {detail.related.map(r => (
                <span key={r} style={{
                  fontSize: '12px', backgroundColor: C.fog, color: C.ink2,
                  padding: '5px 11px', borderRadius: '100px', fontFamily: C.sans,
                }}>
                  {r}
                </span>
              ))}
            </div>
          </div>
        )}

        <div style={{ height: '1px', backgroundColor: C.edge, marginBottom: '16px' }} />

        {/* Suggested next */}
        <div style={{ marginBottom: '8px' }}>
          <p style={{ fontSize: '10px', letterSpacing: '0.1em', textTransform: 'uppercase', color: C.ink3, fontFamily: C.sans, marginBottom: '6px' }}>
            Suggested next concept
          </p>
          <p style={{ fontSize: '14px', color: C.coral, fontFamily: C.sans, fontWeight: 500 }}>
            {detail.suggestedNext} →
          </p>
        </div>

        {/* Ask button */}
        <button style={{
          width: '100%', backgroundColor: C.ink, color: '#fff',
          fontFamily: C.sans, fontWeight: 500, fontSize: '14px',
          padding: '12px', borderRadius: '100px', border: 'none', cursor: 'pointer',
          marginTop: '12px',
        }}>
          Ask Thinketh about this
        </button>
      </div>
    </div>
  );
}

function LegendPanel({ onClose }: { onClose: () => void }) {
  const items = [
    { color: '#1A1918', label: 'Established knowledge', opacity: 0.88 },
    { color: '#6B6560', label: 'Developing knowledge', opacity: 1 },
    { color: '#C0553A', label: 'Newly added today', opacity: 1 },
    { color: '#A09A93', label: 'Adjacent, not yet learned', opacity: 1 },
  ];
  return (
    <div style={{
      position: 'absolute', top: '48px', right: '16px',
      backgroundColor: C.panel, borderRadius: '14px',
      padding: '14px 16px', zIndex: 40,
      boxShadow: '0 4px 20px rgba(0,0,0,0.1)',
      minWidth: '200px',
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
        <p style={{ fontSize: '11px', fontWeight: 600, color: C.ink, fontFamily: C.sans }}>Visual encoding</p>
        <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.ink3, fontSize: '16px', padding: 0 }}>×</button>
      </div>
      {items.map(item => (
        <div key={item.label} style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
          <div style={{ width: '10px', height: '10px', borderRadius: '50%', backgroundColor: item.color, opacity: item.opacity, flexShrink: 0 }} />
          <span style={{ fontSize: '12px', color: C.ink2, fontFamily: C.sans }}>{item.label}</span>
        </div>
      ))}
      <div style={{ height: '1px', backgroundColor: C.edge, margin: '10px 0' }} />
      <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
        <svg width="28" height="8" viewBox="0 0 28 8">
          <line x1="0" y1="4" x2="28" y2="4" stroke="#C8C3BB" strokeWidth="1.5" />
        </svg>
        <span style={{ fontSize: '12px', color: C.ink2, fontFamily: C.sans }}>Established relationship</span>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
        <svg width="28" height="8" viewBox="0 0 28 8">
          <line x1="0" y1="4" x2="28" y2="4" stroke="#C8C3BB" strokeWidth="1" strokeDasharray="3 4" />
        </svg>
        <span style={{ fontSize: '12px', color: C.ink2, fontFamily: C.sans }}>Possible relationship</span>
      </div>
    </div>
  );
}

// ─── Main component ───────────────────────────────────────────────────────────

function isNodeDimmed(node: GraphNode, filterMode: AtlasFilter): boolean {
  if (filterMode === 'all') return false;
  if (filterMode === 'today') return node.state !== 'new';
  if (filterMode === 'concepts') return node.level === 1;
  // companies, models, papers — no data yet, dim everything except level-1 structure
  return node.level === 2;
}

function isEdgeDimmed(edge: GraphEdge, nodes: GraphNode[], filterMode: AtlasFilter): boolean {
  if (filterMode === 'all') return false;
  const from = nodes.find(n => n.id === edge.from);
  const to = nodes.find(n => n.id === edge.to);
  if (!from || !to) return true;
  if (filterMode === 'today') return !edge.isNew;
  return false;
}

export default function KnowledgeAtlas({
  mode = 'full',
  showNewNode = true,
  filterMode = 'all',
  onNodeTap,
  style,
  className,
}: KnowledgeAtlasProps) {
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);

  const handleNodeTap = (id: string) => {
    setSelectedNodeId(prev => prev === id ? null : id);
    onNodeTap?.(id);
  };
  const [showLegend, setShowLegend] = useState(false);

  const visibleNodes = showNewNode
    ? NODES
    : NODES.filter(n => !n.isAnimated);

  const visibleEdges = showNewNode
    ? EDGES
    : EDGES.filter(e => !e.isAnimated);

  const isMini = mode === 'mini';

  // Crop to Agent Memory cluster in mini mode
  const viewBox = isMini
    ? '62 148 168 115'
    : '30 42 308 436';

  return (
    <div
      className={className}
      style={{
        position: 'relative',
        width: '100%',
        height: '100%',
        overflow: 'hidden',
        ...style,
      }}
    >
      <svg
        viewBox={viewBox}
        style={{ width: '100%', height: '100%', display: 'block' }}
        preserveAspectRatio="xMidYMid meet"
      >
        {/* Brain silhouette */}
        <path
          d={BRAIN_PATH}
          fill="none"
          stroke="#D0CAC2"
          strokeWidth="1.2"
          opacity={isMini ? 0 : 0.22}
        />

        {/* Medial hint */}
        {!isMini && (
          <line x1="178" y1="58" x2="170" y2="462" stroke="#D0CAC2" strokeWidth="0.8" opacity="0.12" strokeDasharray="5 8" />
        )}

        {/* Edges (rendered below nodes) */}
        {visibleEdges.map(edge => (
          <EdgeLine
            key={edge.id}
            edge={edge}
            nodes={visibleNodes}
            visible={!isEdgeDimmed(edge, visibleNodes, filterMode)}
          />
        ))}

        {/* Nodes */}
        {visibleNodes.map(node => (
          <NodeCircle
            key={node.id}
            node={node}
            selected={selectedNodeId === node.id}
            onTap={() => handleNodeTap(node.id)}
            interactive={!isMini}
            dimmed={isNodeDimmed(node, filterMode)}
          />
        ))}

        {/* Domain labels (full mode only) */}
        {!isMini && NODES.filter(n => n.level === 1).map(node => (
          <text
            key={`label-${node.id}`}
            x={node.x}
            y={node.y + node.r + 9}
            textAnchor="middle"
            fontSize="6.5"
            fill="#6B6560"
            fontFamily="Inter, system-ui, sans-serif"
            opacity="0.75"
          >
            {node.shortLabel ?? node.label}
          </text>
        ))}

        {/* New node label */}
        {showNewNode && (
          <text
            x={162}
            y={192 + 9 + 9}
            textAnchor="middle"
            fontSize="6"
            fill={C.coral}
            fontFamily="Inter, system-ui, sans-serif"
            opacity="0.9"
          >
            Persistent Memory
          </text>
        )}

        {/* Agent Memory label */}
        <text
          x={124}
          y={208 + 10 + 9}
          textAnchor="middle"
          fontSize="6"
          fill={C.coral}
          fontFamily="Inter, system-ui, sans-serif"
          opacity="0.85"
        >
          Agent Memory
        </text>
      </svg>

      {/* Info / Legend button */}
      {!isMini && (
        <button
          onClick={() => setShowLegend(v => !v)}
          style={{
            position: 'absolute', top: '12px', right: '16px',
            width: '28px', height: '28px', borderRadius: '50%',
            backgroundColor: C.panel, border: `1px solid ${C.edge}`,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            cursor: 'pointer', color: C.ink3, fontSize: '13px', fontFamily: C.sans,
            boxShadow: '0 1px 4px rgba(0,0,0,0.08)',
          }}
        >
          ℹ
        </button>
      )}

      {showLegend && <LegendPanel onClose={() => setShowLegend(false)} />}

      {/* Concept bottom sheet */}
      {!isMini && selectedNodeId && (
        <ConceptBottomSheet
          nodeId={selectedNodeId}
          onClose={() => setSelectedNodeId(null)}
        />
      )}

      {/* Tap backdrop to close sheet */}
      {!isMini && selectedNodeId && (
        <div
          onClick={() => setSelectedNodeId(null)}
          style={{
            position: 'absolute', inset: 0, zIndex: 40,
            pointerEvents: 'none',
          }}
        />
      )}
    </div>
  );
}
