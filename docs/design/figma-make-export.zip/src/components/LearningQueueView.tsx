import { useState, useEffect, useRef } from 'react';
import type { Screen } from '../types';

const C = {
  coral: '#C0553A',
  coralTint: '#F7EAE6',
  ground: '#F6F5F2',
  panel: '#FFFFFF',
  ink: '#1A1918',
  ink2: '#6B6560',
  ink3: '#A09A93',
  fog: '#EEEAE4',
  edge: '#E6E2DA',
  sans: "'Inter', system-ui, sans-serif",
  serif: "'Playfair Display', Georgia, serif",
};

type QueueView = 'list' | 'add-url' | 'processing' | 'result';

interface Resource {
  id: string;
  title: string;
  publisher: string;
  type: string;
  usefulMinutes: number;
  concepts: string[];
  whyNow: string;
  state: 'ready' | 'in-progress' | 'saved-later' | 'integrated';
  stateLabel: string;
  section: 'learn-next' | 'in-progress' | 'saved-later' | 'integrated';
}

const processingSteps = [
  'Identifying the source…',
  'Extracting central concepts…',
  'Comparing this paper with 47 concepts in your Atlas…',
  'Preparing the useful knowledge delta…',
];

interface Props {
  onNavigate: (screen: Screen) => void;
  newlySaved?: boolean;
}

export default function LearningQueueView({ onNavigate, newlySaved = false }: Props) {
  const [view, setView] = useState<QueueView>('list');
  const [url, setUrl] = useState('');
  const [processingStep, setProcessingStep] = useState(0);
  const [integratedOpen, setIntegratedOpen] = useState(false);
  const [overflowOpen, setOverflowOpen] = useState<string | null>(null);
  const [organizeOpen, setOrganizeOpen] = useState(false);
  const [selectedIntention, setSelectedIntention] = useState<string | null>(null);
  const [savedToConcepts, setSavedToConcepts] = useState(['Agent Architecture', 'Tool Use', 'Agent Memory']);
  const processingRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const [resources, setResources] = useState<Resource[]>([
    {
      id: 'building-agents',
      title: 'Building Effective Agents',
      publisher: 'Anthropic',
      type: 'Technical article',
      usefulMinutes: 6,
      concepts: ['Agent Architecture', 'Workflows'],
      whyNow: 'This fills the gap between your Tool Use knowledge and your developing model of Agent Architecture.',
      state: newlySaved ? 'ready' : 'ready',
      stateLabel: 'Ready to learn',
      section: 'learn-next',
    },
    {
      id: 'react-paper',
      title: 'ReAct: Synergizing Reasoning and Acting',
      publisher: 'Princeton / Google',
      type: 'Research paper',
      usefulMinutes: 9,
      concepts: ['Agent Architecture', 'Tool Use'],
      whyNow: 'Foundational framing for your current work on agent loops.',
      state: 'in-progress',
      stateLabel: 'Two concepts remaining',
      section: 'in-progress',
    },
    {
      id: 'attention',
      title: 'Attention is All You Need',
      publisher: 'Google Research',
      type: 'Research paper',
      usefulMinutes: 12,
      concepts: ['Transformer Architecture', 'Attention Mechanism'],
      whyNow: 'Background for understanding model architecture limitations.',
      state: 'saved-later',
      stateLabel: 'Saved for later',
      section: 'saved-later',
    },
    {
      id: 'memory-survey',
      title: 'A Survey on Memory in LLM-based Agents',
      publisher: 'arXiv',
      type: 'Research paper',
      usefulMinutes: 8,
      concepts: ['Agent Memory', 'Persistent Memory'],
      whyNow: 'Directly supports the memory storyline update from today.',
      state: 'saved-later',
      stateLabel: 'Saved for later',
      section: 'saved-later',
    },
    {
      id: 'mcp-docs',
      title: 'Model Context Protocol — Introduction',
      publisher: 'Anthropic',
      type: 'Documentation',
      usefulMinutes: 7,
      concepts: ['Model Context Protocol', 'Tool Use'],
      whyNow: 'Completes your understanding of the MCP concept.',
      state: 'integrated',
      stateLabel: 'Connected to three Atlas concepts',
      section: 'integrated',
    },
  ]);

  const learnNext = resources.filter(r => r.section === 'learn-next');
  const inProgress = resources.filter(r => r.section === 'in-progress');
  const savedLater = resources.filter(r => r.section === 'saved-later');
  const integrated = resources.filter(r => r.section === 'integrated');

  const startProcessing = () => {
    setView('processing');
    setProcessingStep(0);
    let i = 0;
    processingRef.current = setInterval(() => {
      i++;
      if (i < processingSteps.length) {
        setProcessingStep(i);
      } else {
        if (processingRef.current) clearInterval(processingRef.current);
        setTimeout(() => setView('result'), 600);
      }
    }, 1100);
  };

  useEffect(() => {
    return () => {
      if (processingRef.current) clearInterval(processingRef.current);
    };
  }, []);

  const intentions = [
    'Understand the central idea',
    'Go deep technically',
    'Apply this to a project',
    'Revisit later',
    'Compare with another source',
  ];

  const ResourceRow = ({ r }: { r: Resource }) => (
    <div style={{
      padding: '16px 0',
      borderBottom: `1px solid ${C.edge}`,
      position: 'relative',
    }}>
      <div style={{ display: 'flex', alignItems: 'flex-start', gap: '12px' }}>
        {/* Type icon */}
        <div style={{
          width: '36px', height: '36px', borderRadius: '8px', flexShrink: 0,
          backgroundColor: r.type === 'Technical article' || r.type === 'Documentation' ? C.coralTint : C.fog,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          {r.type.includes('paper') ? (
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke={C.ink3} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
              <path d="M9 4H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-4"/>
              <path d="M18 2l4 4-9 9H9v-4l9-9z"/>
            </svg>
          ) : r.type === 'Documentation' ? (
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke={C.coral} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
              <polyline points="14 2 14 8 20 8"/>
              <line x1="16" y1="13" x2="8" y2="13"/>
              <line x1="16" y1="17" x2="8" y2="17"/>
            </svg>
          ) : (
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke={C.coral} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
              <polyline points="14 2 14 8 20 8"/>
            </svg>
          )}
        </div>

        <div style={{ flex: 1, minWidth: 0 }}>
          <p style={{
            fontFamily: C.serif, fontSize: '15px', fontWeight: 600,
            color: C.ink, lineHeight: 1.3, marginBottom: '3px',
          }}>
            {r.title}
          </p>
          <p style={{ fontSize: '12px', color: C.ink3, fontFamily: C.sans, marginBottom: '8px' }}>
            {r.publisher} · {r.type} · {r.usefulMinutes} useful min
          </p>

          {/* Concepts */}
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '4px', marginBottom: '8px' }}>
            {r.concepts.map(c => (
              <span key={c} style={{
                fontSize: '10px', padding: '2px 8px', borderRadius: '100px',
                backgroundColor: C.fog, color: C.ink2, fontFamily: C.sans, fontWeight: 500,
              }}>
                {c}
              </span>
            ))}
          </div>

          {/* Why now */}
          {(r.section === 'learn-next' || r.section === 'in-progress') && (
            <p style={{
              fontSize: '12px', color: C.ink2, fontFamily: C.sans,
              lineHeight: 1.45, marginBottom: '10px',
              fontStyle: 'italic',
            }}>
              Why now: "{r.whyNow}"
            </p>
          )}

          {/* State + action */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <span style={{
              fontSize: '10px', fontFamily: C.sans, fontWeight: 500,
              color: r.section === 'integrated' ? '#4A9E6B' : r.section === 'in-progress' ? C.coral : C.ink3,
            }}>
              {r.stateLabel}
            </span>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              {r.section !== 'integrated' && (
                <button
                  onClick={() => r.id === 'building-agents' && onNavigate('teach-delta')}
                  style={{
                    padding: '6px 14px', borderRadius: '100px',
                    backgroundColor: r.section === 'learn-next' ? C.ink : C.panel,
                    border: `1px solid ${r.section === 'learn-next' ? C.ink : C.edge}`,
                    cursor: 'pointer', fontSize: '12px', fontWeight: 600,
                    color: r.section === 'learn-next' ? '#fff' : C.ink2,
                    fontFamily: C.sans,
                  }}
                >
                  {r.section === 'learn-next' ? 'Learn' : r.section === 'in-progress' ? 'Continue' : 'Learn'}
                </button>
              )}

              {/* Overflow menu */}
              <div style={{ position: 'relative' }}>
                <button
                  onClick={() => setOverflowOpen(overflowOpen === r.id ? null : r.id)}
                  style={{
                    background: 'none', border: 'none', cursor: 'pointer',
                    padding: '4px', color: C.ink3, display: 'flex', alignItems: 'center',
                  }}
                >
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                    <circle cx="12" cy="5" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="12" cy="19" r="1.5"/>
                  </svg>
                </button>
                {overflowOpen === r.id && (
                  <div style={{
                    position: 'absolute', right: 0, top: '24px', zIndex: 10,
                    backgroundColor: C.panel, borderRadius: '12px',
                    boxShadow: '0 4px 20px rgba(0,0,0,0.12)',
                    border: `1px solid ${C.edge}`, minWidth: '150px',
                  }}>
                    {['Open original', 'Add to path', 'Connect to project', 'Move later', 'Remove'].map(action => (
                      <button
                        key={action}
                        onClick={() => setOverflowOpen(null)}
                        style={{
                          display: 'block', width: '100%', textAlign: 'left',
                          padding: '11px 14px', background: 'none', border: 'none', cursor: 'pointer',
                          fontSize: '13px', color: action === 'Remove' ? C.coral : C.ink2,
                          fontFamily: C.sans, borderBottom: action !== 'Remove' ? `1px solid ${C.edge}` : 'none',
                        }}
                      >
                        {action}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const SectionHeader = ({ label, count }: { label: string; count: number }) => (
    <div style={{ marginBottom: '2px', marginTop: '4px' }}>
      <p style={{
        fontSize: '10px', letterSpacing: '0.12em', textTransform: 'uppercase',
        color: C.ink3, fontFamily: C.sans, fontWeight: 600,
      }}>
        {label} <span style={{ fontWeight: 400 }}>· {count}</span>
      </p>
    </div>
  );

  if (view === 'add-url') {
    return (
      <div style={{ padding: '0 0 24px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '20px' }}>
          <button
            onClick={() => setView('list')}
            style={{
              background: 'none', border: 'none', cursor: 'pointer',
              color: C.ink2, padding: 0, display: 'flex', alignItems: 'center', gap: '4px',
              fontSize: '14px', fontFamily: C.sans,
            }}
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
              <path d="M19 12H5M12 19l-7-7 7-7"/>
            </svg>
            Queue
          </button>
        </div>

        <p style={{
          fontFamily: C.serif, fontSize: '20px', fontWeight: 600,
          color: C.ink, marginBottom: '6px',
        }}>
          Add a resource
        </p>
        <p style={{ fontSize: '13px', color: C.ink3, fontFamily: C.sans, marginBottom: '20px', lineHeight: 1.5 }}>
          Paste an article, paper, video, repository, or documentation URL
        </p>

        <div style={{
          backgroundColor: C.panel, borderRadius: '14px', overflow: 'hidden',
          boxShadow: `0 0 0 1px ${C.edge}`, marginBottom: '14px',
        }}>
          <input
            type="url"
            value={url}
            onChange={e => setUrl(e.target.value)}
            placeholder="https://…"
            style={{
              width: '100%', padding: '16px',
              background: 'none', border: 'none', outline: 'none',
              fontSize: '14px', color: C.ink, fontFamily: C.sans,
              boxSizing: 'border-box',
            }}
          />
        </div>

        {/* Example trigger */}
        <button
          onClick={() => { setUrl('https://www.anthropic.com/research/building-effective-agents'); startProcessing(); }}
          style={{
            width: '100%', padding: '14px', borderRadius: '12px',
            backgroundColor: url.length > 5 ? C.ink : C.fog,
            border: 'none', cursor: url.length > 5 ? 'pointer' : 'default',
            fontSize: '14px', fontWeight: 600,
            color: url.length > 5 ? '#fff' : C.ink3,
            fontFamily: C.sans, transition: 'all 0.2s', marginBottom: '12px',
          }}
        >
          Analyze
        </button>

        <button
          onClick={() => { setUrl('https://www.anthropic.com/research/building-effective-agents'); startProcessing(); }}
          style={{
            width: '100%', padding: '12px', borderRadius: '12px',
            backgroundColor: C.panel, border: `1px solid ${C.edge}`,
            cursor: 'pointer', fontSize: '13px', color: C.ink3, fontFamily: C.sans,
          }}
        >
          Try the demo URL →
        </button>
      </div>
    );
  }

  if (view === 'processing') {
    return (
      <div style={{ padding: '40px 0 24px', textAlign: 'center' }}>
        <div style={{
          width: '48px', height: '48px', borderRadius: '50%',
          border: `2px solid ${C.edge}`, borderTopColor: C.coral,
          animation: 'spin 0.9s linear infinite',
          margin: '0 auto 24px',
        }} />
        <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>

        <p style={{
          fontFamily: C.serif, fontSize: '16px', color: C.ink,
          lineHeight: 1.5, maxWidth: '260px', margin: '0 auto',
          minHeight: '48px', transition: 'opacity 0.3s',
        }}>
          {processingSteps[processingStep]}
        </p>
      </div>
    );
  }

  if (view === 'result') {
    return (
      <div style={{ padding: '0 0 24px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '20px' }}>
          <button
            onClick={() => setView('list')}
            style={{
              background: 'none', border: 'none', cursor: 'pointer',
              color: C.ink2, padding: 0, display: 'flex', alignItems: 'center', gap: '4px',
              fontSize: '14px', fontFamily: C.sans,
            }}
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
              <path d="M19 12H5M12 19l-7-7 7-7"/>
            </svg>
            Queue
          </button>
        </div>

        {/* Ready to learn badge */}
        <div style={{
          display: 'inline-flex', alignItems: 'center', gap: '6px',
          backgroundColor: C.coralTint, borderRadius: '8px',
          padding: '4px 10px', marginBottom: '14px',
        }}>
          <div style={{ width: '6px', height: '6px', borderRadius: '50%', backgroundColor: C.coral }} />
          <span style={{ fontSize: '11px', fontWeight: 600, color: C.coral, fontFamily: C.sans }}>
            Ready to learn
          </span>
        </div>

        <p style={{
          fontFamily: C.serif, fontSize: '22px', fontWeight: 600,
          color: C.ink, lineHeight: 1.3, marginBottom: '6px',
        }}>
          Building Effective Agents
        </p>
        <p style={{ fontSize: '13px', color: C.ink3, fontFamily: C.sans, marginBottom: '20px' }}>
          Anthropic · Technical article · Primary source
        </p>

        {/* Time grid */}
        <div style={{
          display: 'grid', gridTemplateColumns: '1fr 1fr',
          gap: '8px', marginBottom: '20px',
        }}>
          {[
            { label: 'Full reading time', value: '18 minutes' },
            { label: 'Useful learning time', value: '6 minutes' },
          ].map(item => (
            <div key={item.label} style={{
              backgroundColor: C.panel, borderRadius: '12px', padding: '12px 14px',
              boxShadow: `0 0 0 1px ${C.edge}`,
            }}>
              <p style={{ fontSize: '10px', color: C.ink3, fontFamily: C.sans, marginBottom: '4px' }}>{item.label}</p>
              <p style={{ fontSize: '15px', fontWeight: 600, color: C.ink, fontFamily: C.sans }}>{item.value}</p>
            </div>
          ))}
        </div>

        {/* Connected concepts */}
        <div style={{ marginBottom: '16px' }}>
          <p style={{
            fontSize: '10px', letterSpacing: '0.1em', textTransform: 'uppercase',
            color: C.ink3, fontFamily: C.sans, fontWeight: 500, marginBottom: '8px',
          }}>
            Connected Atlas concepts
          </p>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
            {['Agent Architecture', 'Tool Use', 'Workflows', 'Orchestration'].map(c => (
              <span key={c} style={{
                fontSize: '12px', padding: '4px 10px', borderRadius: '100px',
                backgroundColor: C.fog, color: C.ink2, fontFamily: C.sans,
              }}>
                {c}
              </span>
            ))}
          </div>
        </div>

        {/* Personalized analysis */}
        <div style={{
          backgroundColor: C.coralTint, borderRadius: '14px', padding: '14px 16px',
          marginBottom: '20px',
        }}>
          <p style={{
            fontSize: '10px', letterSpacing: '0.1em', textTransform: 'uppercase',
            color: C.coral, fontFamily: C.sans, fontWeight: 600, marginBottom: '6px',
          }}>
            Knowledge delta
          </p>
          <p style={{ fontSize: '13px', color: C.ink, fontFamily: C.sans, lineHeight: 1.55 }}>
            You already understand tool use and basic agent loops. The most useful new material for you is Anthropic's distinction between workflows and agents, and when each architecture is appropriate.
          </p>
        </div>

        <button
          onClick={() => onNavigate('teach-delta')}
          style={{
            width: '100%', padding: '15px', borderRadius: '14px',
            backgroundColor: C.ink, border: 'none', cursor: 'pointer',
            fontSize: '14px', fontWeight: 600, color: '#fff', fontFamily: C.sans,
            marginBottom: '10px',
          }}
        >
          Teach me the delta
        </button>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
          {['Read original', 'Add to path', 'Connect to project', 'Save for later'].map(action => (
            <button key={action} style={{
              padding: '11px', borderRadius: '10px',
              backgroundColor: C.panel, border: `1px solid ${C.edge}`,
              cursor: 'pointer', fontSize: '12px', color: C.ink2,
              fontFamily: C.sans,
            }}>
              {action}
            </button>
          ))}
        </div>
      </div>
    );
  }

  // Default list view
  return (
    <div onClick={() => setOverflowOpen(null)}>
      {/* Queue header */}
      <div style={{ marginBottom: '20px' }}>
        <h2 style={{
          fontFamily: C.serif, fontSize: '24px', fontWeight: 600,
          color: C.ink, letterSpacing: '-0.01em', lineHeight: 1.2, marginBottom: '4px',
        }}>
          Learning Queue
        </h2>
        <p style={{ fontSize: '13px', color: C.ink3, fontFamily: C.sans, marginBottom: '10px', lineHeight: 1.45 }}>
          Resources waiting to become part of what you understand.
        </p>
        <p style={{ fontSize: '12px', color: C.ink2, fontFamily: C.sans }}>
          {resources.filter(r => r.section !== 'integrated').length} resources · 42 useful minutes
        </p>
      </div>

      {/* Add a resource button */}
      <button
        onClick={e => { e.stopPropagation(); setView('add-url'); }}
        style={{
          width: '100%', padding: '12px 16px', borderRadius: '12px',
          backgroundColor: C.panel, border: `1px solid ${C.edge}`,
          cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '8px',
          marginBottom: '24px', textAlign: 'left',
        }}
      >
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke={C.ink3} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
        </svg>
        <span style={{ fontSize: '13px', color: C.ink3, fontFamily: C.sans }}>
          Add a resource
        </span>
      </button>

      {/* Learn next */}
      {learnNext.length > 0 && (
        <div style={{ marginBottom: '24px' }}>
          <SectionHeader label="Learn next" count={learnNext.length} />
          {learnNext.map(r => <ResourceRow key={r.id} r={r} />)}
        </div>
      )}

      {/* In progress */}
      {inProgress.length > 0 && (
        <div style={{ marginBottom: '24px' }}>
          <SectionHeader label="In progress" count={inProgress.length} />
          {inProgress.map(r => <ResourceRow key={r.id} r={r} />)}
        </div>
      )}

      {/* Saved for later */}
      {savedLater.length > 0 && (
        <div style={{ marginBottom: '24px' }}>
          <SectionHeader label="Saved for later" count={savedLater.length} />
          {savedLater.map(r => <ResourceRow key={r.id} r={r} />)}
        </div>
      )}

      {/* Integrated (collapsed by default) */}
      {integrated.length > 0 && (
        <div>
          <button
            onClick={e => { e.stopPropagation(); setIntegratedOpen(o => !o); }}
            style={{
              display: 'flex', alignItems: 'center', justifyContent: 'space-between',
              width: '100%', background: 'none', border: 'none', cursor: 'pointer', padding: '4px 0',
              marginBottom: '4px',
            }}
          >
            <p style={{
              fontSize: '10px', letterSpacing: '0.12em', textTransform: 'uppercase',
              color: C.ink3, fontFamily: C.sans, fontWeight: 600,
            }}>
              Integrated <span style={{ fontWeight: 400 }}>· {integrated.length}</span>
            </p>
            <svg
              width="14" height="14" viewBox="0 0 24 24" fill="none"
              stroke={C.ink3} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"
              style={{ transform: integratedOpen ? 'rotate(180deg)' : 'none', transition: 'transform 0.2s' }}
            >
              <polyline points="6 9 12 15 18 9"/>
            </svg>
          </button>
          {integratedOpen && integrated.map(r => <ResourceRow key={r.id} r={r} />)}
        </div>
      )}

      {/* Organize bottom sheet */}
      {organizeOpen && (
        <div
          style={{
            position: 'fixed', inset: 0, zIndex: 40,
            backgroundColor: 'rgba(0,0,0,0.25)',
            display: 'flex', alignItems: 'flex-end',
          }}
          onClick={() => setOrganizeOpen(false)}
        >
          <div
            style={{
              width: '100%', backgroundColor: C.panel, borderRadius: '24px 24px 0 0',
              padding: '24px 20px 40px',
            }}
            onClick={e => e.stopPropagation()}
          >
            <div style={{
              width: '36px', height: '4px', borderRadius: '2px',
              backgroundColor: C.edge, margin: '0 auto 20px',
            }} />
            <p style={{
              fontFamily: C.serif, fontSize: '20px', fontWeight: 600,
              color: C.ink, marginBottom: '20px',
            }}>
              Save this to learn
            </p>

            {/* Destination */}
            <p style={{
              fontSize: '10px', letterSpacing: '0.1em', textTransform: 'uppercase',
              color: C.ink3, fontFamily: C.sans, fontWeight: 500, marginBottom: '8px',
            }}>
              Destination
            </p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', marginBottom: '20px' }}>
              {['Learning Queue', 'Reliable Production Agents path', 'Thinketh — HackGT project', 'New knowledge branch'].map((dest, i) => (
                <button key={dest} style={{
                  padding: '11px 14px', borderRadius: '10px', textAlign: 'left',
                  backgroundColor: i === 0 ? C.ink : C.fog,
                  border: 'none', cursor: 'pointer',
                  fontSize: '13px', color: i === 0 ? '#fff' : C.ink2, fontFamily: C.sans,
                }}>
                  {dest}
                </button>
              ))}
            </div>

            {/* Relevant concepts */}
            <p style={{
              fontSize: '10px', letterSpacing: '0.1em', textTransform: 'uppercase',
              color: C.ink3, fontFamily: C.sans, fontWeight: 500, marginBottom: '8px',
            }}>
              Relevant concepts
            </p>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px', marginBottom: '20px' }}>
              {savedToConcepts.map(c => (
                <button
                  key={c}
                  onClick={() => setSavedToConcepts(sc => sc.filter(x => x !== c))}
                  style={{
                    display: 'flex', alignItems: 'center', gap: '5px',
                    padding: '5px 10px', borderRadius: '100px',
                    backgroundColor: C.coralTint, border: `1px solid ${C.coral}`,
                    cursor: 'pointer', fontSize: '12px', color: C.coral, fontFamily: C.sans,
                  }}
                >
                  {c}
                  <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
                    <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
                  </svg>
                </button>
              ))}
            </div>

            {/* Learning intention */}
            <p style={{
              fontSize: '10px', letterSpacing: '0.1em', textTransform: 'uppercase',
              color: C.ink3, fontFamily: C.sans, fontWeight: 500, marginBottom: '8px',
            }}>
              Learning intention
            </p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', marginBottom: '24px' }}>
              {intentions.map(intent => (
                <button
                  key={intent}
                  onClick={() => setSelectedIntention(intent)}
                  style={{
                    padding: '11px 14px', borderRadius: '10px', textAlign: 'left',
                    backgroundColor: selectedIntention === intent ? C.coralTint : C.fog,
                    border: `1px solid ${selectedIntention === intent ? C.coral : 'transparent'}`,
                    cursor: 'pointer', fontSize: '13px',
                    color: selectedIntention === intent ? C.coral : C.ink2,
                    fontFamily: C.sans,
                  }}
                >
                  {intent}
                </button>
              ))}
            </div>

            <button
              onClick={() => setOrganizeOpen(false)}
              style={{
                width: '100%', padding: '15px', borderRadius: '14px',
                backgroundColor: C.ink, border: 'none', cursor: 'pointer',
                fontSize: '14px', fontWeight: 600, color: '#fff', fontFamily: C.sans,
              }}
            >
              Save to learn
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
