export type Screen =
  | 'today'
  | 'detail'
  | 'update'
  | 'today-updated'
  | 'library'
  | 'explore'
  | 'ask'
  | 'desktop-atlas'
  | 'quiz'
  | 'teach-delta';

export type Tab = 'today' | 'library' | 'explore' | 'ask';

export interface ScreenProps {
  onNavigate: (screen: Screen) => void;
  activeTab: Tab;
  onTabChange: (tab: Tab) => void;
}
